AltSql 0.2.0-alpha for Linux x86-64
===================================

Two command-line shells, statically linked, for 64-bit Linux on x86:

  altsql      the shell of AltSql Core 0.1.0-alpha, the engine. It keeps a
              device's database in a file: key-value pairs, time series and
              SQL. ".sync AFTER FILE" writes the records after position AFTER
              to FILE, as the device would send them to its gateway.
  altsql-db   the shell of AltSql DB 0.2.0-alpha, the database for a gateway
              that serves a fleet. It runs SQL, reads and writes rows by key
              with no SQL step (.row get, .row put, .row insert, .row del),
              and applies a device's sync file with ".sync DEVICE AFTER FILE".
              When a batch starts past what the gateway holds, it says
              "gap: send again from N" and changes nothing.

Try it:

  ./altsql new dev.db
  ./altsql dev.db "CREATE TABLE temps (time TIME, machine INT, temp FLOAT)"
  ./altsql dev.db "INSERT INTO temps VALUES (1700000001, 1, 21.5), (1700000002, 2, 22.25)"
  ./altsql dev.db ".sync 0 batch.bin"
  ./altsql-db gw.db ".sync 7 0 batch.bin" "SELECT * FROM temps;"
  ./altsql-db gw.db              (an interactive shell; .help lists the commands)

Status: alpha. Built and tested on a PC; nothing has run on a microcontroller
or a gateway yet. File formats may still change. Not for production.

Source, tests and the logs behind every figure: https://github.com/AltSql/altsql
More about AltSql: https://altsql.com

Copyright 2026 AltSql.com. Licensed under the Apache License 2.0; see LICENSE
and NOTICE.
