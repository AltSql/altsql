--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE shop;
--
-- Name: shop; Type: DATABASE; Schema: -; Owner: pg
--

CREATE DATABASE shop WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE shop OWNER TO pg;

\unrestrict (null)
\connect shop
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sales; Type: SCHEMA; Schema: -; Owner: shop_owner
--

CREATE SCHEMA sales;


ALTER SCHEMA sales OWNER TO shop_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: pg
--

CREATE TABLE public.audit_log (
    at timestamp with time zone,
    msg text
);


ALTER TABLE public.audit_log OWNER TO pg;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: pg
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    email text
);


ALTER TABLE public.customers OWNER TO pg;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: pg
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO pg;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pg
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: orders; Type: TABLE; Schema: sales; Owner: shop_owner
--

CREATE TABLE sales.orders (
    id bigint NOT NULL,
    customer integer,
    total numeric(10,2),
    placed timestamp with time zone DEFAULT '2026-10-01 00:00:00+03'::timestamp with time zone
);


ALTER TABLE sales.orders OWNER TO shop_owner;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: sales; Owner: shop_owner
--

CREATE SEQUENCE sales.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sales.orders_id_seq OWNER TO shop_owner;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: shop_owner
--

ALTER SEQUENCE sales.orders_id_seq OWNED BY sales.orders.id;


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: pg
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: sales; Owner: shop_owner
--

ALTER TABLE ONLY sales.orders ALTER COLUMN id SET DEFAULT nextval('sales.orders_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: pg
--

COPY public.audit_log (at, msg) FROM stdin;
\.
COPY public.audit_log (at, msg) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: pg
--

COPY public.customers (id, name, email) FROM stdin;
\.
COPY public.customers (id, name, email) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: sales; Owner: shop_owner
--

COPY sales.orders (id, customer, total, placed) FROM stdin;
\.
COPY sales.orders (id, customer, total, placed) FROM '$$PATH$$/3411.dat';

--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pg
--

SELECT pg_catalog.setval('public.customers_id_seq', 1200, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: shop_owner
--

SELECT pg_catalog.setval('sales.orders_id_seq', 5000, true);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: pg
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: sales; Owner: shop_owner
--

ALTER TABLE ONLY sales.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_customer_fkey; Type: FK CONSTRAINT; Schema: sales; Owner: shop_owner
--

ALTER TABLE ONLY sales.orders
    ADD CONSTRAINT orders_customer_fkey FOREIGN KEY (customer) REFERENCES public.customers(id);


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: pg
--

GRANT SELECT ON TABLE public.customers TO shop_owner;


--
-- PostgreSQL database dump complete
--

