--
-- PostgreSQL database dump
--

\restrict fYfEDjsJhJjSYMmctnP2iLbUrdYL5dXGFzsMT85TZ1NfPn9B4KjcGKLyJZWlmBk

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: shop; Type: DATABASE; Schema: -; Owner: pg
--

CREATE DATABASE shop WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE shop OWNER TO pg;

\unrestrict fYfEDjsJhJjSYMmctnP2iLbUrdYL5dXGFzsMT85TZ1NfPn9B4KjcGKLyJZWlmBk
\connect shop
\restrict fYfEDjsJhJjSYMmctnP2iLbUrdYL5dXGFzsMT85TZ1NfPn9B4KjcGKLyJZWlmBk

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sales; Type: SCHEMA; Schema: -; Owner: shop_owner
--

CREATE SCHEMA sales;


ALTER SCHEMA sales OWNER TO shop_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: pg
--

CREATE TABLE public.audit_log (
    at timestamp with time zone,
    msg text
);


ALTER TABLE public.audit_log OWNER TO pg;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: pg
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    email text
);


ALTER TABLE public.customers OWNER TO pg;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: pg
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO pg;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pg
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: orders; Type: TABLE; Schema: sales; Owner: shop_owner
--

CREATE TABLE sales.orders (
    id bigint NOT NULL,
    customer integer,
    total numeric(10,2),
    placed timestamp with time zone DEFAULT '2026-10-01 00:00:00+03'::timestamp with time zone
);


ALTER TABLE sales.orders OWNER TO shop_owner;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: sales; Owner: shop_owner
--

CREATE SEQUENCE sales.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE sales.orders_id_seq OWNER TO shop_owner;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: sales; Owner: shop_owner
--

ALTER SEQUENCE sales.orders_id_seq OWNED BY sales.orders.id;


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: pg
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: sales; Owner: shop_owner
--

ALTER TABLE ONLY sales.orders ALTER COLUMN id SET DEFAULT nextval('sales.orders_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: pg
--

COPY public.audit_log (at, msg) FROM stdin;
2026-10-01 00:01:00+03	event 1
2026-10-01 00:02:00+03	event 2
2026-10-01 00:03:00+03	event 3
2026-10-01 00:04:00+03	event 4
2026-10-01 00:05:00+03	event 5
2026-10-01 00:06:00+03	event 6
2026-10-01 00:07:00+03	event 7
2026-10-01 00:08:00+03	event 8
2026-10-01 00:09:00+03	event 9
2026-10-01 00:10:00+03	event 10
2026-10-01 00:11:00+03	event 11
2026-10-01 00:12:00+03	event 12
2026-10-01 00:13:00+03	event 13
2026-10-01 00:14:00+03	event 14
2026-10-01 00:15:00+03	event 15
2026-10-01 00:16:00+03	event 16
2026-10-01 00:17:00+03	event 17
2026-10-01 00:18:00+03	event 18
2026-10-01 00:19:00+03	event 19
2026-10-01 00:20:00+03	event 20
2026-10-01 00:21:00+03	event 21
2026-10-01 00:22:00+03	event 22
2026-10-01 00:23:00+03	event 23
2026-10-01 00:24:00+03	event 24
2026-10-01 00:25:00+03	event 25
2026-10-01 00:26:00+03	event 26
2026-10-01 00:27:00+03	event 27
2026-10-01 00:28:00+03	event 28
2026-10-01 00:29:00+03	event 29
2026-10-01 00:30:00+03	event 30
2026-10-01 00:31:00+03	event 31
2026-10-01 00:32:00+03	event 32
2026-10-01 00:33:00+03	event 33
2026-10-01 00:34:00+03	event 34
2026-10-01 00:35:00+03	event 35
2026-10-01 00:36:00+03	event 36
2026-10-01 00:37:00+03	event 37
2026-10-01 00:38:00+03	event 38
2026-10-01 00:39:00+03	event 39
2026-10-01 00:40:00+03	event 40
2026-10-01 00:41:00+03	event 41
2026-10-01 00:42:00+03	event 42
2026-10-01 00:43:00+03	event 43
2026-10-01 00:44:00+03	event 44
2026-10-01 00:45:00+03	event 45
2026-10-01 00:46:00+03	event 46
2026-10-01 00:47:00+03	event 47
2026-10-01 00:48:00+03	event 48
2026-10-01 00:49:00+03	event 49
2026-10-01 00:50:00+03	event 50
2026-10-01 00:51:00+03	event 51
2026-10-01 00:52:00+03	event 52
2026-10-01 00:53:00+03	event 53
2026-10-01 00:54:00+03	event 54
2026-10-01 00:55:00+03	event 55
2026-10-01 00:56:00+03	event 56
2026-10-01 00:57:00+03	event 57
2026-10-01 00:58:00+03	event 58
2026-10-01 00:59:00+03	event 59
2026-10-01 01:00:00+03	event 60
2026-10-01 01:01:00+03	event 61
2026-10-01 01:02:00+03	event 62
2026-10-01 01:03:00+03	event 63
2026-10-01 01:04:00+03	event 64
2026-10-01 01:05:00+03	event 65
2026-10-01 01:06:00+03	event 66
2026-10-01 01:07:00+03	event 67
2026-10-01 01:08:00+03	event 68
2026-10-01 01:09:00+03	event 69
2026-10-01 01:10:00+03	event 70
2026-10-01 01:11:00+03	event 71
2026-10-01 01:12:00+03	event 72
2026-10-01 01:13:00+03	event 73
2026-10-01 01:14:00+03	event 74
2026-10-01 01:15:00+03	event 75
2026-10-01 01:16:00+03	event 76
2026-10-01 01:17:00+03	event 77
2026-10-01 01:18:00+03	event 78
2026-10-01 01:19:00+03	event 79
2026-10-01 01:20:00+03	event 80
2026-10-01 01:21:00+03	event 81
2026-10-01 01:22:00+03	event 82
2026-10-01 01:23:00+03	event 83
2026-10-01 01:24:00+03	event 84
2026-10-01 01:25:00+03	event 85
2026-10-01 01:26:00+03	event 86
2026-10-01 01:27:00+03	event 87
2026-10-01 01:28:00+03	event 88
2026-10-01 01:29:00+03	event 89
2026-10-01 01:30:00+03	event 90
2026-10-01 01:31:00+03	event 91
2026-10-01 01:32:00+03	event 92
2026-10-01 01:33:00+03	event 93
2026-10-01 01:34:00+03	event 94
2026-10-01 01:35:00+03	event 95
2026-10-01 01:36:00+03	event 96
2026-10-01 01:37:00+03	event 97
2026-10-01 01:38:00+03	event 98
2026-10-01 01:39:00+03	event 99
2026-10-01 01:40:00+03	event 100
2026-10-01 01:41:00+03	event 101
2026-10-01 01:42:00+03	event 102
2026-10-01 01:43:00+03	event 103
2026-10-01 01:44:00+03	event 104
2026-10-01 01:45:00+03	event 105
2026-10-01 01:46:00+03	event 106
2026-10-01 01:47:00+03	event 107
2026-10-01 01:48:00+03	event 108
2026-10-01 01:49:00+03	event 109
2026-10-01 01:50:00+03	event 110
2026-10-01 01:51:00+03	event 111
2026-10-01 01:52:00+03	event 112
2026-10-01 01:53:00+03	event 113
2026-10-01 01:54:00+03	event 114
2026-10-01 01:55:00+03	event 115
2026-10-01 01:56:00+03	event 116
2026-10-01 01:57:00+03	event 117
2026-10-01 01:58:00+03	event 118
2026-10-01 01:59:00+03	event 119
2026-10-01 02:00:00+03	event 120
2026-10-01 02:01:00+03	event 121
2026-10-01 02:02:00+03	event 122
2026-10-01 02:03:00+03	event 123
2026-10-01 02:04:00+03	event 124
2026-10-01 02:05:00+03	event 125
2026-10-01 02:06:00+03	event 126
2026-10-01 02:07:00+03	event 127
2026-10-01 02:08:00+03	event 128
2026-10-01 02:09:00+03	event 129
2026-10-01 02:10:00+03	event 130
2026-10-01 02:11:00+03	event 131
2026-10-01 02:12:00+03	event 132
2026-10-01 02:13:00+03	event 133
2026-10-01 02:14:00+03	event 134
2026-10-01 02:15:00+03	event 135
2026-10-01 02:16:00+03	event 136
2026-10-01 02:17:00+03	event 137
2026-10-01 02:18:00+03	event 138
2026-10-01 02:19:00+03	event 139
2026-10-01 02:20:00+03	event 140
2026-10-01 02:21:00+03	event 141
2026-10-01 02:22:00+03	event 142
2026-10-01 02:23:00+03	event 143
2026-10-01 02:24:00+03	event 144
2026-10-01 02:25:00+03	event 145
2026-10-01 02:26:00+03	event 146
2026-10-01 02:27:00+03	event 147
2026-10-01 02:28:00+03	event 148
2026-10-01 02:29:00+03	event 149
2026-10-01 02:30:00+03	event 150
2026-10-01 02:31:00+03	event 151
2026-10-01 02:32:00+03	event 152
2026-10-01 02:33:00+03	event 153
2026-10-01 02:34:00+03	event 154
2026-10-01 02:35:00+03	event 155
2026-10-01 02:36:00+03	event 156
2026-10-01 02:37:00+03	event 157
2026-10-01 02:38:00+03	event 158
2026-10-01 02:39:00+03	event 159
2026-10-01 02:40:00+03	event 160
2026-10-01 02:41:00+03	event 161
2026-10-01 02:42:00+03	event 162
2026-10-01 02:43:00+03	event 163
2026-10-01 02:44:00+03	event 164
2026-10-01 02:45:00+03	event 165
2026-10-01 02:46:00+03	event 166
2026-10-01 02:47:00+03	event 167
2026-10-01 02:48:00+03	event 168
2026-10-01 02:49:00+03	event 169
2026-10-01 02:50:00+03	event 170
2026-10-01 02:51:00+03	event 171
2026-10-01 02:52:00+03	event 172
2026-10-01 02:53:00+03	event 173
2026-10-01 02:54:00+03	event 174
2026-10-01 02:55:00+03	event 175
2026-10-01 02:56:00+03	event 176
2026-10-01 02:57:00+03	event 177
2026-10-01 02:58:00+03	event 178
2026-10-01 02:59:00+03	event 179
2026-10-01 03:00:00+03	event 180
2026-10-01 03:01:00+03	event 181
2026-10-01 03:02:00+03	event 182
2026-10-01 03:03:00+03	event 183
2026-10-01 03:04:00+03	event 184
2026-10-01 03:05:00+03	event 185
2026-10-01 03:06:00+03	event 186
2026-10-01 03:07:00+03	event 187
2026-10-01 03:08:00+03	event 188
2026-10-01 03:09:00+03	event 189
2026-10-01 03:10:00+03	event 190
2026-10-01 03:11:00+03	event 191
2026-10-01 03:12:00+03	event 192
2026-10-01 03:13:00+03	event 193
2026-10-01 03:14:00+03	event 194
2026-10-01 03:15:00+03	event 195
2026-10-01 03:16:00+03	event 196
2026-10-01 03:17:00+03	event 197
2026-10-01 03:18:00+03	event 198
2026-10-01 03:19:00+03	event 199
2026-10-01 03:20:00+03	event 200
2026-10-01 03:21:00+03	event 201
2026-10-01 03:22:00+03	event 202
2026-10-01 03:23:00+03	event 203
2026-10-01 03:24:00+03	event 204
2026-10-01 03:25:00+03	event 205
2026-10-01 03:26:00+03	event 206
2026-10-01 03:27:00+03	event 207
2026-10-01 03:28:00+03	event 208
2026-10-01 03:29:00+03	event 209
2026-10-01 03:30:00+03	event 210
2026-10-01 03:31:00+03	event 211
2026-10-01 03:32:00+03	event 212
2026-10-01 03:33:00+03	event 213
2026-10-01 03:34:00+03	event 214
2026-10-01 03:35:00+03	event 215
2026-10-01 03:36:00+03	event 216
2026-10-01 03:37:00+03	event 217
2026-10-01 03:38:00+03	event 218
2026-10-01 03:39:00+03	event 219
2026-10-01 03:40:00+03	event 220
2026-10-01 03:41:00+03	event 221
2026-10-01 03:42:00+03	event 222
2026-10-01 03:43:00+03	event 223
2026-10-01 03:44:00+03	event 224
2026-10-01 03:45:00+03	event 225
2026-10-01 03:46:00+03	event 226
2026-10-01 03:47:00+03	event 227
2026-10-01 03:48:00+03	event 228
2026-10-01 03:49:00+03	event 229
2026-10-01 03:50:00+03	event 230
2026-10-01 03:51:00+03	event 231
2026-10-01 03:52:00+03	event 232
2026-10-01 03:53:00+03	event 233
2026-10-01 03:54:00+03	event 234
2026-10-01 03:55:00+03	event 235
2026-10-01 03:56:00+03	event 236
2026-10-01 03:57:00+03	event 237
2026-10-01 03:58:00+03	event 238
2026-10-01 03:59:00+03	event 239
2026-10-01 04:00:00+03	event 240
2026-10-01 04:01:00+03	event 241
2026-10-01 04:02:00+03	event 242
2026-10-01 04:03:00+03	event 243
2026-10-01 04:04:00+03	event 244
2026-10-01 04:05:00+03	event 245
2026-10-01 04:06:00+03	event 246
2026-10-01 04:07:00+03	event 247
2026-10-01 04:08:00+03	event 248
2026-10-01 04:09:00+03	event 249
2026-10-01 04:10:00+03	event 250
2026-10-01 04:11:00+03	event 251
2026-10-01 04:12:00+03	event 252
2026-10-01 04:13:00+03	event 253
2026-10-01 04:14:00+03	event 254
2026-10-01 04:15:00+03	event 255
2026-10-01 04:16:00+03	event 256
2026-10-01 04:17:00+03	event 257
2026-10-01 04:18:00+03	event 258
2026-10-01 04:19:00+03	event 259
2026-10-01 04:20:00+03	event 260
2026-10-01 04:21:00+03	event 261
2026-10-01 04:22:00+03	event 262
2026-10-01 04:23:00+03	event 263
2026-10-01 04:24:00+03	event 264
2026-10-01 04:25:00+03	event 265
2026-10-01 04:26:00+03	event 266
2026-10-01 04:27:00+03	event 267
2026-10-01 04:28:00+03	event 268
2026-10-01 04:29:00+03	event 269
2026-10-01 04:30:00+03	event 270
2026-10-01 04:31:00+03	event 271
2026-10-01 04:32:00+03	event 272
2026-10-01 04:33:00+03	event 273
2026-10-01 04:34:00+03	event 274
2026-10-01 04:35:00+03	event 275
2026-10-01 04:36:00+03	event 276
2026-10-01 04:37:00+03	event 277
2026-10-01 04:38:00+03	event 278
2026-10-01 04:39:00+03	event 279
2026-10-01 04:40:00+03	event 280
2026-10-01 04:41:00+03	event 281
2026-10-01 04:42:00+03	event 282
2026-10-01 04:43:00+03	event 283
2026-10-01 04:44:00+03	event 284
2026-10-01 04:45:00+03	event 285
2026-10-01 04:46:00+03	event 286
2026-10-01 04:47:00+03	event 287
2026-10-01 04:48:00+03	event 288
2026-10-01 04:49:00+03	event 289
2026-10-01 04:50:00+03	event 290
2026-10-01 04:51:00+03	event 291
2026-10-01 04:52:00+03	event 292
2026-10-01 04:53:00+03	event 293
2026-10-01 04:54:00+03	event 294
2026-10-01 04:55:00+03	event 295
2026-10-01 04:56:00+03	event 296
2026-10-01 04:57:00+03	event 297
2026-10-01 04:58:00+03	event 298
2026-10-01 04:59:00+03	event 299
2026-10-01 05:00:00+03	event 300
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: pg
--

COPY public.customers (id, name, email) FROM stdin;
1	customer 1	c1@example.com
2	customer 2	c2@example.com
3	customer 3	c3@example.com
4	customer 4	c4@example.com
5	customer 5	c5@example.com
6	customer 6	c6@example.com
7	customer 7	c7@example.com
8	customer 8	c8@example.com
9	customer 9	c9@example.com
10	customer 10	c10@example.com
11	customer 11	c11@example.com
12	customer 12	c12@example.com
13	customer 13	c13@example.com
14	customer 14	c14@example.com
15	customer 15	c15@example.com
16	customer 16	c16@example.com
17	customer 17	c17@example.com
18	customer 18	c18@example.com
19	customer 19	c19@example.com
20	customer 20	c20@example.com
21	customer 21	c21@example.com
22	customer 22	c22@example.com
23	customer 23	c23@example.com
24	customer 24	c24@example.com
25	customer 25	c25@example.com
26	customer 26	c26@example.com
27	customer 27	c27@example.com
28	customer 28	c28@example.com
29	customer 29	c29@example.com
30	customer 30	c30@example.com
31	customer 31	c31@example.com
32	customer 32	c32@example.com
33	customer 33	c33@example.com
34	customer 34	c34@example.com
35	customer 35	c35@example.com
36	customer 36	c36@example.com
37	customer 37	c37@example.com
38	customer 38	c38@example.com
39	customer 39	c39@example.com
40	customer 40	c40@example.com
41	customer 41	c41@example.com
42	customer 42	c42@example.com
43	customer 43	c43@example.com
44	customer 44	c44@example.com
45	customer 45	c45@example.com
46	customer 46	c46@example.com
47	customer 47	c47@example.com
48	customer 48	c48@example.com
49	customer 49	c49@example.com
50	customer 50	c50@example.com
51	customer 51	c51@example.com
52	customer 52	c52@example.com
53	customer 53	c53@example.com
54	customer 54	c54@example.com
55	customer 55	c55@example.com
56	customer 56	c56@example.com
57	customer 57	c57@example.com
58	customer 58	c58@example.com
59	customer 59	c59@example.com
60	customer 60	c60@example.com
61	customer 61	c61@example.com
62	customer 62	c62@example.com
63	customer 63	c63@example.com
64	customer 64	c64@example.com
65	customer 65	c65@example.com
66	customer 66	c66@example.com
67	customer 67	c67@example.com
68	customer 68	c68@example.com
69	customer 69	c69@example.com
70	customer 70	c70@example.com
71	customer 71	c71@example.com
72	customer 72	c72@example.com
73	customer 73	c73@example.com
74	customer 74	c74@example.com
75	customer 75	c75@example.com
76	customer 76	c76@example.com
77	customer 77	c77@example.com
78	customer 78	c78@example.com
79	customer 79	c79@example.com
80	customer 80	c80@example.com
81	customer 81	c81@example.com
82	customer 82	c82@example.com
83	customer 83	c83@example.com
84	customer 84	c84@example.com
85	customer 85	c85@example.com
86	customer 86	c86@example.com
87	customer 87	c87@example.com
88	customer 88	c88@example.com
89	customer 89	c89@example.com
90	customer 90	c90@example.com
91	customer 91	c91@example.com
92	customer 92	c92@example.com
93	customer 93	c93@example.com
94	customer 94	c94@example.com
95	customer 95	c95@example.com
96	customer 96	c96@example.com
97	customer 97	c97@example.com
98	customer 98	c98@example.com
99	customer 99	c99@example.com
100	customer 100	c100@example.com
101	customer 101	c101@example.com
102	customer 102	c102@example.com
103	customer 103	c103@example.com
104	customer 104	c104@example.com
105	customer 105	c105@example.com
106	customer 106	c106@example.com
107	customer 107	c107@example.com
108	customer 108	c108@example.com
109	customer 109	c109@example.com
110	customer 110	c110@example.com
111	customer 111	c111@example.com
112	customer 112	c112@example.com
113	customer 113	c113@example.com
114	customer 114	c114@example.com
115	customer 115	c115@example.com
116	customer 116	c116@example.com
117	customer 117	c117@example.com
118	customer 118	c118@example.com
119	customer 119	c119@example.com
120	customer 120	c120@example.com
121	customer 121	c121@example.com
122	customer 122	c122@example.com
123	customer 123	c123@example.com
124	customer 124	c124@example.com
125	customer 125	c125@example.com
126	customer 126	c126@example.com
127	customer 127	c127@example.com
128	customer 128	c128@example.com
129	customer 129	c129@example.com
130	customer 130	c130@example.com
131	customer 131	c131@example.com
132	customer 132	c132@example.com
133	customer 133	c133@example.com
134	customer 134	c134@example.com
135	customer 135	c135@example.com
136	customer 136	c136@example.com
137	customer 137	c137@example.com
138	customer 138	c138@example.com
139	customer 139	c139@example.com
140	customer 140	c140@example.com
141	customer 141	c141@example.com
142	customer 142	c142@example.com
143	customer 143	c143@example.com
144	customer 144	c144@example.com
145	customer 145	c145@example.com
146	customer 146	c146@example.com
147	customer 147	c147@example.com
148	customer 148	c148@example.com
149	customer 149	c149@example.com
150	customer 150	c150@example.com
151	customer 151	c151@example.com
152	customer 152	c152@example.com
153	customer 153	c153@example.com
154	customer 154	c154@example.com
155	customer 155	c155@example.com
156	customer 156	c156@example.com
157	customer 157	c157@example.com
158	customer 158	c158@example.com
159	customer 159	c159@example.com
160	customer 160	c160@example.com
161	customer 161	c161@example.com
162	customer 162	c162@example.com
163	customer 163	c163@example.com
164	customer 164	c164@example.com
165	customer 165	c165@example.com
166	customer 166	c166@example.com
167	customer 167	c167@example.com
168	customer 168	c168@example.com
169	customer 169	c169@example.com
170	customer 170	c170@example.com
171	customer 171	c171@example.com
172	customer 172	c172@example.com
173	customer 173	c173@example.com
174	customer 174	c174@example.com
175	customer 175	c175@example.com
176	customer 176	c176@example.com
177	customer 177	c177@example.com
178	customer 178	c178@example.com
179	customer 179	c179@example.com
180	customer 180	c180@example.com
181	customer 181	c181@example.com
182	customer 182	c182@example.com
183	customer 183	c183@example.com
184	customer 184	c184@example.com
185	customer 185	c185@example.com
186	customer 186	c186@example.com
187	customer 187	c187@example.com
188	customer 188	c188@example.com
189	customer 189	c189@example.com
190	customer 190	c190@example.com
191	customer 191	c191@example.com
192	customer 192	c192@example.com
193	customer 193	c193@example.com
194	customer 194	c194@example.com
195	customer 195	c195@example.com
196	customer 196	c196@example.com
197	customer 197	c197@example.com
198	customer 198	c198@example.com
199	customer 199	c199@example.com
200	customer 200	c200@example.com
201	customer 201	c201@example.com
202	customer 202	c202@example.com
203	customer 203	c203@example.com
204	customer 204	c204@example.com
205	customer 205	c205@example.com
206	customer 206	c206@example.com
207	customer 207	c207@example.com
208	customer 208	c208@example.com
209	customer 209	c209@example.com
210	customer 210	c210@example.com
211	customer 211	c211@example.com
212	customer 212	c212@example.com
213	customer 213	c213@example.com
214	customer 214	c214@example.com
215	customer 215	c215@example.com
216	customer 216	c216@example.com
217	customer 217	c217@example.com
218	customer 218	c218@example.com
219	customer 219	c219@example.com
220	customer 220	c220@example.com
221	customer 221	c221@example.com
222	customer 222	c222@example.com
223	customer 223	c223@example.com
224	customer 224	c224@example.com
225	customer 225	c225@example.com
226	customer 226	c226@example.com
227	customer 227	c227@example.com
228	customer 228	c228@example.com
229	customer 229	c229@example.com
230	customer 230	c230@example.com
231	customer 231	c231@example.com
232	customer 232	c232@example.com
233	customer 233	c233@example.com
234	customer 234	c234@example.com
235	customer 235	c235@example.com
236	customer 236	c236@example.com
237	customer 237	c237@example.com
238	customer 238	c238@example.com
239	customer 239	c239@example.com
240	customer 240	c240@example.com
241	customer 241	c241@example.com
242	customer 242	c242@example.com
243	customer 243	c243@example.com
244	customer 244	c244@example.com
245	customer 245	c245@example.com
246	customer 246	c246@example.com
247	customer 247	c247@example.com
248	customer 248	c248@example.com
249	customer 249	c249@example.com
250	customer 250	c250@example.com
251	customer 251	c251@example.com
252	customer 252	c252@example.com
253	customer 253	c253@example.com
254	customer 254	c254@example.com
255	customer 255	c255@example.com
256	customer 256	c256@example.com
257	customer 257	c257@example.com
258	customer 258	c258@example.com
259	customer 259	c259@example.com
260	customer 260	c260@example.com
261	customer 261	c261@example.com
262	customer 262	c262@example.com
263	customer 263	c263@example.com
264	customer 264	c264@example.com
265	customer 265	c265@example.com
266	customer 266	c266@example.com
267	customer 267	c267@example.com
268	customer 268	c268@example.com
269	customer 269	c269@example.com
270	customer 270	c270@example.com
271	customer 271	c271@example.com
272	customer 272	c272@example.com
273	customer 273	c273@example.com
274	customer 274	c274@example.com
275	customer 275	c275@example.com
276	customer 276	c276@example.com
277	customer 277	c277@example.com
278	customer 278	c278@example.com
279	customer 279	c279@example.com
280	customer 280	c280@example.com
281	customer 281	c281@example.com
282	customer 282	c282@example.com
283	customer 283	c283@example.com
284	customer 284	c284@example.com
285	customer 285	c285@example.com
286	customer 286	c286@example.com
287	customer 287	c287@example.com
288	customer 288	c288@example.com
289	customer 289	c289@example.com
290	customer 290	c290@example.com
291	customer 291	c291@example.com
292	customer 292	c292@example.com
293	customer 293	c293@example.com
294	customer 294	c294@example.com
295	customer 295	c295@example.com
296	customer 296	c296@example.com
297	customer 297	c297@example.com
298	customer 298	c298@example.com
299	customer 299	c299@example.com
300	customer 300	c300@example.com
301	customer 301	c301@example.com
302	customer 302	c302@example.com
303	customer 303	c303@example.com
304	customer 304	c304@example.com
305	customer 305	c305@example.com
306	customer 306	c306@example.com
307	customer 307	c307@example.com
308	customer 308	c308@example.com
309	customer 309	c309@example.com
310	customer 310	c310@example.com
311	customer 311	c311@example.com
312	customer 312	c312@example.com
313	customer 313	c313@example.com
314	customer 314	c314@example.com
315	customer 315	c315@example.com
316	customer 316	c316@example.com
317	customer 317	c317@example.com
318	customer 318	c318@example.com
319	customer 319	c319@example.com
320	customer 320	c320@example.com
321	customer 321	c321@example.com
322	customer 322	c322@example.com
323	customer 323	c323@example.com
324	customer 324	c324@example.com
325	customer 325	c325@example.com
326	customer 326	c326@example.com
327	customer 327	c327@example.com
328	customer 328	c328@example.com
329	customer 329	c329@example.com
330	customer 330	c330@example.com
331	customer 331	c331@example.com
332	customer 332	c332@example.com
333	customer 333	c333@example.com
334	customer 334	c334@example.com
335	customer 335	c335@example.com
336	customer 336	c336@example.com
337	customer 337	c337@example.com
338	customer 338	c338@example.com
339	customer 339	c339@example.com
340	customer 340	c340@example.com
341	customer 341	c341@example.com
342	customer 342	c342@example.com
343	customer 343	c343@example.com
344	customer 344	c344@example.com
345	customer 345	c345@example.com
346	customer 346	c346@example.com
347	customer 347	c347@example.com
348	customer 348	c348@example.com
349	customer 349	c349@example.com
350	customer 350	c350@example.com
351	customer 351	c351@example.com
352	customer 352	c352@example.com
353	customer 353	c353@example.com
354	customer 354	c354@example.com
355	customer 355	c355@example.com
356	customer 356	c356@example.com
357	customer 357	c357@example.com
358	customer 358	c358@example.com
359	customer 359	c359@example.com
360	customer 360	c360@example.com
361	customer 361	c361@example.com
362	customer 362	c362@example.com
363	customer 363	c363@example.com
364	customer 364	c364@example.com
365	customer 365	c365@example.com
366	customer 366	c366@example.com
367	customer 367	c367@example.com
368	customer 368	c368@example.com
369	customer 369	c369@example.com
370	customer 370	c370@example.com
371	customer 371	c371@example.com
372	customer 372	c372@example.com
373	customer 373	c373@example.com
374	customer 374	c374@example.com
375	customer 375	c375@example.com
376	customer 376	c376@example.com
377	customer 377	c377@example.com
378	customer 378	c378@example.com
379	customer 379	c379@example.com
380	customer 380	c380@example.com
381	customer 381	c381@example.com
382	customer 382	c382@example.com
383	customer 383	c383@example.com
384	customer 384	c384@example.com
385	customer 385	c385@example.com
386	customer 386	c386@example.com
387	customer 387	c387@example.com
388	customer 388	c388@example.com
389	customer 389	c389@example.com
390	customer 390	c390@example.com
391	customer 391	c391@example.com
392	customer 392	c392@example.com
393	customer 393	c393@example.com
394	customer 394	c394@example.com
395	customer 395	c395@example.com
396	customer 396	c396@example.com
397	customer 397	c397@example.com
398	customer 398	c398@example.com
399	customer 399	c399@example.com
400	customer 400	c400@example.com
401	customer 401	c401@example.com
402	customer 402	c402@example.com
403	customer 403	c403@example.com
404	customer 404	c404@example.com
405	customer 405	c405@example.com
406	customer 406	c406@example.com
407	customer 407	c407@example.com
408	customer 408	c408@example.com
409	customer 409	c409@example.com
410	customer 410	c410@example.com
411	customer 411	c411@example.com
412	customer 412	c412@example.com
413	customer 413	c413@example.com
414	customer 414	c414@example.com
415	customer 415	c415@example.com
416	customer 416	c416@example.com
417	customer 417	c417@example.com
418	customer 418	c418@example.com
419	customer 419	c419@example.com
420	customer 420	c420@example.com
421	customer 421	c421@example.com
422	customer 422	c422@example.com
423	customer 423	c423@example.com
424	customer 424	c424@example.com
425	customer 425	c425@example.com
426	customer 426	c426@example.com
427	customer 427	c427@example.com
428	customer 428	c428@example.com
429	customer 429	c429@example.com
430	customer 430	c430@example.com
431	customer 431	c431@example.com
432	customer 432	c432@example.com
433	customer 433	c433@example.com
434	customer 434	c434@example.com
435	customer 435	c435@example.com
436	customer 436	c436@example.com
437	customer 437	c437@example.com
438	customer 438	c438@example.com
439	customer 439	c439@example.com
440	customer 440	c440@example.com
441	customer 441	c441@example.com
442	customer 442	c442@example.com
443	customer 443	c443@example.com
444	customer 444	c444@example.com
445	customer 445	c445@example.com
446	customer 446	c446@example.com
447	customer 447	c447@example.com
448	customer 448	c448@example.com
449	customer 449	c449@example.com
450	customer 450	c450@example.com
451	customer 451	c451@example.com
452	customer 452	c452@example.com
453	customer 453	c453@example.com
454	customer 454	c454@example.com
455	customer 455	c455@example.com
456	customer 456	c456@example.com
457	customer 457	c457@example.com
458	customer 458	c458@example.com
459	customer 459	c459@example.com
460	customer 460	c460@example.com
461	customer 461	c461@example.com
462	customer 462	c462@example.com
463	customer 463	c463@example.com
464	customer 464	c464@example.com
465	customer 465	c465@example.com
466	customer 466	c466@example.com
467	customer 467	c467@example.com
468	customer 468	c468@example.com
469	customer 469	c469@example.com
470	customer 470	c470@example.com
471	customer 471	c471@example.com
472	customer 472	c472@example.com
473	customer 473	c473@example.com
474	customer 474	c474@example.com
475	customer 475	c475@example.com
476	customer 476	c476@example.com
477	customer 477	c477@example.com
478	customer 478	c478@example.com
479	customer 479	c479@example.com
480	customer 480	c480@example.com
481	customer 481	c481@example.com
482	customer 482	c482@example.com
483	customer 483	c483@example.com
484	customer 484	c484@example.com
485	customer 485	c485@example.com
486	customer 486	c486@example.com
487	customer 487	c487@example.com
488	customer 488	c488@example.com
489	customer 489	c489@example.com
490	customer 490	c490@example.com
491	customer 491	c491@example.com
492	customer 492	c492@example.com
493	customer 493	c493@example.com
494	customer 494	c494@example.com
495	customer 495	c495@example.com
496	customer 496	c496@example.com
497	customer 497	c497@example.com
498	customer 498	c498@example.com
499	customer 499	c499@example.com
500	customer 500	c500@example.com
501	customer 501	c501@example.com
502	customer 502	c502@example.com
503	customer 503	c503@example.com
504	customer 504	c504@example.com
505	customer 505	c505@example.com
506	customer 506	c506@example.com
507	customer 507	c507@example.com
508	customer 508	c508@example.com
509	customer 509	c509@example.com
510	customer 510	c510@example.com
511	customer 511	c511@example.com
512	customer 512	c512@example.com
513	customer 513	c513@example.com
514	customer 514	c514@example.com
515	customer 515	c515@example.com
516	customer 516	c516@example.com
517	customer 517	c517@example.com
518	customer 518	c518@example.com
519	customer 519	c519@example.com
520	customer 520	c520@example.com
521	customer 521	c521@example.com
522	customer 522	c522@example.com
523	customer 523	c523@example.com
524	customer 524	c524@example.com
525	customer 525	c525@example.com
526	customer 526	c526@example.com
527	customer 527	c527@example.com
528	customer 528	c528@example.com
529	customer 529	c529@example.com
530	customer 530	c530@example.com
531	customer 531	c531@example.com
532	customer 532	c532@example.com
533	customer 533	c533@example.com
534	customer 534	c534@example.com
535	customer 535	c535@example.com
536	customer 536	c536@example.com
537	customer 537	c537@example.com
538	customer 538	c538@example.com
539	customer 539	c539@example.com
540	customer 540	c540@example.com
541	customer 541	c541@example.com
542	customer 542	c542@example.com
543	customer 543	c543@example.com
544	customer 544	c544@example.com
545	customer 545	c545@example.com
546	customer 546	c546@example.com
547	customer 547	c547@example.com
548	customer 548	c548@example.com
549	customer 549	c549@example.com
550	customer 550	c550@example.com
551	customer 551	c551@example.com
552	customer 552	c552@example.com
553	customer 553	c553@example.com
554	customer 554	c554@example.com
555	customer 555	c555@example.com
556	customer 556	c556@example.com
557	customer 557	c557@example.com
558	customer 558	c558@example.com
559	customer 559	c559@example.com
560	customer 560	c560@example.com
561	customer 561	c561@example.com
562	customer 562	c562@example.com
563	customer 563	c563@example.com
564	customer 564	c564@example.com
565	customer 565	c565@example.com
566	customer 566	c566@example.com
567	customer 567	c567@example.com
568	customer 568	c568@example.com
569	customer 569	c569@example.com
570	customer 570	c570@example.com
571	customer 571	c571@example.com
572	customer 572	c572@example.com
573	customer 573	c573@example.com
574	customer 574	c574@example.com
575	customer 575	c575@example.com
576	customer 576	c576@example.com
577	customer 577	c577@example.com
578	customer 578	c578@example.com
579	customer 579	c579@example.com
580	customer 580	c580@example.com
581	customer 581	c581@example.com
582	customer 582	c582@example.com
583	customer 583	c583@example.com
584	customer 584	c584@example.com
585	customer 585	c585@example.com
586	customer 586	c586@example.com
587	customer 587	c587@example.com
588	customer 588	c588@example.com
589	customer 589	c589@example.com
590	customer 590	c590@example.com
591	customer 591	c591@example.com
592	customer 592	c592@example.com
593	customer 593	c593@example.com
594	customer 594	c594@example.com
595	customer 595	c595@example.com
596	customer 596	c596@example.com
597	customer 597	c597@example.com
598	customer 598	c598@example.com
599	customer 599	c599@example.com
600	customer 600	c600@example.com
601	customer 601	c601@example.com
602	customer 602	c602@example.com
603	customer 603	c603@example.com
604	customer 604	c604@example.com
605	customer 605	c605@example.com
606	customer 606	c606@example.com
607	customer 607	c607@example.com
608	customer 608	c608@example.com
609	customer 609	c609@example.com
610	customer 610	c610@example.com
611	customer 611	c611@example.com
612	customer 612	c612@example.com
613	customer 613	c613@example.com
614	customer 614	c614@example.com
615	customer 615	c615@example.com
616	customer 616	c616@example.com
617	customer 617	c617@example.com
618	customer 618	c618@example.com
619	customer 619	c619@example.com
620	customer 620	c620@example.com
621	customer 621	c621@example.com
622	customer 622	c622@example.com
623	customer 623	c623@example.com
624	customer 624	c624@example.com
625	customer 625	c625@example.com
626	customer 626	c626@example.com
627	customer 627	c627@example.com
628	customer 628	c628@example.com
629	customer 629	c629@example.com
630	customer 630	c630@example.com
631	customer 631	c631@example.com
632	customer 632	c632@example.com
633	customer 633	c633@example.com
634	customer 634	c634@example.com
635	customer 635	c635@example.com
636	customer 636	c636@example.com
637	customer 637	c637@example.com
638	customer 638	c638@example.com
639	customer 639	c639@example.com
640	customer 640	c640@example.com
641	customer 641	c641@example.com
642	customer 642	c642@example.com
643	customer 643	c643@example.com
644	customer 644	c644@example.com
645	customer 645	c645@example.com
646	customer 646	c646@example.com
647	customer 647	c647@example.com
648	customer 648	c648@example.com
649	customer 649	c649@example.com
650	customer 650	c650@example.com
651	customer 651	c651@example.com
652	customer 652	c652@example.com
653	customer 653	c653@example.com
654	customer 654	c654@example.com
655	customer 655	c655@example.com
656	customer 656	c656@example.com
657	customer 657	c657@example.com
658	customer 658	c658@example.com
659	customer 659	c659@example.com
660	customer 660	c660@example.com
661	customer 661	c661@example.com
662	customer 662	c662@example.com
663	customer 663	c663@example.com
664	customer 664	c664@example.com
665	customer 665	c665@example.com
666	customer 666	c666@example.com
667	customer 667	c667@example.com
668	customer 668	c668@example.com
669	customer 669	c669@example.com
670	customer 670	c670@example.com
671	customer 671	c671@example.com
672	customer 672	c672@example.com
673	customer 673	c673@example.com
674	customer 674	c674@example.com
675	customer 675	c675@example.com
676	customer 676	c676@example.com
677	customer 677	c677@example.com
678	customer 678	c678@example.com
679	customer 679	c679@example.com
680	customer 680	c680@example.com
681	customer 681	c681@example.com
682	customer 682	c682@example.com
683	customer 683	c683@example.com
684	customer 684	c684@example.com
685	customer 685	c685@example.com
686	customer 686	c686@example.com
687	customer 687	c687@example.com
688	customer 688	c688@example.com
689	customer 689	c689@example.com
690	customer 690	c690@example.com
691	customer 691	c691@example.com
692	customer 692	c692@example.com
693	customer 693	c693@example.com
694	customer 694	c694@example.com
695	customer 695	c695@example.com
696	customer 696	c696@example.com
697	customer 697	c697@example.com
698	customer 698	c698@example.com
699	customer 699	c699@example.com
700	customer 700	c700@example.com
701	customer 701	c701@example.com
702	customer 702	c702@example.com
703	customer 703	c703@example.com
704	customer 704	c704@example.com
705	customer 705	c705@example.com
706	customer 706	c706@example.com
707	customer 707	c707@example.com
708	customer 708	c708@example.com
709	customer 709	c709@example.com
710	customer 710	c710@example.com
711	customer 711	c711@example.com
712	customer 712	c712@example.com
713	customer 713	c713@example.com
714	customer 714	c714@example.com
715	customer 715	c715@example.com
716	customer 716	c716@example.com
717	customer 717	c717@example.com
718	customer 718	c718@example.com
719	customer 719	c719@example.com
720	customer 720	c720@example.com
721	customer 721	c721@example.com
722	customer 722	c722@example.com
723	customer 723	c723@example.com
724	customer 724	c724@example.com
725	customer 725	c725@example.com
726	customer 726	c726@example.com
727	customer 727	c727@example.com
728	customer 728	c728@example.com
729	customer 729	c729@example.com
730	customer 730	c730@example.com
731	customer 731	c731@example.com
732	customer 732	c732@example.com
733	customer 733	c733@example.com
734	customer 734	c734@example.com
735	customer 735	c735@example.com
736	customer 736	c736@example.com
737	customer 737	c737@example.com
738	customer 738	c738@example.com
739	customer 739	c739@example.com
740	customer 740	c740@example.com
741	customer 741	c741@example.com
742	customer 742	c742@example.com
743	customer 743	c743@example.com
744	customer 744	c744@example.com
745	customer 745	c745@example.com
746	customer 746	c746@example.com
747	customer 747	c747@example.com
748	customer 748	c748@example.com
749	customer 749	c749@example.com
750	customer 750	c750@example.com
751	customer 751	c751@example.com
752	customer 752	c752@example.com
753	customer 753	c753@example.com
754	customer 754	c754@example.com
755	customer 755	c755@example.com
756	customer 756	c756@example.com
757	customer 757	c757@example.com
758	customer 758	c758@example.com
759	customer 759	c759@example.com
760	customer 760	c760@example.com
761	customer 761	c761@example.com
762	customer 762	c762@example.com
763	customer 763	c763@example.com
764	customer 764	c764@example.com
765	customer 765	c765@example.com
766	customer 766	c766@example.com
767	customer 767	c767@example.com
768	customer 768	c768@example.com
769	customer 769	c769@example.com
770	customer 770	c770@example.com
771	customer 771	c771@example.com
772	customer 772	c772@example.com
773	customer 773	c773@example.com
774	customer 774	c774@example.com
775	customer 775	c775@example.com
776	customer 776	c776@example.com
777	customer 777	c777@example.com
778	customer 778	c778@example.com
779	customer 779	c779@example.com
780	customer 780	c780@example.com
781	customer 781	c781@example.com
782	customer 782	c782@example.com
783	customer 783	c783@example.com
784	customer 784	c784@example.com
785	customer 785	c785@example.com
786	customer 786	c786@example.com
787	customer 787	c787@example.com
788	customer 788	c788@example.com
789	customer 789	c789@example.com
790	customer 790	c790@example.com
791	customer 791	c791@example.com
792	customer 792	c792@example.com
793	customer 793	c793@example.com
794	customer 794	c794@example.com
795	customer 795	c795@example.com
796	customer 796	c796@example.com
797	customer 797	c797@example.com
798	customer 798	c798@example.com
799	customer 799	c799@example.com
800	customer 800	c800@example.com
801	customer 801	c801@example.com
802	customer 802	c802@example.com
803	customer 803	c803@example.com
804	customer 804	c804@example.com
805	customer 805	c805@example.com
806	customer 806	c806@example.com
807	customer 807	c807@example.com
808	customer 808	c808@example.com
809	customer 809	c809@example.com
810	customer 810	c810@example.com
811	customer 811	c811@example.com
812	customer 812	c812@example.com
813	customer 813	c813@example.com
814	customer 814	c814@example.com
815	customer 815	c815@example.com
816	customer 816	c816@example.com
817	customer 817	c817@example.com
818	customer 818	c818@example.com
819	customer 819	c819@example.com
820	customer 820	c820@example.com
821	customer 821	c821@example.com
822	customer 822	c822@example.com
823	customer 823	c823@example.com
824	customer 824	c824@example.com
825	customer 825	c825@example.com
826	customer 826	c826@example.com
827	customer 827	c827@example.com
828	customer 828	c828@example.com
829	customer 829	c829@example.com
830	customer 830	c830@example.com
831	customer 831	c831@example.com
832	customer 832	c832@example.com
833	customer 833	c833@example.com
834	customer 834	c834@example.com
835	customer 835	c835@example.com
836	customer 836	c836@example.com
837	customer 837	c837@example.com
838	customer 838	c838@example.com
839	customer 839	c839@example.com
840	customer 840	c840@example.com
841	customer 841	c841@example.com
842	customer 842	c842@example.com
843	customer 843	c843@example.com
844	customer 844	c844@example.com
845	customer 845	c845@example.com
846	customer 846	c846@example.com
847	customer 847	c847@example.com
848	customer 848	c848@example.com
849	customer 849	c849@example.com
850	customer 850	c850@example.com
851	customer 851	c851@example.com
852	customer 852	c852@example.com
853	customer 853	c853@example.com
854	customer 854	c854@example.com
855	customer 855	c855@example.com
856	customer 856	c856@example.com
857	customer 857	c857@example.com
858	customer 858	c858@example.com
859	customer 859	c859@example.com
860	customer 860	c860@example.com
861	customer 861	c861@example.com
862	customer 862	c862@example.com
863	customer 863	c863@example.com
864	customer 864	c864@example.com
865	customer 865	c865@example.com
866	customer 866	c866@example.com
867	customer 867	c867@example.com
868	customer 868	c868@example.com
869	customer 869	c869@example.com
870	customer 870	c870@example.com
871	customer 871	c871@example.com
872	customer 872	c872@example.com
873	customer 873	c873@example.com
874	customer 874	c874@example.com
875	customer 875	c875@example.com
876	customer 876	c876@example.com
877	customer 877	c877@example.com
878	customer 878	c878@example.com
879	customer 879	c879@example.com
880	customer 880	c880@example.com
881	customer 881	c881@example.com
882	customer 882	c882@example.com
883	customer 883	c883@example.com
884	customer 884	c884@example.com
885	customer 885	c885@example.com
886	customer 886	c886@example.com
887	customer 887	c887@example.com
888	customer 888	c888@example.com
889	customer 889	c889@example.com
890	customer 890	c890@example.com
891	customer 891	c891@example.com
892	customer 892	c892@example.com
893	customer 893	c893@example.com
894	customer 894	c894@example.com
895	customer 895	c895@example.com
896	customer 896	c896@example.com
897	customer 897	c897@example.com
898	customer 898	c898@example.com
899	customer 899	c899@example.com
900	customer 900	c900@example.com
901	customer 901	c901@example.com
902	customer 902	c902@example.com
903	customer 903	c903@example.com
904	customer 904	c904@example.com
905	customer 905	c905@example.com
906	customer 906	c906@example.com
907	customer 907	c907@example.com
908	customer 908	c908@example.com
909	customer 909	c909@example.com
910	customer 910	c910@example.com
911	customer 911	c911@example.com
912	customer 912	c912@example.com
913	customer 913	c913@example.com
914	customer 914	c914@example.com
915	customer 915	c915@example.com
916	customer 916	c916@example.com
917	customer 917	c917@example.com
918	customer 918	c918@example.com
919	customer 919	c919@example.com
920	customer 920	c920@example.com
921	customer 921	c921@example.com
922	customer 922	c922@example.com
923	customer 923	c923@example.com
924	customer 924	c924@example.com
925	customer 925	c925@example.com
926	customer 926	c926@example.com
927	customer 927	c927@example.com
928	customer 928	c928@example.com
929	customer 929	c929@example.com
930	customer 930	c930@example.com
931	customer 931	c931@example.com
932	customer 932	c932@example.com
933	customer 933	c933@example.com
934	customer 934	c934@example.com
935	customer 935	c935@example.com
936	customer 936	c936@example.com
937	customer 937	c937@example.com
938	customer 938	c938@example.com
939	customer 939	c939@example.com
940	customer 940	c940@example.com
941	customer 941	c941@example.com
942	customer 942	c942@example.com
943	customer 943	c943@example.com
944	customer 944	c944@example.com
945	customer 945	c945@example.com
946	customer 946	c946@example.com
947	customer 947	c947@example.com
948	customer 948	c948@example.com
949	customer 949	c949@example.com
950	customer 950	c950@example.com
951	customer 951	c951@example.com
952	customer 952	c952@example.com
953	customer 953	c953@example.com
954	customer 954	c954@example.com
955	customer 955	c955@example.com
956	customer 956	c956@example.com
957	customer 957	c957@example.com
958	customer 958	c958@example.com
959	customer 959	c959@example.com
960	customer 960	c960@example.com
961	customer 961	c961@example.com
962	customer 962	c962@example.com
963	customer 963	c963@example.com
964	customer 964	c964@example.com
965	customer 965	c965@example.com
966	customer 966	c966@example.com
967	customer 967	c967@example.com
968	customer 968	c968@example.com
969	customer 969	c969@example.com
970	customer 970	c970@example.com
971	customer 971	c971@example.com
972	customer 972	c972@example.com
973	customer 973	c973@example.com
974	customer 974	c974@example.com
975	customer 975	c975@example.com
976	customer 976	c976@example.com
977	customer 977	c977@example.com
978	customer 978	c978@example.com
979	customer 979	c979@example.com
980	customer 980	c980@example.com
981	customer 981	c981@example.com
982	customer 982	c982@example.com
983	customer 983	c983@example.com
984	customer 984	c984@example.com
985	customer 985	c985@example.com
986	customer 986	c986@example.com
987	customer 987	c987@example.com
988	customer 988	c988@example.com
989	customer 989	c989@example.com
990	customer 990	c990@example.com
991	customer 991	c991@example.com
992	customer 992	c992@example.com
993	customer 993	c993@example.com
994	customer 994	c994@example.com
995	customer 995	c995@example.com
996	customer 996	c996@example.com
997	customer 997	c997@example.com
998	customer 998	c998@example.com
999	customer 999	c999@example.com
1000	customer 1000	c1000@example.com
1001	customer 1001	c1001@example.com
1002	customer 1002	c1002@example.com
1003	customer 1003	c1003@example.com
1004	customer 1004	c1004@example.com
1005	customer 1005	c1005@example.com
1006	customer 1006	c1006@example.com
1007	customer 1007	c1007@example.com
1008	customer 1008	c1008@example.com
1009	customer 1009	c1009@example.com
1010	customer 1010	c1010@example.com
1011	customer 1011	c1011@example.com
1012	customer 1012	c1012@example.com
1013	customer 1013	c1013@example.com
1014	customer 1014	c1014@example.com
1015	customer 1015	c1015@example.com
1016	customer 1016	c1016@example.com
1017	customer 1017	c1017@example.com
1018	customer 1018	c1018@example.com
1019	customer 1019	c1019@example.com
1020	customer 1020	c1020@example.com
1021	customer 1021	c1021@example.com
1022	customer 1022	c1022@example.com
1023	customer 1023	c1023@example.com
1024	customer 1024	c1024@example.com
1025	customer 1025	c1025@example.com
1026	customer 1026	c1026@example.com
1027	customer 1027	c1027@example.com
1028	customer 1028	c1028@example.com
1029	customer 1029	c1029@example.com
1030	customer 1030	c1030@example.com
1031	customer 1031	c1031@example.com
1032	customer 1032	c1032@example.com
1033	customer 1033	c1033@example.com
1034	customer 1034	c1034@example.com
1035	customer 1035	c1035@example.com
1036	customer 1036	c1036@example.com
1037	customer 1037	c1037@example.com
1038	customer 1038	c1038@example.com
1039	customer 1039	c1039@example.com
1040	customer 1040	c1040@example.com
1041	customer 1041	c1041@example.com
1042	customer 1042	c1042@example.com
1043	customer 1043	c1043@example.com
1044	customer 1044	c1044@example.com
1045	customer 1045	c1045@example.com
1046	customer 1046	c1046@example.com
1047	customer 1047	c1047@example.com
1048	customer 1048	c1048@example.com
1049	customer 1049	c1049@example.com
1050	customer 1050	c1050@example.com
1051	customer 1051	c1051@example.com
1052	customer 1052	c1052@example.com
1053	customer 1053	c1053@example.com
1054	customer 1054	c1054@example.com
1055	customer 1055	c1055@example.com
1056	customer 1056	c1056@example.com
1057	customer 1057	c1057@example.com
1058	customer 1058	c1058@example.com
1059	customer 1059	c1059@example.com
1060	customer 1060	c1060@example.com
1061	customer 1061	c1061@example.com
1062	customer 1062	c1062@example.com
1063	customer 1063	c1063@example.com
1064	customer 1064	c1064@example.com
1065	customer 1065	c1065@example.com
1066	customer 1066	c1066@example.com
1067	customer 1067	c1067@example.com
1068	customer 1068	c1068@example.com
1069	customer 1069	c1069@example.com
1070	customer 1070	c1070@example.com
1071	customer 1071	c1071@example.com
1072	customer 1072	c1072@example.com
1073	customer 1073	c1073@example.com
1074	customer 1074	c1074@example.com
1075	customer 1075	c1075@example.com
1076	customer 1076	c1076@example.com
1077	customer 1077	c1077@example.com
1078	customer 1078	c1078@example.com
1079	customer 1079	c1079@example.com
1080	customer 1080	c1080@example.com
1081	customer 1081	c1081@example.com
1082	customer 1082	c1082@example.com
1083	customer 1083	c1083@example.com
1084	customer 1084	c1084@example.com
1085	customer 1085	c1085@example.com
1086	customer 1086	c1086@example.com
1087	customer 1087	c1087@example.com
1088	customer 1088	c1088@example.com
1089	customer 1089	c1089@example.com
1090	customer 1090	c1090@example.com
1091	customer 1091	c1091@example.com
1092	customer 1092	c1092@example.com
1093	customer 1093	c1093@example.com
1094	customer 1094	c1094@example.com
1095	customer 1095	c1095@example.com
1096	customer 1096	c1096@example.com
1097	customer 1097	c1097@example.com
1098	customer 1098	c1098@example.com
1099	customer 1099	c1099@example.com
1100	customer 1100	c1100@example.com
1101	customer 1101	c1101@example.com
1102	customer 1102	c1102@example.com
1103	customer 1103	c1103@example.com
1104	customer 1104	c1104@example.com
1105	customer 1105	c1105@example.com
1106	customer 1106	c1106@example.com
1107	customer 1107	c1107@example.com
1108	customer 1108	c1108@example.com
1109	customer 1109	c1109@example.com
1110	customer 1110	c1110@example.com
1111	customer 1111	c1111@example.com
1112	customer 1112	c1112@example.com
1113	customer 1113	c1113@example.com
1114	customer 1114	c1114@example.com
1115	customer 1115	c1115@example.com
1116	customer 1116	c1116@example.com
1117	customer 1117	c1117@example.com
1118	customer 1118	c1118@example.com
1119	customer 1119	c1119@example.com
1120	customer 1120	c1120@example.com
1121	customer 1121	c1121@example.com
1122	customer 1122	c1122@example.com
1123	customer 1123	c1123@example.com
1124	customer 1124	c1124@example.com
1125	customer 1125	c1125@example.com
1126	customer 1126	c1126@example.com
1127	customer 1127	c1127@example.com
1128	customer 1128	c1128@example.com
1129	customer 1129	c1129@example.com
1130	customer 1130	c1130@example.com
1131	customer 1131	c1131@example.com
1132	customer 1132	c1132@example.com
1133	customer 1133	c1133@example.com
1134	customer 1134	c1134@example.com
1135	customer 1135	c1135@example.com
1136	customer 1136	c1136@example.com
1137	customer 1137	c1137@example.com
1138	customer 1138	c1138@example.com
1139	customer 1139	c1139@example.com
1140	customer 1140	c1140@example.com
1141	customer 1141	c1141@example.com
1142	customer 1142	c1142@example.com
1143	customer 1143	c1143@example.com
1144	customer 1144	c1144@example.com
1145	customer 1145	c1145@example.com
1146	customer 1146	c1146@example.com
1147	customer 1147	c1147@example.com
1148	customer 1148	c1148@example.com
1149	customer 1149	c1149@example.com
1150	customer 1150	c1150@example.com
1151	customer 1151	c1151@example.com
1152	customer 1152	c1152@example.com
1153	customer 1153	c1153@example.com
1154	customer 1154	c1154@example.com
1155	customer 1155	c1155@example.com
1156	customer 1156	c1156@example.com
1157	customer 1157	c1157@example.com
1158	customer 1158	c1158@example.com
1159	customer 1159	c1159@example.com
1160	customer 1160	c1160@example.com
1161	customer 1161	c1161@example.com
1162	customer 1162	c1162@example.com
1163	customer 1163	c1163@example.com
1164	customer 1164	c1164@example.com
1165	customer 1165	c1165@example.com
1166	customer 1166	c1166@example.com
1167	customer 1167	c1167@example.com
1168	customer 1168	c1168@example.com
1169	customer 1169	c1169@example.com
1170	customer 1170	c1170@example.com
1171	customer 1171	c1171@example.com
1172	customer 1172	c1172@example.com
1173	customer 1173	c1173@example.com
1174	customer 1174	c1174@example.com
1175	customer 1175	c1175@example.com
1176	customer 1176	c1176@example.com
1177	customer 1177	c1177@example.com
1178	customer 1178	c1178@example.com
1179	customer 1179	c1179@example.com
1180	customer 1180	c1180@example.com
1181	customer 1181	c1181@example.com
1182	customer 1182	c1182@example.com
1183	customer 1183	c1183@example.com
1184	customer 1184	c1184@example.com
1185	customer 1185	c1185@example.com
1186	customer 1186	c1186@example.com
1187	customer 1187	c1187@example.com
1188	customer 1188	c1188@example.com
1189	customer 1189	c1189@example.com
1190	customer 1190	c1190@example.com
1191	customer 1191	c1191@example.com
1192	customer 1192	c1192@example.com
1193	customer 1193	c1193@example.com
1194	customer 1194	c1194@example.com
1195	customer 1195	c1195@example.com
1196	customer 1196	c1196@example.com
1197	customer 1197	c1197@example.com
1198	customer 1198	c1198@example.com
1199	customer 1199	c1199@example.com
1200	customer 1200	c1200@example.com
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: sales; Owner: shop_owner
--

COPY sales.orders (id, customer, total, placed) FROM stdin;
1	2	0.33	2026-10-01 00:00:00+03
2	3	0.67	2026-10-01 00:00:00+03
3	4	1.00	2026-10-01 00:00:00+03
4	5	1.33	2026-10-01 00:00:00+03
5	6	1.67	2026-10-01 00:00:00+03
6	7	2.00	2026-10-01 00:00:00+03
7	8	2.33	2026-10-01 00:00:00+03
8	9	2.67	2026-10-01 00:00:00+03
9	10	3.00	2026-10-01 00:00:00+03
10	11	3.33	2026-10-01 00:00:00+03
11	12	3.67	2026-10-01 00:00:00+03
12	13	4.00	2026-10-01 00:00:00+03
13	14	4.33	2026-10-01 00:00:00+03
14	15	4.67	2026-10-01 00:00:00+03
15	16	5.00	2026-10-01 00:00:00+03
16	17	5.33	2026-10-01 00:00:00+03
17	18	5.67	2026-10-01 00:00:00+03
18	19	6.00	2026-10-01 00:00:00+03
19	20	6.33	2026-10-01 00:00:00+03
20	21	6.67	2026-10-01 00:00:00+03
21	22	7.00	2026-10-01 00:00:00+03
22	23	7.33	2026-10-01 00:00:00+03
23	24	7.67	2026-10-01 00:00:00+03
24	25	8.00	2026-10-01 00:00:00+03
25	26	8.33	2026-10-01 00:00:00+03
26	27	8.67	2026-10-01 00:00:00+03
27	28	9.00	2026-10-01 00:00:00+03
28	29	9.33	2026-10-01 00:00:00+03
29	30	9.67	2026-10-01 00:00:00+03
30	31	10.00	2026-10-01 00:00:00+03
31	32	10.33	2026-10-01 00:00:00+03
32	33	10.67	2026-10-01 00:00:00+03
33	34	11.00	2026-10-01 00:00:00+03
34	35	11.33	2026-10-01 00:00:00+03
35	36	11.67	2026-10-01 00:00:00+03
36	37	12.00	2026-10-01 00:00:00+03
37	38	12.33	2026-10-01 00:00:00+03
38	39	12.67	2026-10-01 00:00:00+03
39	40	13.00	2026-10-01 00:00:00+03
40	41	13.33	2026-10-01 00:00:00+03
41	42	13.67	2026-10-01 00:00:00+03
42	43	14.00	2026-10-01 00:00:00+03
43	44	14.33	2026-10-01 00:00:00+03
44	45	14.67	2026-10-01 00:00:00+03
45	46	15.00	2026-10-01 00:00:00+03
46	47	15.33	2026-10-01 00:00:00+03
47	48	15.67	2026-10-01 00:00:00+03
48	49	16.00	2026-10-01 00:00:00+03
49	50	16.33	2026-10-01 00:00:00+03
50	51	16.67	2026-10-01 00:00:00+03
51	52	17.00	2026-10-01 00:00:00+03
52	53	17.33	2026-10-01 00:00:00+03
53	54	17.67	2026-10-01 00:00:00+03
54	55	18.00	2026-10-01 00:00:00+03
55	56	18.33	2026-10-01 00:00:00+03
56	57	18.67	2026-10-01 00:00:00+03
57	58	19.00	2026-10-01 00:00:00+03
58	59	19.33	2026-10-01 00:00:00+03
59	60	19.67	2026-10-01 00:00:00+03
60	61	20.00	2026-10-01 00:00:00+03
61	62	20.33	2026-10-01 00:00:00+03
62	63	20.67	2026-10-01 00:00:00+03
63	64	21.00	2026-10-01 00:00:00+03
64	65	21.33	2026-10-01 00:00:00+03
65	66	21.67	2026-10-01 00:00:00+03
66	67	22.00	2026-10-01 00:00:00+03
67	68	22.33	2026-10-01 00:00:00+03
68	69	22.67	2026-10-01 00:00:00+03
69	70	23.00	2026-10-01 00:00:00+03
70	71	23.33	2026-10-01 00:00:00+03
71	72	23.67	2026-10-01 00:00:00+03
72	73	24.00	2026-10-01 00:00:00+03
73	74	24.33	2026-10-01 00:00:00+03
74	75	24.67	2026-10-01 00:00:00+03
75	76	25.00	2026-10-01 00:00:00+03
76	77	25.33	2026-10-01 00:00:00+03
77	78	25.67	2026-10-01 00:00:00+03
78	79	26.00	2026-10-01 00:00:00+03
79	80	26.33	2026-10-01 00:00:00+03
80	81	26.67	2026-10-01 00:00:00+03
81	82	27.00	2026-10-01 00:00:00+03
82	83	27.33	2026-10-01 00:00:00+03
83	84	27.67	2026-10-01 00:00:00+03
84	85	28.00	2026-10-01 00:00:00+03
85	86	28.33	2026-10-01 00:00:00+03
86	87	28.67	2026-10-01 00:00:00+03
87	88	29.00	2026-10-01 00:00:00+03
88	89	29.33	2026-10-01 00:00:00+03
89	90	29.67	2026-10-01 00:00:00+03
90	91	30.00	2026-10-01 00:00:00+03
91	92	30.33	2026-10-01 00:00:00+03
92	93	30.67	2026-10-01 00:00:00+03
93	94	31.00	2026-10-01 00:00:00+03
94	95	31.33	2026-10-01 00:00:00+03
95	96	31.67	2026-10-01 00:00:00+03
96	97	32.00	2026-10-01 00:00:00+03
97	98	32.33	2026-10-01 00:00:00+03
98	99	32.67	2026-10-01 00:00:00+03
99	100	33.00	2026-10-01 00:00:00+03
100	101	33.33	2026-10-01 00:00:00+03
101	102	33.67	2026-10-01 00:00:00+03
102	103	34.00	2026-10-01 00:00:00+03
103	104	34.33	2026-10-01 00:00:00+03
104	105	34.67	2026-10-01 00:00:00+03
105	106	35.00	2026-10-01 00:00:00+03
106	107	35.33	2026-10-01 00:00:00+03
107	108	35.67	2026-10-01 00:00:00+03
108	109	36.00	2026-10-01 00:00:00+03
109	110	36.33	2026-10-01 00:00:00+03
110	111	36.67	2026-10-01 00:00:00+03
111	112	37.00	2026-10-01 00:00:00+03
112	113	37.33	2026-10-01 00:00:00+03
113	114	37.67	2026-10-01 00:00:00+03
114	115	38.00	2026-10-01 00:00:00+03
115	116	38.33	2026-10-01 00:00:00+03
116	117	38.67	2026-10-01 00:00:00+03
117	118	39.00	2026-10-01 00:00:00+03
118	119	39.33	2026-10-01 00:00:00+03
119	120	39.67	2026-10-01 00:00:00+03
120	121	40.00	2026-10-01 00:00:00+03
121	122	40.33	2026-10-01 00:00:00+03
122	123	40.67	2026-10-01 00:00:00+03
123	124	41.00	2026-10-01 00:00:00+03
124	125	41.33	2026-10-01 00:00:00+03
125	126	41.67	2026-10-01 00:00:00+03
126	127	42.00	2026-10-01 00:00:00+03
127	128	42.33	2026-10-01 00:00:00+03
128	129	42.67	2026-10-01 00:00:00+03
129	130	43.00	2026-10-01 00:00:00+03
130	131	43.33	2026-10-01 00:00:00+03
131	132	43.67	2026-10-01 00:00:00+03
132	133	44.00	2026-10-01 00:00:00+03
133	134	44.33	2026-10-01 00:00:00+03
134	135	44.67	2026-10-01 00:00:00+03
135	136	45.00	2026-10-01 00:00:00+03
136	137	45.33	2026-10-01 00:00:00+03
137	138	45.67	2026-10-01 00:00:00+03
138	139	46.00	2026-10-01 00:00:00+03
139	140	46.33	2026-10-01 00:00:00+03
140	141	46.67	2026-10-01 00:00:00+03
141	142	47.00	2026-10-01 00:00:00+03
142	143	47.33	2026-10-01 00:00:00+03
143	144	47.67	2026-10-01 00:00:00+03
144	145	48.00	2026-10-01 00:00:00+03
145	146	48.33	2026-10-01 00:00:00+03
146	147	48.67	2026-10-01 00:00:00+03
147	148	49.00	2026-10-01 00:00:00+03
148	149	49.33	2026-10-01 00:00:00+03
149	150	49.67	2026-10-01 00:00:00+03
150	151	50.00	2026-10-01 00:00:00+03
151	152	50.33	2026-10-01 00:00:00+03
152	153	50.67	2026-10-01 00:00:00+03
153	154	51.00	2026-10-01 00:00:00+03
154	155	51.33	2026-10-01 00:00:00+03
155	156	51.67	2026-10-01 00:00:00+03
156	157	52.00	2026-10-01 00:00:00+03
157	158	52.33	2026-10-01 00:00:00+03
158	159	52.67	2026-10-01 00:00:00+03
159	160	53.00	2026-10-01 00:00:00+03
160	161	53.33	2026-10-01 00:00:00+03
161	162	53.67	2026-10-01 00:00:00+03
162	163	54.00	2026-10-01 00:00:00+03
163	164	54.33	2026-10-01 00:00:00+03
164	165	54.67	2026-10-01 00:00:00+03
165	166	55.00	2026-10-01 00:00:00+03
166	167	55.33	2026-10-01 00:00:00+03
167	168	55.67	2026-10-01 00:00:00+03
168	169	56.00	2026-10-01 00:00:00+03
169	170	56.33	2026-10-01 00:00:00+03
170	171	56.67	2026-10-01 00:00:00+03
171	172	57.00	2026-10-01 00:00:00+03
172	173	57.33	2026-10-01 00:00:00+03
173	174	57.67	2026-10-01 00:00:00+03
174	175	58.00	2026-10-01 00:00:00+03
175	176	58.33	2026-10-01 00:00:00+03
176	177	58.67	2026-10-01 00:00:00+03
177	178	59.00	2026-10-01 00:00:00+03
178	179	59.33	2026-10-01 00:00:00+03
179	180	59.67	2026-10-01 00:00:00+03
180	181	60.00	2026-10-01 00:00:00+03
181	182	60.33	2026-10-01 00:00:00+03
182	183	60.67	2026-10-01 00:00:00+03
183	184	61.00	2026-10-01 00:00:00+03
184	185	61.33	2026-10-01 00:00:00+03
185	186	61.67	2026-10-01 00:00:00+03
186	187	62.00	2026-10-01 00:00:00+03
187	188	62.33	2026-10-01 00:00:00+03
188	189	62.67	2026-10-01 00:00:00+03
189	190	63.00	2026-10-01 00:00:00+03
190	191	63.33	2026-10-01 00:00:00+03
191	192	63.67	2026-10-01 00:00:00+03
192	193	64.00	2026-10-01 00:00:00+03
193	194	64.33	2026-10-01 00:00:00+03
194	195	64.67	2026-10-01 00:00:00+03
195	196	65.00	2026-10-01 00:00:00+03
196	197	65.33	2026-10-01 00:00:00+03
197	198	65.67	2026-10-01 00:00:00+03
198	199	66.00	2026-10-01 00:00:00+03
199	200	66.33	2026-10-01 00:00:00+03
200	201	66.67	2026-10-01 00:00:00+03
201	202	67.00	2026-10-01 00:00:00+03
202	203	67.33	2026-10-01 00:00:00+03
203	204	67.67	2026-10-01 00:00:00+03
204	205	68.00	2026-10-01 00:00:00+03
205	206	68.33	2026-10-01 00:00:00+03
206	207	68.67	2026-10-01 00:00:00+03
207	208	69.00	2026-10-01 00:00:00+03
208	209	69.33	2026-10-01 00:00:00+03
209	210	69.67	2026-10-01 00:00:00+03
210	211	70.00	2026-10-01 00:00:00+03
211	212	70.33	2026-10-01 00:00:00+03
212	213	70.67	2026-10-01 00:00:00+03
213	214	71.00	2026-10-01 00:00:00+03
214	215	71.33	2026-10-01 00:00:00+03
215	216	71.67	2026-10-01 00:00:00+03
216	217	72.00	2026-10-01 00:00:00+03
217	218	72.33	2026-10-01 00:00:00+03
218	219	72.67	2026-10-01 00:00:00+03
219	220	73.00	2026-10-01 00:00:00+03
220	221	73.33	2026-10-01 00:00:00+03
221	222	73.67	2026-10-01 00:00:00+03
222	223	74.00	2026-10-01 00:00:00+03
223	224	74.33	2026-10-01 00:00:00+03
224	225	74.67	2026-10-01 00:00:00+03
225	226	75.00	2026-10-01 00:00:00+03
226	227	75.33	2026-10-01 00:00:00+03
227	228	75.67	2026-10-01 00:00:00+03
228	229	76.00	2026-10-01 00:00:00+03
229	230	76.33	2026-10-01 00:00:00+03
230	231	76.67	2026-10-01 00:00:00+03
231	232	77.00	2026-10-01 00:00:00+03
232	233	77.33	2026-10-01 00:00:00+03
233	234	77.67	2026-10-01 00:00:00+03
234	235	78.00	2026-10-01 00:00:00+03
235	236	78.33	2026-10-01 00:00:00+03
236	237	78.67	2026-10-01 00:00:00+03
237	238	79.00	2026-10-01 00:00:00+03
238	239	79.33	2026-10-01 00:00:00+03
239	240	79.67	2026-10-01 00:00:00+03
240	241	80.00	2026-10-01 00:00:00+03
241	242	80.33	2026-10-01 00:00:00+03
242	243	80.67	2026-10-01 00:00:00+03
243	244	81.00	2026-10-01 00:00:00+03
244	245	81.33	2026-10-01 00:00:00+03
245	246	81.67	2026-10-01 00:00:00+03
246	247	82.00	2026-10-01 00:00:00+03
247	248	82.33	2026-10-01 00:00:00+03
248	249	82.67	2026-10-01 00:00:00+03
249	250	83.00	2026-10-01 00:00:00+03
250	251	83.33	2026-10-01 00:00:00+03
251	252	83.67	2026-10-01 00:00:00+03
252	253	84.00	2026-10-01 00:00:00+03
253	254	84.33	2026-10-01 00:00:00+03
254	255	84.67	2026-10-01 00:00:00+03
255	256	85.00	2026-10-01 00:00:00+03
256	257	85.33	2026-10-01 00:00:00+03
257	258	85.67	2026-10-01 00:00:00+03
258	259	86.00	2026-10-01 00:00:00+03
259	260	86.33	2026-10-01 00:00:00+03
260	261	86.67	2026-10-01 00:00:00+03
261	262	87.00	2026-10-01 00:00:00+03
262	263	87.33	2026-10-01 00:00:00+03
263	264	87.67	2026-10-01 00:00:00+03
264	265	88.00	2026-10-01 00:00:00+03
265	266	88.33	2026-10-01 00:00:00+03
266	267	88.67	2026-10-01 00:00:00+03
267	268	89.00	2026-10-01 00:00:00+03
268	269	89.33	2026-10-01 00:00:00+03
269	270	89.67	2026-10-01 00:00:00+03
270	271	90.00	2026-10-01 00:00:00+03
271	272	90.33	2026-10-01 00:00:00+03
272	273	90.67	2026-10-01 00:00:00+03
273	274	91.00	2026-10-01 00:00:00+03
274	275	91.33	2026-10-01 00:00:00+03
275	276	91.67	2026-10-01 00:00:00+03
276	277	92.00	2026-10-01 00:00:00+03
277	278	92.33	2026-10-01 00:00:00+03
278	279	92.67	2026-10-01 00:00:00+03
279	280	93.00	2026-10-01 00:00:00+03
280	281	93.33	2026-10-01 00:00:00+03
281	282	93.67	2026-10-01 00:00:00+03
282	283	94.00	2026-10-01 00:00:00+03
283	284	94.33	2026-10-01 00:00:00+03
284	285	94.67	2026-10-01 00:00:00+03
285	286	95.00	2026-10-01 00:00:00+03
286	287	95.33	2026-10-01 00:00:00+03
287	288	95.67	2026-10-01 00:00:00+03
288	289	96.00	2026-10-01 00:00:00+03
289	290	96.33	2026-10-01 00:00:00+03
290	291	96.67	2026-10-01 00:00:00+03
291	292	97.00	2026-10-01 00:00:00+03
292	293	97.33	2026-10-01 00:00:00+03
293	294	97.67	2026-10-01 00:00:00+03
294	295	98.00	2026-10-01 00:00:00+03
295	296	98.33	2026-10-01 00:00:00+03
296	297	98.67	2026-10-01 00:00:00+03
297	298	99.00	2026-10-01 00:00:00+03
298	299	99.33	2026-10-01 00:00:00+03
299	300	99.67	2026-10-01 00:00:00+03
300	301	100.00	2026-10-01 00:00:00+03
301	302	100.33	2026-10-01 00:00:00+03
302	303	100.67	2026-10-01 00:00:00+03
303	304	101.00	2026-10-01 00:00:00+03
304	305	101.33	2026-10-01 00:00:00+03
305	306	101.67	2026-10-01 00:00:00+03
306	307	102.00	2026-10-01 00:00:00+03
307	308	102.33	2026-10-01 00:00:00+03
308	309	102.67	2026-10-01 00:00:00+03
309	310	103.00	2026-10-01 00:00:00+03
310	311	103.33	2026-10-01 00:00:00+03
311	312	103.67	2026-10-01 00:00:00+03
312	313	104.00	2026-10-01 00:00:00+03
313	314	104.33	2026-10-01 00:00:00+03
314	315	104.67	2026-10-01 00:00:00+03
315	316	105.00	2026-10-01 00:00:00+03
316	317	105.33	2026-10-01 00:00:00+03
317	318	105.67	2026-10-01 00:00:00+03
318	319	106.00	2026-10-01 00:00:00+03
319	320	106.33	2026-10-01 00:00:00+03
320	321	106.67	2026-10-01 00:00:00+03
321	322	107.00	2026-10-01 00:00:00+03
322	323	107.33	2026-10-01 00:00:00+03
323	324	107.67	2026-10-01 00:00:00+03
324	325	108.00	2026-10-01 00:00:00+03
325	326	108.33	2026-10-01 00:00:00+03
326	327	108.67	2026-10-01 00:00:00+03
327	328	109.00	2026-10-01 00:00:00+03
328	329	109.33	2026-10-01 00:00:00+03
329	330	109.67	2026-10-01 00:00:00+03
330	331	110.00	2026-10-01 00:00:00+03
331	332	110.33	2026-10-01 00:00:00+03
332	333	110.67	2026-10-01 00:00:00+03
333	334	111.00	2026-10-01 00:00:00+03
334	335	111.33	2026-10-01 00:00:00+03
335	336	111.67	2026-10-01 00:00:00+03
336	337	112.00	2026-10-01 00:00:00+03
337	338	112.33	2026-10-01 00:00:00+03
338	339	112.67	2026-10-01 00:00:00+03
339	340	113.00	2026-10-01 00:00:00+03
340	341	113.33	2026-10-01 00:00:00+03
341	342	113.67	2026-10-01 00:00:00+03
342	343	114.00	2026-10-01 00:00:00+03
343	344	114.33	2026-10-01 00:00:00+03
344	345	114.67	2026-10-01 00:00:00+03
345	346	115.00	2026-10-01 00:00:00+03
346	347	115.33	2026-10-01 00:00:00+03
347	348	115.67	2026-10-01 00:00:00+03
348	349	116.00	2026-10-01 00:00:00+03
349	350	116.33	2026-10-01 00:00:00+03
350	351	116.67	2026-10-01 00:00:00+03
351	352	117.00	2026-10-01 00:00:00+03
352	353	117.33	2026-10-01 00:00:00+03
353	354	117.67	2026-10-01 00:00:00+03
354	355	118.00	2026-10-01 00:00:00+03
355	356	118.33	2026-10-01 00:00:00+03
356	357	118.67	2026-10-01 00:00:00+03
357	358	119.00	2026-10-01 00:00:00+03
358	359	119.33	2026-10-01 00:00:00+03
359	360	119.67	2026-10-01 00:00:00+03
360	361	120.00	2026-10-01 00:00:00+03
361	362	120.33	2026-10-01 00:00:00+03
362	363	120.67	2026-10-01 00:00:00+03
363	364	121.00	2026-10-01 00:00:00+03
364	365	121.33	2026-10-01 00:00:00+03
365	366	121.67	2026-10-01 00:00:00+03
366	367	122.00	2026-10-01 00:00:00+03
367	368	122.33	2026-10-01 00:00:00+03
368	369	122.67	2026-10-01 00:00:00+03
369	370	123.00	2026-10-01 00:00:00+03
370	371	123.33	2026-10-01 00:00:00+03
371	372	123.67	2026-10-01 00:00:00+03
372	373	124.00	2026-10-01 00:00:00+03
373	374	124.33	2026-10-01 00:00:00+03
374	375	124.67	2026-10-01 00:00:00+03
375	376	125.00	2026-10-01 00:00:00+03
376	377	125.33	2026-10-01 00:00:00+03
377	378	125.67	2026-10-01 00:00:00+03
378	379	126.00	2026-10-01 00:00:00+03
379	380	126.33	2026-10-01 00:00:00+03
380	381	126.67	2026-10-01 00:00:00+03
381	382	127.00	2026-10-01 00:00:00+03
382	383	127.33	2026-10-01 00:00:00+03
383	384	127.67	2026-10-01 00:00:00+03
384	385	128.00	2026-10-01 00:00:00+03
385	386	128.33	2026-10-01 00:00:00+03
386	387	128.67	2026-10-01 00:00:00+03
387	388	129.00	2026-10-01 00:00:00+03
388	389	129.33	2026-10-01 00:00:00+03
389	390	129.67	2026-10-01 00:00:00+03
390	391	130.00	2026-10-01 00:00:00+03
391	392	130.33	2026-10-01 00:00:00+03
392	393	130.67	2026-10-01 00:00:00+03
393	394	131.00	2026-10-01 00:00:00+03
394	395	131.33	2026-10-01 00:00:00+03
395	396	131.67	2026-10-01 00:00:00+03
396	397	132.00	2026-10-01 00:00:00+03
397	398	132.33	2026-10-01 00:00:00+03
398	399	132.67	2026-10-01 00:00:00+03
399	400	133.00	2026-10-01 00:00:00+03
400	401	133.33	2026-10-01 00:00:00+03
401	402	133.67	2026-10-01 00:00:00+03
402	403	134.00	2026-10-01 00:00:00+03
403	404	134.33	2026-10-01 00:00:00+03
404	405	134.67	2026-10-01 00:00:00+03
405	406	135.00	2026-10-01 00:00:00+03
406	407	135.33	2026-10-01 00:00:00+03
407	408	135.67	2026-10-01 00:00:00+03
408	409	136.00	2026-10-01 00:00:00+03
409	410	136.33	2026-10-01 00:00:00+03
410	411	136.67	2026-10-01 00:00:00+03
411	412	137.00	2026-10-01 00:00:00+03
412	413	137.33	2026-10-01 00:00:00+03
413	414	137.67	2026-10-01 00:00:00+03
414	415	138.00	2026-10-01 00:00:00+03
415	416	138.33	2026-10-01 00:00:00+03
416	417	138.67	2026-10-01 00:00:00+03
417	418	139.00	2026-10-01 00:00:00+03
418	419	139.33	2026-10-01 00:00:00+03
419	420	139.67	2026-10-01 00:00:00+03
420	421	140.00	2026-10-01 00:00:00+03
421	422	140.33	2026-10-01 00:00:00+03
422	423	140.67	2026-10-01 00:00:00+03
423	424	141.00	2026-10-01 00:00:00+03
424	425	141.33	2026-10-01 00:00:00+03
425	426	141.67	2026-10-01 00:00:00+03
426	427	142.00	2026-10-01 00:00:00+03
427	428	142.33	2026-10-01 00:00:00+03
428	429	142.67	2026-10-01 00:00:00+03
429	430	143.00	2026-10-01 00:00:00+03
430	431	143.33	2026-10-01 00:00:00+03
431	432	143.67	2026-10-01 00:00:00+03
432	433	144.00	2026-10-01 00:00:00+03
433	434	144.33	2026-10-01 00:00:00+03
434	435	144.67	2026-10-01 00:00:00+03
435	436	145.00	2026-10-01 00:00:00+03
436	437	145.33	2026-10-01 00:00:00+03
437	438	145.67	2026-10-01 00:00:00+03
438	439	146.00	2026-10-01 00:00:00+03
439	440	146.33	2026-10-01 00:00:00+03
440	441	146.67	2026-10-01 00:00:00+03
441	442	147.00	2026-10-01 00:00:00+03
442	443	147.33	2026-10-01 00:00:00+03
443	444	147.67	2026-10-01 00:00:00+03
444	445	148.00	2026-10-01 00:00:00+03
445	446	148.33	2026-10-01 00:00:00+03
446	447	148.67	2026-10-01 00:00:00+03
447	448	149.00	2026-10-01 00:00:00+03
448	449	149.33	2026-10-01 00:00:00+03
449	450	149.67	2026-10-01 00:00:00+03
450	451	150.00	2026-10-01 00:00:00+03
451	452	150.33	2026-10-01 00:00:00+03
452	453	150.67	2026-10-01 00:00:00+03
453	454	151.00	2026-10-01 00:00:00+03
454	455	151.33	2026-10-01 00:00:00+03
455	456	151.67	2026-10-01 00:00:00+03
456	457	152.00	2026-10-01 00:00:00+03
457	458	152.33	2026-10-01 00:00:00+03
458	459	152.67	2026-10-01 00:00:00+03
459	460	153.00	2026-10-01 00:00:00+03
460	461	153.33	2026-10-01 00:00:00+03
461	462	153.67	2026-10-01 00:00:00+03
462	463	154.00	2026-10-01 00:00:00+03
463	464	154.33	2026-10-01 00:00:00+03
464	465	154.67	2026-10-01 00:00:00+03
465	466	155.00	2026-10-01 00:00:00+03
466	467	155.33	2026-10-01 00:00:00+03
467	468	155.67	2026-10-01 00:00:00+03
468	469	156.00	2026-10-01 00:00:00+03
469	470	156.33	2026-10-01 00:00:00+03
470	471	156.67	2026-10-01 00:00:00+03
471	472	157.00	2026-10-01 00:00:00+03
472	473	157.33	2026-10-01 00:00:00+03
473	474	157.67	2026-10-01 00:00:00+03
474	475	158.00	2026-10-01 00:00:00+03
475	476	158.33	2026-10-01 00:00:00+03
476	477	158.67	2026-10-01 00:00:00+03
477	478	159.00	2026-10-01 00:00:00+03
478	479	159.33	2026-10-01 00:00:00+03
479	480	159.67	2026-10-01 00:00:00+03
480	481	160.00	2026-10-01 00:00:00+03
481	482	160.33	2026-10-01 00:00:00+03
482	483	160.67	2026-10-01 00:00:00+03
483	484	161.00	2026-10-01 00:00:00+03
484	485	161.33	2026-10-01 00:00:00+03
485	486	161.67	2026-10-01 00:00:00+03
486	487	162.00	2026-10-01 00:00:00+03
487	488	162.33	2026-10-01 00:00:00+03
488	489	162.67	2026-10-01 00:00:00+03
489	490	163.00	2026-10-01 00:00:00+03
490	491	163.33	2026-10-01 00:00:00+03
491	492	163.67	2026-10-01 00:00:00+03
492	493	164.00	2026-10-01 00:00:00+03
493	494	164.33	2026-10-01 00:00:00+03
494	495	164.67	2026-10-01 00:00:00+03
495	496	165.00	2026-10-01 00:00:00+03
496	497	165.33	2026-10-01 00:00:00+03
497	498	165.67	2026-10-01 00:00:00+03
498	499	166.00	2026-10-01 00:00:00+03
499	500	166.33	2026-10-01 00:00:00+03
500	501	166.67	2026-10-01 00:00:00+03
501	502	167.00	2026-10-01 00:00:00+03
502	503	167.33	2026-10-01 00:00:00+03
503	504	167.67	2026-10-01 00:00:00+03
504	505	168.00	2026-10-01 00:00:00+03
505	506	168.33	2026-10-01 00:00:00+03
506	507	168.67	2026-10-01 00:00:00+03
507	508	169.00	2026-10-01 00:00:00+03
508	509	169.33	2026-10-01 00:00:00+03
509	510	169.67	2026-10-01 00:00:00+03
510	511	170.00	2026-10-01 00:00:00+03
511	512	170.33	2026-10-01 00:00:00+03
512	513	170.67	2026-10-01 00:00:00+03
513	514	171.00	2026-10-01 00:00:00+03
514	515	171.33	2026-10-01 00:00:00+03
515	516	171.67	2026-10-01 00:00:00+03
516	517	172.00	2026-10-01 00:00:00+03
517	518	172.33	2026-10-01 00:00:00+03
518	519	172.67	2026-10-01 00:00:00+03
519	520	173.00	2026-10-01 00:00:00+03
520	521	173.33	2026-10-01 00:00:00+03
521	522	173.67	2026-10-01 00:00:00+03
522	523	174.00	2026-10-01 00:00:00+03
523	524	174.33	2026-10-01 00:00:00+03
524	525	174.67	2026-10-01 00:00:00+03
525	526	175.00	2026-10-01 00:00:00+03
526	527	175.33	2026-10-01 00:00:00+03
527	528	175.67	2026-10-01 00:00:00+03
528	529	176.00	2026-10-01 00:00:00+03
529	530	176.33	2026-10-01 00:00:00+03
530	531	176.67	2026-10-01 00:00:00+03
531	532	177.00	2026-10-01 00:00:00+03
532	533	177.33	2026-10-01 00:00:00+03
533	534	177.67	2026-10-01 00:00:00+03
534	535	178.00	2026-10-01 00:00:00+03
535	536	178.33	2026-10-01 00:00:00+03
536	537	178.67	2026-10-01 00:00:00+03
537	538	179.00	2026-10-01 00:00:00+03
538	539	179.33	2026-10-01 00:00:00+03
539	540	179.67	2026-10-01 00:00:00+03
540	541	180.00	2026-10-01 00:00:00+03
541	542	180.33	2026-10-01 00:00:00+03
542	543	180.67	2026-10-01 00:00:00+03
543	544	181.00	2026-10-01 00:00:00+03
544	545	181.33	2026-10-01 00:00:00+03
545	546	181.67	2026-10-01 00:00:00+03
546	547	182.00	2026-10-01 00:00:00+03
547	548	182.33	2026-10-01 00:00:00+03
548	549	182.67	2026-10-01 00:00:00+03
549	550	183.00	2026-10-01 00:00:00+03
550	551	183.33	2026-10-01 00:00:00+03
551	552	183.67	2026-10-01 00:00:00+03
552	553	184.00	2026-10-01 00:00:00+03
553	554	184.33	2026-10-01 00:00:00+03
554	555	184.67	2026-10-01 00:00:00+03
555	556	185.00	2026-10-01 00:00:00+03
556	557	185.33	2026-10-01 00:00:00+03
557	558	185.67	2026-10-01 00:00:00+03
558	559	186.00	2026-10-01 00:00:00+03
559	560	186.33	2026-10-01 00:00:00+03
560	561	186.67	2026-10-01 00:00:00+03
561	562	187.00	2026-10-01 00:00:00+03
562	563	187.33	2026-10-01 00:00:00+03
563	564	187.67	2026-10-01 00:00:00+03
564	565	188.00	2026-10-01 00:00:00+03
565	566	188.33	2026-10-01 00:00:00+03
566	567	188.67	2026-10-01 00:00:00+03
567	568	189.00	2026-10-01 00:00:00+03
568	569	189.33	2026-10-01 00:00:00+03
569	570	189.67	2026-10-01 00:00:00+03
570	571	190.00	2026-10-01 00:00:00+03
571	572	190.33	2026-10-01 00:00:00+03
572	573	190.67	2026-10-01 00:00:00+03
573	574	191.00	2026-10-01 00:00:00+03
574	575	191.33	2026-10-01 00:00:00+03
575	576	191.67	2026-10-01 00:00:00+03
576	577	192.00	2026-10-01 00:00:00+03
577	578	192.33	2026-10-01 00:00:00+03
578	579	192.67	2026-10-01 00:00:00+03
579	580	193.00	2026-10-01 00:00:00+03
580	581	193.33	2026-10-01 00:00:00+03
581	582	193.67	2026-10-01 00:00:00+03
582	583	194.00	2026-10-01 00:00:00+03
583	584	194.33	2026-10-01 00:00:00+03
584	585	194.67	2026-10-01 00:00:00+03
585	586	195.00	2026-10-01 00:00:00+03
586	587	195.33	2026-10-01 00:00:00+03
587	588	195.67	2026-10-01 00:00:00+03
588	589	196.00	2026-10-01 00:00:00+03
589	590	196.33	2026-10-01 00:00:00+03
590	591	196.67	2026-10-01 00:00:00+03
591	592	197.00	2026-10-01 00:00:00+03
592	593	197.33	2026-10-01 00:00:00+03
593	594	197.67	2026-10-01 00:00:00+03
594	595	198.00	2026-10-01 00:00:00+03
595	596	198.33	2026-10-01 00:00:00+03
596	597	198.67	2026-10-01 00:00:00+03
597	598	199.00	2026-10-01 00:00:00+03
598	599	199.33	2026-10-01 00:00:00+03
599	600	199.67	2026-10-01 00:00:00+03
600	601	200.00	2026-10-01 00:00:00+03
601	602	200.33	2026-10-01 00:00:00+03
602	603	200.67	2026-10-01 00:00:00+03
603	604	201.00	2026-10-01 00:00:00+03
604	605	201.33	2026-10-01 00:00:00+03
605	606	201.67	2026-10-01 00:00:00+03
606	607	202.00	2026-10-01 00:00:00+03
607	608	202.33	2026-10-01 00:00:00+03
608	609	202.67	2026-10-01 00:00:00+03
609	610	203.00	2026-10-01 00:00:00+03
610	611	203.33	2026-10-01 00:00:00+03
611	612	203.67	2026-10-01 00:00:00+03
612	613	204.00	2026-10-01 00:00:00+03
613	614	204.33	2026-10-01 00:00:00+03
614	615	204.67	2026-10-01 00:00:00+03
615	616	205.00	2026-10-01 00:00:00+03
616	617	205.33	2026-10-01 00:00:00+03
617	618	205.67	2026-10-01 00:00:00+03
618	619	206.00	2026-10-01 00:00:00+03
619	620	206.33	2026-10-01 00:00:00+03
620	621	206.67	2026-10-01 00:00:00+03
621	622	207.00	2026-10-01 00:00:00+03
622	623	207.33	2026-10-01 00:00:00+03
623	624	207.67	2026-10-01 00:00:00+03
624	625	208.00	2026-10-01 00:00:00+03
625	626	208.33	2026-10-01 00:00:00+03
626	627	208.67	2026-10-01 00:00:00+03
627	628	209.00	2026-10-01 00:00:00+03
628	629	209.33	2026-10-01 00:00:00+03
629	630	209.67	2026-10-01 00:00:00+03
630	631	210.00	2026-10-01 00:00:00+03
631	632	210.33	2026-10-01 00:00:00+03
632	633	210.67	2026-10-01 00:00:00+03
633	634	211.00	2026-10-01 00:00:00+03
634	635	211.33	2026-10-01 00:00:00+03
635	636	211.67	2026-10-01 00:00:00+03
636	637	212.00	2026-10-01 00:00:00+03
637	638	212.33	2026-10-01 00:00:00+03
638	639	212.67	2026-10-01 00:00:00+03
639	640	213.00	2026-10-01 00:00:00+03
640	641	213.33	2026-10-01 00:00:00+03
641	642	213.67	2026-10-01 00:00:00+03
642	643	214.00	2026-10-01 00:00:00+03
643	644	214.33	2026-10-01 00:00:00+03
644	645	214.67	2026-10-01 00:00:00+03
645	646	215.00	2026-10-01 00:00:00+03
646	647	215.33	2026-10-01 00:00:00+03
647	648	215.67	2026-10-01 00:00:00+03
648	649	216.00	2026-10-01 00:00:00+03
649	650	216.33	2026-10-01 00:00:00+03
650	651	216.67	2026-10-01 00:00:00+03
651	652	217.00	2026-10-01 00:00:00+03
652	653	217.33	2026-10-01 00:00:00+03
653	654	217.67	2026-10-01 00:00:00+03
654	655	218.00	2026-10-01 00:00:00+03
655	656	218.33	2026-10-01 00:00:00+03
656	657	218.67	2026-10-01 00:00:00+03
657	658	219.00	2026-10-01 00:00:00+03
658	659	219.33	2026-10-01 00:00:00+03
659	660	219.67	2026-10-01 00:00:00+03
660	661	220.00	2026-10-01 00:00:00+03
661	662	220.33	2026-10-01 00:00:00+03
662	663	220.67	2026-10-01 00:00:00+03
663	664	221.00	2026-10-01 00:00:00+03
664	665	221.33	2026-10-01 00:00:00+03
665	666	221.67	2026-10-01 00:00:00+03
666	667	222.00	2026-10-01 00:00:00+03
667	668	222.33	2026-10-01 00:00:00+03
668	669	222.67	2026-10-01 00:00:00+03
669	670	223.00	2026-10-01 00:00:00+03
670	671	223.33	2026-10-01 00:00:00+03
671	672	223.67	2026-10-01 00:00:00+03
672	673	224.00	2026-10-01 00:00:00+03
673	674	224.33	2026-10-01 00:00:00+03
674	675	224.67	2026-10-01 00:00:00+03
675	676	225.00	2026-10-01 00:00:00+03
676	677	225.33	2026-10-01 00:00:00+03
677	678	225.67	2026-10-01 00:00:00+03
678	679	226.00	2026-10-01 00:00:00+03
679	680	226.33	2026-10-01 00:00:00+03
680	681	226.67	2026-10-01 00:00:00+03
681	682	227.00	2026-10-01 00:00:00+03
682	683	227.33	2026-10-01 00:00:00+03
683	684	227.67	2026-10-01 00:00:00+03
684	685	228.00	2026-10-01 00:00:00+03
685	686	228.33	2026-10-01 00:00:00+03
686	687	228.67	2026-10-01 00:00:00+03
687	688	229.00	2026-10-01 00:00:00+03
688	689	229.33	2026-10-01 00:00:00+03
689	690	229.67	2026-10-01 00:00:00+03
690	691	230.00	2026-10-01 00:00:00+03
691	692	230.33	2026-10-01 00:00:00+03
692	693	230.67	2026-10-01 00:00:00+03
693	694	231.00	2026-10-01 00:00:00+03
694	695	231.33	2026-10-01 00:00:00+03
695	696	231.67	2026-10-01 00:00:00+03
696	697	232.00	2026-10-01 00:00:00+03
697	698	232.33	2026-10-01 00:00:00+03
698	699	232.67	2026-10-01 00:00:00+03
699	700	233.00	2026-10-01 00:00:00+03
700	701	233.33	2026-10-01 00:00:00+03
701	702	233.67	2026-10-01 00:00:00+03
702	703	234.00	2026-10-01 00:00:00+03
703	704	234.33	2026-10-01 00:00:00+03
704	705	234.67	2026-10-01 00:00:00+03
705	706	235.00	2026-10-01 00:00:00+03
706	707	235.33	2026-10-01 00:00:00+03
707	708	235.67	2026-10-01 00:00:00+03
708	709	236.00	2026-10-01 00:00:00+03
709	710	236.33	2026-10-01 00:00:00+03
710	711	236.67	2026-10-01 00:00:00+03
711	712	237.00	2026-10-01 00:00:00+03
712	713	237.33	2026-10-01 00:00:00+03
713	714	237.67	2026-10-01 00:00:00+03
714	715	238.00	2026-10-01 00:00:00+03
715	716	238.33	2026-10-01 00:00:00+03
716	717	238.67	2026-10-01 00:00:00+03
717	718	239.00	2026-10-01 00:00:00+03
718	719	239.33	2026-10-01 00:00:00+03
719	720	239.67	2026-10-01 00:00:00+03
720	721	240.00	2026-10-01 00:00:00+03
721	722	240.33	2026-10-01 00:00:00+03
722	723	240.67	2026-10-01 00:00:00+03
723	724	241.00	2026-10-01 00:00:00+03
724	725	241.33	2026-10-01 00:00:00+03
725	726	241.67	2026-10-01 00:00:00+03
726	727	242.00	2026-10-01 00:00:00+03
727	728	242.33	2026-10-01 00:00:00+03
728	729	242.67	2026-10-01 00:00:00+03
729	730	243.00	2026-10-01 00:00:00+03
730	731	243.33	2026-10-01 00:00:00+03
731	732	243.67	2026-10-01 00:00:00+03
732	733	244.00	2026-10-01 00:00:00+03
733	734	244.33	2026-10-01 00:00:00+03
734	735	244.67	2026-10-01 00:00:00+03
735	736	245.00	2026-10-01 00:00:00+03
736	737	245.33	2026-10-01 00:00:00+03
737	738	245.67	2026-10-01 00:00:00+03
738	739	246.00	2026-10-01 00:00:00+03
739	740	246.33	2026-10-01 00:00:00+03
740	741	246.67	2026-10-01 00:00:00+03
741	742	247.00	2026-10-01 00:00:00+03
742	743	247.33	2026-10-01 00:00:00+03
743	744	247.67	2026-10-01 00:00:00+03
744	745	248.00	2026-10-01 00:00:00+03
745	746	248.33	2026-10-01 00:00:00+03
746	747	248.67	2026-10-01 00:00:00+03
747	748	249.00	2026-10-01 00:00:00+03
748	749	249.33	2026-10-01 00:00:00+03
749	750	249.67	2026-10-01 00:00:00+03
750	751	250.00	2026-10-01 00:00:00+03
751	752	250.33	2026-10-01 00:00:00+03
752	753	250.67	2026-10-01 00:00:00+03
753	754	251.00	2026-10-01 00:00:00+03
754	755	251.33	2026-10-01 00:00:00+03
755	756	251.67	2026-10-01 00:00:00+03
756	757	252.00	2026-10-01 00:00:00+03
757	758	252.33	2026-10-01 00:00:00+03
758	759	252.67	2026-10-01 00:00:00+03
759	760	253.00	2026-10-01 00:00:00+03
760	761	253.33	2026-10-01 00:00:00+03
761	762	253.67	2026-10-01 00:00:00+03
762	763	254.00	2026-10-01 00:00:00+03
763	764	254.33	2026-10-01 00:00:00+03
764	765	254.67	2026-10-01 00:00:00+03
765	766	255.00	2026-10-01 00:00:00+03
766	767	255.33	2026-10-01 00:00:00+03
767	768	255.67	2026-10-01 00:00:00+03
768	769	256.00	2026-10-01 00:00:00+03
769	770	256.33	2026-10-01 00:00:00+03
770	771	256.67	2026-10-01 00:00:00+03
771	772	257.00	2026-10-01 00:00:00+03
772	773	257.33	2026-10-01 00:00:00+03
773	774	257.67	2026-10-01 00:00:00+03
774	775	258.00	2026-10-01 00:00:00+03
775	776	258.33	2026-10-01 00:00:00+03
776	777	258.67	2026-10-01 00:00:00+03
777	778	259.00	2026-10-01 00:00:00+03
778	779	259.33	2026-10-01 00:00:00+03
779	780	259.67	2026-10-01 00:00:00+03
780	781	260.00	2026-10-01 00:00:00+03
781	782	260.33	2026-10-01 00:00:00+03
782	783	260.67	2026-10-01 00:00:00+03
783	784	261.00	2026-10-01 00:00:00+03
784	785	261.33	2026-10-01 00:00:00+03
785	786	261.67	2026-10-01 00:00:00+03
786	787	262.00	2026-10-01 00:00:00+03
787	788	262.33	2026-10-01 00:00:00+03
788	789	262.67	2026-10-01 00:00:00+03
789	790	263.00	2026-10-01 00:00:00+03
790	791	263.33	2026-10-01 00:00:00+03
791	792	263.67	2026-10-01 00:00:00+03
792	793	264.00	2026-10-01 00:00:00+03
793	794	264.33	2026-10-01 00:00:00+03
794	795	264.67	2026-10-01 00:00:00+03
795	796	265.00	2026-10-01 00:00:00+03
796	797	265.33	2026-10-01 00:00:00+03
797	798	265.67	2026-10-01 00:00:00+03
798	799	266.00	2026-10-01 00:00:00+03
799	800	266.33	2026-10-01 00:00:00+03
800	801	266.67	2026-10-01 00:00:00+03
801	802	267.00	2026-10-01 00:00:00+03
802	803	267.33	2026-10-01 00:00:00+03
803	804	267.67	2026-10-01 00:00:00+03
804	805	268.00	2026-10-01 00:00:00+03
805	806	268.33	2026-10-01 00:00:00+03
806	807	268.67	2026-10-01 00:00:00+03
807	808	269.00	2026-10-01 00:00:00+03
808	809	269.33	2026-10-01 00:00:00+03
809	810	269.67	2026-10-01 00:00:00+03
810	811	270.00	2026-10-01 00:00:00+03
811	812	270.33	2026-10-01 00:00:00+03
812	813	270.67	2026-10-01 00:00:00+03
813	814	271.00	2026-10-01 00:00:00+03
814	815	271.33	2026-10-01 00:00:00+03
815	816	271.67	2026-10-01 00:00:00+03
816	817	272.00	2026-10-01 00:00:00+03
817	818	272.33	2026-10-01 00:00:00+03
818	819	272.67	2026-10-01 00:00:00+03
819	820	273.00	2026-10-01 00:00:00+03
820	821	273.33	2026-10-01 00:00:00+03
821	822	273.67	2026-10-01 00:00:00+03
822	823	274.00	2026-10-01 00:00:00+03
823	824	274.33	2026-10-01 00:00:00+03
824	825	274.67	2026-10-01 00:00:00+03
825	826	275.00	2026-10-01 00:00:00+03
826	827	275.33	2026-10-01 00:00:00+03
827	828	275.67	2026-10-01 00:00:00+03
828	829	276.00	2026-10-01 00:00:00+03
829	830	276.33	2026-10-01 00:00:00+03
830	831	276.67	2026-10-01 00:00:00+03
831	832	277.00	2026-10-01 00:00:00+03
832	833	277.33	2026-10-01 00:00:00+03
833	834	277.67	2026-10-01 00:00:00+03
834	835	278.00	2026-10-01 00:00:00+03
835	836	278.33	2026-10-01 00:00:00+03
836	837	278.67	2026-10-01 00:00:00+03
837	838	279.00	2026-10-01 00:00:00+03
838	839	279.33	2026-10-01 00:00:00+03
839	840	279.67	2026-10-01 00:00:00+03
840	841	280.00	2026-10-01 00:00:00+03
841	842	280.33	2026-10-01 00:00:00+03
842	843	280.67	2026-10-01 00:00:00+03
843	844	281.00	2026-10-01 00:00:00+03
844	845	281.33	2026-10-01 00:00:00+03
845	846	281.67	2026-10-01 00:00:00+03
846	847	282.00	2026-10-01 00:00:00+03
847	848	282.33	2026-10-01 00:00:00+03
848	849	282.67	2026-10-01 00:00:00+03
849	850	283.00	2026-10-01 00:00:00+03
850	851	283.33	2026-10-01 00:00:00+03
851	852	283.67	2026-10-01 00:00:00+03
852	853	284.00	2026-10-01 00:00:00+03
853	854	284.33	2026-10-01 00:00:00+03
854	855	284.67	2026-10-01 00:00:00+03
855	856	285.00	2026-10-01 00:00:00+03
856	857	285.33	2026-10-01 00:00:00+03
857	858	285.67	2026-10-01 00:00:00+03
858	859	286.00	2026-10-01 00:00:00+03
859	860	286.33	2026-10-01 00:00:00+03
860	861	286.67	2026-10-01 00:00:00+03
861	862	287.00	2026-10-01 00:00:00+03
862	863	287.33	2026-10-01 00:00:00+03
863	864	287.67	2026-10-01 00:00:00+03
864	865	288.00	2026-10-01 00:00:00+03
865	866	288.33	2026-10-01 00:00:00+03
866	867	288.67	2026-10-01 00:00:00+03
867	868	289.00	2026-10-01 00:00:00+03
868	869	289.33	2026-10-01 00:00:00+03
869	870	289.67	2026-10-01 00:00:00+03
870	871	290.00	2026-10-01 00:00:00+03
871	872	290.33	2026-10-01 00:00:00+03
872	873	290.67	2026-10-01 00:00:00+03
873	874	291.00	2026-10-01 00:00:00+03
874	875	291.33	2026-10-01 00:00:00+03
875	876	291.67	2026-10-01 00:00:00+03
876	877	292.00	2026-10-01 00:00:00+03
877	878	292.33	2026-10-01 00:00:00+03
878	879	292.67	2026-10-01 00:00:00+03
879	880	293.00	2026-10-01 00:00:00+03
880	881	293.33	2026-10-01 00:00:00+03
881	882	293.67	2026-10-01 00:00:00+03
882	883	294.00	2026-10-01 00:00:00+03
883	884	294.33	2026-10-01 00:00:00+03
884	885	294.67	2026-10-01 00:00:00+03
885	886	295.00	2026-10-01 00:00:00+03
886	887	295.33	2026-10-01 00:00:00+03
887	888	295.67	2026-10-01 00:00:00+03
888	889	296.00	2026-10-01 00:00:00+03
889	890	296.33	2026-10-01 00:00:00+03
890	891	296.67	2026-10-01 00:00:00+03
891	892	297.00	2026-10-01 00:00:00+03
892	893	297.33	2026-10-01 00:00:00+03
893	894	297.67	2026-10-01 00:00:00+03
894	895	298.00	2026-10-01 00:00:00+03
895	896	298.33	2026-10-01 00:00:00+03
896	897	298.67	2026-10-01 00:00:00+03
897	898	299.00	2026-10-01 00:00:00+03
898	899	299.33	2026-10-01 00:00:00+03
899	900	299.67	2026-10-01 00:00:00+03
900	901	300.00	2026-10-01 00:00:00+03
901	902	300.33	2026-10-01 00:00:00+03
902	903	300.67	2026-10-01 00:00:00+03
903	904	301.00	2026-10-01 00:00:00+03
904	905	301.33	2026-10-01 00:00:00+03
905	906	301.67	2026-10-01 00:00:00+03
906	907	302.00	2026-10-01 00:00:00+03
907	908	302.33	2026-10-01 00:00:00+03
908	909	302.67	2026-10-01 00:00:00+03
909	910	303.00	2026-10-01 00:00:00+03
910	911	303.33	2026-10-01 00:00:00+03
911	912	303.67	2026-10-01 00:00:00+03
912	913	304.00	2026-10-01 00:00:00+03
913	914	304.33	2026-10-01 00:00:00+03
914	915	304.67	2026-10-01 00:00:00+03
915	916	305.00	2026-10-01 00:00:00+03
916	917	305.33	2026-10-01 00:00:00+03
917	918	305.67	2026-10-01 00:00:00+03
918	919	306.00	2026-10-01 00:00:00+03
919	920	306.33	2026-10-01 00:00:00+03
920	921	306.67	2026-10-01 00:00:00+03
921	922	307.00	2026-10-01 00:00:00+03
922	923	307.33	2026-10-01 00:00:00+03
923	924	307.67	2026-10-01 00:00:00+03
924	925	308.00	2026-10-01 00:00:00+03
925	926	308.33	2026-10-01 00:00:00+03
926	927	308.67	2026-10-01 00:00:00+03
927	928	309.00	2026-10-01 00:00:00+03
928	929	309.33	2026-10-01 00:00:00+03
929	930	309.67	2026-10-01 00:00:00+03
930	931	310.00	2026-10-01 00:00:00+03
931	932	310.33	2026-10-01 00:00:00+03
932	933	310.67	2026-10-01 00:00:00+03
933	934	311.00	2026-10-01 00:00:00+03
934	935	311.33	2026-10-01 00:00:00+03
935	936	311.67	2026-10-01 00:00:00+03
936	937	312.00	2026-10-01 00:00:00+03
937	938	312.33	2026-10-01 00:00:00+03
938	939	312.67	2026-10-01 00:00:00+03
939	940	313.00	2026-10-01 00:00:00+03
940	941	313.33	2026-10-01 00:00:00+03
941	942	313.67	2026-10-01 00:00:00+03
942	943	314.00	2026-10-01 00:00:00+03
943	944	314.33	2026-10-01 00:00:00+03
944	945	314.67	2026-10-01 00:00:00+03
945	946	315.00	2026-10-01 00:00:00+03
946	947	315.33	2026-10-01 00:00:00+03
947	948	315.67	2026-10-01 00:00:00+03
948	949	316.00	2026-10-01 00:00:00+03
949	950	316.33	2026-10-01 00:00:00+03
950	951	316.67	2026-10-01 00:00:00+03
951	952	317.00	2026-10-01 00:00:00+03
952	953	317.33	2026-10-01 00:00:00+03
953	954	317.67	2026-10-01 00:00:00+03
954	955	318.00	2026-10-01 00:00:00+03
955	956	318.33	2026-10-01 00:00:00+03
956	957	318.67	2026-10-01 00:00:00+03
957	958	319.00	2026-10-01 00:00:00+03
958	959	319.33	2026-10-01 00:00:00+03
959	960	319.67	2026-10-01 00:00:00+03
960	961	320.00	2026-10-01 00:00:00+03
961	962	320.33	2026-10-01 00:00:00+03
962	963	320.67	2026-10-01 00:00:00+03
963	964	321.00	2026-10-01 00:00:00+03
964	965	321.33	2026-10-01 00:00:00+03
965	966	321.67	2026-10-01 00:00:00+03
966	967	322.00	2026-10-01 00:00:00+03
967	968	322.33	2026-10-01 00:00:00+03
968	969	322.67	2026-10-01 00:00:00+03
969	970	323.00	2026-10-01 00:00:00+03
970	971	323.33	2026-10-01 00:00:00+03
971	972	323.67	2026-10-01 00:00:00+03
972	973	324.00	2026-10-01 00:00:00+03
973	974	324.33	2026-10-01 00:00:00+03
974	975	324.67	2026-10-01 00:00:00+03
975	976	325.00	2026-10-01 00:00:00+03
976	977	325.33	2026-10-01 00:00:00+03
977	978	0.00	2026-10-01 00:00:00+03
978	979	0.33	2026-10-01 00:00:00+03
979	980	0.67	2026-10-01 00:00:00+03
980	981	1.00	2026-10-01 00:00:00+03
981	982	1.33	2026-10-01 00:00:00+03
982	983	1.67	2026-10-01 00:00:00+03
983	984	2.00	2026-10-01 00:00:00+03
984	985	2.33	2026-10-01 00:00:00+03
985	986	2.67	2026-10-01 00:00:00+03
986	987	3.00	2026-10-01 00:00:00+03
987	988	3.33	2026-10-01 00:00:00+03
988	989	3.67	2026-10-01 00:00:00+03
989	990	4.00	2026-10-01 00:00:00+03
990	991	4.33	2026-10-01 00:00:00+03
991	992	4.67	2026-10-01 00:00:00+03
992	993	5.00	2026-10-01 00:00:00+03
993	994	5.33	2026-10-01 00:00:00+03
994	995	5.67	2026-10-01 00:00:00+03
995	996	6.00	2026-10-01 00:00:00+03
996	997	6.33	2026-10-01 00:00:00+03
997	998	6.67	2026-10-01 00:00:00+03
998	999	7.00	2026-10-01 00:00:00+03
999	1000	7.33	2026-10-01 00:00:00+03
1000	1001	7.67	2026-10-01 00:00:00+03
1001	1002	8.00	2026-10-01 00:00:00+03
1002	1003	8.33	2026-10-01 00:00:00+03
1003	1004	8.67	2026-10-01 00:00:00+03
1004	1005	9.00	2026-10-01 00:00:00+03
1005	1006	9.33	2026-10-01 00:00:00+03
1006	1007	9.67	2026-10-01 00:00:00+03
1007	1008	10.00	2026-10-01 00:00:00+03
1008	1009	10.33	2026-10-01 00:00:00+03
1009	1010	10.67	2026-10-01 00:00:00+03
1010	1011	11.00	2026-10-01 00:00:00+03
1011	1012	11.33	2026-10-01 00:00:00+03
1012	1013	11.67	2026-10-01 00:00:00+03
1013	1014	12.00	2026-10-01 00:00:00+03
1014	1015	12.33	2026-10-01 00:00:00+03
1015	1016	12.67	2026-10-01 00:00:00+03
1016	1017	13.00	2026-10-01 00:00:00+03
1017	1018	13.33	2026-10-01 00:00:00+03
1018	1019	13.67	2026-10-01 00:00:00+03
1019	1020	14.00	2026-10-01 00:00:00+03
1020	1021	14.33	2026-10-01 00:00:00+03
1021	1022	14.67	2026-10-01 00:00:00+03
1022	1023	15.00	2026-10-01 00:00:00+03
1023	1024	15.33	2026-10-01 00:00:00+03
1024	1025	15.67	2026-10-01 00:00:00+03
1025	1026	16.00	2026-10-01 00:00:00+03
1026	1027	16.33	2026-10-01 00:00:00+03
1027	1028	16.67	2026-10-01 00:00:00+03
1028	1029	17.00	2026-10-01 00:00:00+03
1029	1030	17.33	2026-10-01 00:00:00+03
1030	1031	17.67	2026-10-01 00:00:00+03
1031	1032	18.00	2026-10-01 00:00:00+03
1032	1033	18.33	2026-10-01 00:00:00+03
1033	1034	18.67	2026-10-01 00:00:00+03
1034	1035	19.00	2026-10-01 00:00:00+03
1035	1036	19.33	2026-10-01 00:00:00+03
1036	1037	19.67	2026-10-01 00:00:00+03
1037	1038	20.00	2026-10-01 00:00:00+03
1038	1039	20.33	2026-10-01 00:00:00+03
1039	1040	20.67	2026-10-01 00:00:00+03
1040	1041	21.00	2026-10-01 00:00:00+03
1041	1042	21.33	2026-10-01 00:00:00+03
1042	1043	21.67	2026-10-01 00:00:00+03
1043	1044	22.00	2026-10-01 00:00:00+03
1044	1045	22.33	2026-10-01 00:00:00+03
1045	1046	22.67	2026-10-01 00:00:00+03
1046	1047	23.00	2026-10-01 00:00:00+03
1047	1048	23.33	2026-10-01 00:00:00+03
1048	1049	23.67	2026-10-01 00:00:00+03
1049	1050	24.00	2026-10-01 00:00:00+03
1050	1051	24.33	2026-10-01 00:00:00+03
1051	1052	24.67	2026-10-01 00:00:00+03
1052	1053	25.00	2026-10-01 00:00:00+03
1053	1054	25.33	2026-10-01 00:00:00+03
1054	1055	25.67	2026-10-01 00:00:00+03
1055	1056	26.00	2026-10-01 00:00:00+03
1056	1057	26.33	2026-10-01 00:00:00+03
1057	1058	26.67	2026-10-01 00:00:00+03
1058	1059	27.00	2026-10-01 00:00:00+03
1059	1060	27.33	2026-10-01 00:00:00+03
1060	1061	27.67	2026-10-01 00:00:00+03
1061	1062	28.00	2026-10-01 00:00:00+03
1062	1063	28.33	2026-10-01 00:00:00+03
1063	1064	28.67	2026-10-01 00:00:00+03
1064	1065	29.00	2026-10-01 00:00:00+03
1065	1066	29.33	2026-10-01 00:00:00+03
1066	1067	29.67	2026-10-01 00:00:00+03
1067	1068	30.00	2026-10-01 00:00:00+03
1068	1069	30.33	2026-10-01 00:00:00+03
1069	1070	30.67	2026-10-01 00:00:00+03
1070	1071	31.00	2026-10-01 00:00:00+03
1071	1072	31.33	2026-10-01 00:00:00+03
1072	1073	31.67	2026-10-01 00:00:00+03
1073	1074	32.00	2026-10-01 00:00:00+03
1074	1075	32.33	2026-10-01 00:00:00+03
1075	1076	32.67	2026-10-01 00:00:00+03
1076	1077	33.00	2026-10-01 00:00:00+03
1077	1078	33.33	2026-10-01 00:00:00+03
1078	1079	33.67	2026-10-01 00:00:00+03
1079	1080	34.00	2026-10-01 00:00:00+03
1080	1081	34.33	2026-10-01 00:00:00+03
1081	1082	34.67	2026-10-01 00:00:00+03
1082	1083	35.00	2026-10-01 00:00:00+03
1083	1084	35.33	2026-10-01 00:00:00+03
1084	1085	35.67	2026-10-01 00:00:00+03
1085	1086	36.00	2026-10-01 00:00:00+03
1086	1087	36.33	2026-10-01 00:00:00+03
1087	1088	36.67	2026-10-01 00:00:00+03
1088	1089	37.00	2026-10-01 00:00:00+03
1089	1090	37.33	2026-10-01 00:00:00+03
1090	1091	37.67	2026-10-01 00:00:00+03
1091	1092	38.00	2026-10-01 00:00:00+03
1092	1093	38.33	2026-10-01 00:00:00+03
1093	1094	38.67	2026-10-01 00:00:00+03
1094	1095	39.00	2026-10-01 00:00:00+03
1095	1096	39.33	2026-10-01 00:00:00+03
1096	1097	39.67	2026-10-01 00:00:00+03
1097	1098	40.00	2026-10-01 00:00:00+03
1098	1099	40.33	2026-10-01 00:00:00+03
1099	1100	40.67	2026-10-01 00:00:00+03
1100	1101	41.00	2026-10-01 00:00:00+03
1101	1102	41.33	2026-10-01 00:00:00+03
1102	1103	41.67	2026-10-01 00:00:00+03
1103	1104	42.00	2026-10-01 00:00:00+03
1104	1105	42.33	2026-10-01 00:00:00+03
1105	1106	42.67	2026-10-01 00:00:00+03
1106	1107	43.00	2026-10-01 00:00:00+03
1107	1108	43.33	2026-10-01 00:00:00+03
1108	1109	43.67	2026-10-01 00:00:00+03
1109	1110	44.00	2026-10-01 00:00:00+03
1110	1111	44.33	2026-10-01 00:00:00+03
1111	1112	44.67	2026-10-01 00:00:00+03
1112	1113	45.00	2026-10-01 00:00:00+03
1113	1114	45.33	2026-10-01 00:00:00+03
1114	1115	45.67	2026-10-01 00:00:00+03
1115	1116	46.00	2026-10-01 00:00:00+03
1116	1117	46.33	2026-10-01 00:00:00+03
1117	1118	46.67	2026-10-01 00:00:00+03
1118	1119	47.00	2026-10-01 00:00:00+03
1119	1120	47.33	2026-10-01 00:00:00+03
1120	1121	47.67	2026-10-01 00:00:00+03
1121	1122	48.00	2026-10-01 00:00:00+03
1122	1123	48.33	2026-10-01 00:00:00+03
1123	1124	48.67	2026-10-01 00:00:00+03
1124	1125	49.00	2026-10-01 00:00:00+03
1125	1126	49.33	2026-10-01 00:00:00+03
1126	1127	49.67	2026-10-01 00:00:00+03
1127	1128	50.00	2026-10-01 00:00:00+03
1128	1129	50.33	2026-10-01 00:00:00+03
1129	1130	50.67	2026-10-01 00:00:00+03
1130	1131	51.00	2026-10-01 00:00:00+03
1131	1132	51.33	2026-10-01 00:00:00+03
1132	1133	51.67	2026-10-01 00:00:00+03
1133	1134	52.00	2026-10-01 00:00:00+03
1134	1135	52.33	2026-10-01 00:00:00+03
1135	1136	52.67	2026-10-01 00:00:00+03
1136	1137	53.00	2026-10-01 00:00:00+03
1137	1138	53.33	2026-10-01 00:00:00+03
1138	1139	53.67	2026-10-01 00:00:00+03
1139	1140	54.00	2026-10-01 00:00:00+03
1140	1141	54.33	2026-10-01 00:00:00+03
1141	1142	54.67	2026-10-01 00:00:00+03
1142	1143	55.00	2026-10-01 00:00:00+03
1143	1144	55.33	2026-10-01 00:00:00+03
1144	1145	55.67	2026-10-01 00:00:00+03
1145	1146	56.00	2026-10-01 00:00:00+03
1146	1147	56.33	2026-10-01 00:00:00+03
1147	1148	56.67	2026-10-01 00:00:00+03
1148	1149	57.00	2026-10-01 00:00:00+03
1149	1150	57.33	2026-10-01 00:00:00+03
1150	1151	57.67	2026-10-01 00:00:00+03
1151	1152	58.00	2026-10-01 00:00:00+03
1152	1153	58.33	2026-10-01 00:00:00+03
1153	1154	58.67	2026-10-01 00:00:00+03
1154	1155	59.00	2026-10-01 00:00:00+03
1155	1156	59.33	2026-10-01 00:00:00+03
1156	1157	59.67	2026-10-01 00:00:00+03
1157	1158	60.00	2026-10-01 00:00:00+03
1158	1159	60.33	2026-10-01 00:00:00+03
1159	1160	60.67	2026-10-01 00:00:00+03
1160	1161	61.00	2026-10-01 00:00:00+03
1161	1162	61.33	2026-10-01 00:00:00+03
1162	1163	61.67	2026-10-01 00:00:00+03
1163	1164	62.00	2026-10-01 00:00:00+03
1164	1165	62.33	2026-10-01 00:00:00+03
1165	1166	62.67	2026-10-01 00:00:00+03
1166	1167	63.00	2026-10-01 00:00:00+03
1167	1168	63.33	2026-10-01 00:00:00+03
1168	1169	63.67	2026-10-01 00:00:00+03
1169	1170	64.00	2026-10-01 00:00:00+03
1170	1171	64.33	2026-10-01 00:00:00+03
1171	1172	64.67	2026-10-01 00:00:00+03
1172	1173	65.00	2026-10-01 00:00:00+03
1173	1174	65.33	2026-10-01 00:00:00+03
1174	1175	65.67	2026-10-01 00:00:00+03
1175	1176	66.00	2026-10-01 00:00:00+03
1176	1177	66.33	2026-10-01 00:00:00+03
1177	1178	66.67	2026-10-01 00:00:00+03
1178	1179	67.00	2026-10-01 00:00:00+03
1179	1180	67.33	2026-10-01 00:00:00+03
1180	1181	67.67	2026-10-01 00:00:00+03
1181	1182	68.00	2026-10-01 00:00:00+03
1182	1183	68.33	2026-10-01 00:00:00+03
1183	1184	68.67	2026-10-01 00:00:00+03
1184	1185	69.00	2026-10-01 00:00:00+03
1185	1186	69.33	2026-10-01 00:00:00+03
1186	1187	69.67	2026-10-01 00:00:00+03
1187	1188	70.00	2026-10-01 00:00:00+03
1188	1189	70.33	2026-10-01 00:00:00+03
1189	1190	70.67	2026-10-01 00:00:00+03
1190	1191	71.00	2026-10-01 00:00:00+03
1191	1192	71.33	2026-10-01 00:00:00+03
1192	1193	71.67	2026-10-01 00:00:00+03
1193	1194	72.00	2026-10-01 00:00:00+03
1194	1195	72.33	2026-10-01 00:00:00+03
1195	1196	72.67	2026-10-01 00:00:00+03
1196	1197	73.00	2026-10-01 00:00:00+03
1197	1198	73.33	2026-10-01 00:00:00+03
1198	1199	73.67	2026-10-01 00:00:00+03
1199	1200	74.00	2026-10-01 00:00:00+03
1200	1	74.33	2026-10-01 00:00:00+03
1201	2	74.67	2026-10-01 00:00:00+03
1202	3	75.00	2026-10-01 00:00:00+03
1203	4	75.33	2026-10-01 00:00:00+03
1204	5	75.67	2026-10-01 00:00:00+03
1205	6	76.00	2026-10-01 00:00:00+03
1206	7	76.33	2026-10-01 00:00:00+03
1207	8	76.67	2026-10-01 00:00:00+03
1208	9	77.00	2026-10-01 00:00:00+03
1209	10	77.33	2026-10-01 00:00:00+03
1210	11	77.67	2026-10-01 00:00:00+03
1211	12	78.00	2026-10-01 00:00:00+03
1212	13	78.33	2026-10-01 00:00:00+03
1213	14	78.67	2026-10-01 00:00:00+03
1214	15	79.00	2026-10-01 00:00:00+03
1215	16	79.33	2026-10-01 00:00:00+03
1216	17	79.67	2026-10-01 00:00:00+03
1217	18	80.00	2026-10-01 00:00:00+03
1218	19	80.33	2026-10-01 00:00:00+03
1219	20	80.67	2026-10-01 00:00:00+03
1220	21	81.00	2026-10-01 00:00:00+03
1221	22	81.33	2026-10-01 00:00:00+03
1222	23	81.67	2026-10-01 00:00:00+03
1223	24	82.00	2026-10-01 00:00:00+03
1224	25	82.33	2026-10-01 00:00:00+03
1225	26	82.67	2026-10-01 00:00:00+03
1226	27	83.00	2026-10-01 00:00:00+03
1227	28	83.33	2026-10-01 00:00:00+03
1228	29	83.67	2026-10-01 00:00:00+03
1229	30	84.00	2026-10-01 00:00:00+03
1230	31	84.33	2026-10-01 00:00:00+03
1231	32	84.67	2026-10-01 00:00:00+03
1232	33	85.00	2026-10-01 00:00:00+03
1233	34	85.33	2026-10-01 00:00:00+03
1234	35	85.67	2026-10-01 00:00:00+03
1235	36	86.00	2026-10-01 00:00:00+03
1236	37	86.33	2026-10-01 00:00:00+03
1237	38	86.67	2026-10-01 00:00:00+03
1238	39	87.00	2026-10-01 00:00:00+03
1239	40	87.33	2026-10-01 00:00:00+03
1240	41	87.67	2026-10-01 00:00:00+03
1241	42	88.00	2026-10-01 00:00:00+03
1242	43	88.33	2026-10-01 00:00:00+03
1243	44	88.67	2026-10-01 00:00:00+03
1244	45	89.00	2026-10-01 00:00:00+03
1245	46	89.33	2026-10-01 00:00:00+03
1246	47	89.67	2026-10-01 00:00:00+03
1247	48	90.00	2026-10-01 00:00:00+03
1248	49	90.33	2026-10-01 00:00:00+03
1249	50	90.67	2026-10-01 00:00:00+03
1250	51	91.00	2026-10-01 00:00:00+03
1251	52	91.33	2026-10-01 00:00:00+03
1252	53	91.67	2026-10-01 00:00:00+03
1253	54	92.00	2026-10-01 00:00:00+03
1254	55	92.33	2026-10-01 00:00:00+03
1255	56	92.67	2026-10-01 00:00:00+03
1256	57	93.00	2026-10-01 00:00:00+03
1257	58	93.33	2026-10-01 00:00:00+03
1258	59	93.67	2026-10-01 00:00:00+03
1259	60	94.00	2026-10-01 00:00:00+03
1260	61	94.33	2026-10-01 00:00:00+03
1261	62	94.67	2026-10-01 00:00:00+03
1262	63	95.00	2026-10-01 00:00:00+03
1263	64	95.33	2026-10-01 00:00:00+03
1264	65	95.67	2026-10-01 00:00:00+03
1265	66	96.00	2026-10-01 00:00:00+03
1266	67	96.33	2026-10-01 00:00:00+03
1267	68	96.67	2026-10-01 00:00:00+03
1268	69	97.00	2026-10-01 00:00:00+03
1269	70	97.33	2026-10-01 00:00:00+03
1270	71	97.67	2026-10-01 00:00:00+03
1271	72	98.00	2026-10-01 00:00:00+03
1272	73	98.33	2026-10-01 00:00:00+03
1273	74	98.67	2026-10-01 00:00:00+03
1274	75	99.00	2026-10-01 00:00:00+03
1275	76	99.33	2026-10-01 00:00:00+03
1276	77	99.67	2026-10-01 00:00:00+03
1277	78	100.00	2026-10-01 00:00:00+03
1278	79	100.33	2026-10-01 00:00:00+03
1279	80	100.67	2026-10-01 00:00:00+03
1280	81	101.00	2026-10-01 00:00:00+03
1281	82	101.33	2026-10-01 00:00:00+03
1282	83	101.67	2026-10-01 00:00:00+03
1283	84	102.00	2026-10-01 00:00:00+03
1284	85	102.33	2026-10-01 00:00:00+03
1285	86	102.67	2026-10-01 00:00:00+03
1286	87	103.00	2026-10-01 00:00:00+03
1287	88	103.33	2026-10-01 00:00:00+03
1288	89	103.67	2026-10-01 00:00:00+03
1289	90	104.00	2026-10-01 00:00:00+03
1290	91	104.33	2026-10-01 00:00:00+03
1291	92	104.67	2026-10-01 00:00:00+03
1292	93	105.00	2026-10-01 00:00:00+03
1293	94	105.33	2026-10-01 00:00:00+03
1294	95	105.67	2026-10-01 00:00:00+03
1295	96	106.00	2026-10-01 00:00:00+03
1296	97	106.33	2026-10-01 00:00:00+03
1297	98	106.67	2026-10-01 00:00:00+03
1298	99	107.00	2026-10-01 00:00:00+03
1299	100	107.33	2026-10-01 00:00:00+03
1300	101	107.67	2026-10-01 00:00:00+03
1301	102	108.00	2026-10-01 00:00:00+03
1302	103	108.33	2026-10-01 00:00:00+03
1303	104	108.67	2026-10-01 00:00:00+03
1304	105	109.00	2026-10-01 00:00:00+03
1305	106	109.33	2026-10-01 00:00:00+03
1306	107	109.67	2026-10-01 00:00:00+03
1307	108	110.00	2026-10-01 00:00:00+03
1308	109	110.33	2026-10-01 00:00:00+03
1309	110	110.67	2026-10-01 00:00:00+03
1310	111	111.00	2026-10-01 00:00:00+03
1311	112	111.33	2026-10-01 00:00:00+03
1312	113	111.67	2026-10-01 00:00:00+03
1313	114	112.00	2026-10-01 00:00:00+03
1314	115	112.33	2026-10-01 00:00:00+03
1315	116	112.67	2026-10-01 00:00:00+03
1316	117	113.00	2026-10-01 00:00:00+03
1317	118	113.33	2026-10-01 00:00:00+03
1318	119	113.67	2026-10-01 00:00:00+03
1319	120	114.00	2026-10-01 00:00:00+03
1320	121	114.33	2026-10-01 00:00:00+03
1321	122	114.67	2026-10-01 00:00:00+03
1322	123	115.00	2026-10-01 00:00:00+03
1323	124	115.33	2026-10-01 00:00:00+03
1324	125	115.67	2026-10-01 00:00:00+03
1325	126	116.00	2026-10-01 00:00:00+03
1326	127	116.33	2026-10-01 00:00:00+03
1327	128	116.67	2026-10-01 00:00:00+03
1328	129	117.00	2026-10-01 00:00:00+03
1329	130	117.33	2026-10-01 00:00:00+03
1330	131	117.67	2026-10-01 00:00:00+03
1331	132	118.00	2026-10-01 00:00:00+03
1332	133	118.33	2026-10-01 00:00:00+03
1333	134	118.67	2026-10-01 00:00:00+03
1334	135	119.00	2026-10-01 00:00:00+03
1335	136	119.33	2026-10-01 00:00:00+03
1336	137	119.67	2026-10-01 00:00:00+03
1337	138	120.00	2026-10-01 00:00:00+03
1338	139	120.33	2026-10-01 00:00:00+03
1339	140	120.67	2026-10-01 00:00:00+03
1340	141	121.00	2026-10-01 00:00:00+03
1341	142	121.33	2026-10-01 00:00:00+03
1342	143	121.67	2026-10-01 00:00:00+03
1343	144	122.00	2026-10-01 00:00:00+03
1344	145	122.33	2026-10-01 00:00:00+03
1345	146	122.67	2026-10-01 00:00:00+03
1346	147	123.00	2026-10-01 00:00:00+03
1347	148	123.33	2026-10-01 00:00:00+03
1348	149	123.67	2026-10-01 00:00:00+03
1349	150	124.00	2026-10-01 00:00:00+03
1350	151	124.33	2026-10-01 00:00:00+03
1351	152	124.67	2026-10-01 00:00:00+03
1352	153	125.00	2026-10-01 00:00:00+03
1353	154	125.33	2026-10-01 00:00:00+03
1354	155	125.67	2026-10-01 00:00:00+03
1355	156	126.00	2026-10-01 00:00:00+03
1356	157	126.33	2026-10-01 00:00:00+03
1357	158	126.67	2026-10-01 00:00:00+03
1358	159	127.00	2026-10-01 00:00:00+03
1359	160	127.33	2026-10-01 00:00:00+03
1360	161	127.67	2026-10-01 00:00:00+03
1361	162	128.00	2026-10-01 00:00:00+03
1362	163	128.33	2026-10-01 00:00:00+03
1363	164	128.67	2026-10-01 00:00:00+03
1364	165	129.00	2026-10-01 00:00:00+03
1365	166	129.33	2026-10-01 00:00:00+03
1366	167	129.67	2026-10-01 00:00:00+03
1367	168	130.00	2026-10-01 00:00:00+03
1368	169	130.33	2026-10-01 00:00:00+03
1369	170	130.67	2026-10-01 00:00:00+03
1370	171	131.00	2026-10-01 00:00:00+03
1371	172	131.33	2026-10-01 00:00:00+03
1372	173	131.67	2026-10-01 00:00:00+03
1373	174	132.00	2026-10-01 00:00:00+03
1374	175	132.33	2026-10-01 00:00:00+03
1375	176	132.67	2026-10-01 00:00:00+03
1376	177	133.00	2026-10-01 00:00:00+03
1377	178	133.33	2026-10-01 00:00:00+03
1378	179	133.67	2026-10-01 00:00:00+03
1379	180	134.00	2026-10-01 00:00:00+03
1380	181	134.33	2026-10-01 00:00:00+03
1381	182	134.67	2026-10-01 00:00:00+03
1382	183	135.00	2026-10-01 00:00:00+03
1383	184	135.33	2026-10-01 00:00:00+03
1384	185	135.67	2026-10-01 00:00:00+03
1385	186	136.00	2026-10-01 00:00:00+03
1386	187	136.33	2026-10-01 00:00:00+03
1387	188	136.67	2026-10-01 00:00:00+03
1388	189	137.00	2026-10-01 00:00:00+03
1389	190	137.33	2026-10-01 00:00:00+03
1390	191	137.67	2026-10-01 00:00:00+03
1391	192	138.00	2026-10-01 00:00:00+03
1392	193	138.33	2026-10-01 00:00:00+03
1393	194	138.67	2026-10-01 00:00:00+03
1394	195	139.00	2026-10-01 00:00:00+03
1395	196	139.33	2026-10-01 00:00:00+03
1396	197	139.67	2026-10-01 00:00:00+03
1397	198	140.00	2026-10-01 00:00:00+03
1398	199	140.33	2026-10-01 00:00:00+03
1399	200	140.67	2026-10-01 00:00:00+03
1400	201	141.00	2026-10-01 00:00:00+03
1401	202	141.33	2026-10-01 00:00:00+03
1402	203	141.67	2026-10-01 00:00:00+03
1403	204	142.00	2026-10-01 00:00:00+03
1404	205	142.33	2026-10-01 00:00:00+03
1405	206	142.67	2026-10-01 00:00:00+03
1406	207	143.00	2026-10-01 00:00:00+03
1407	208	143.33	2026-10-01 00:00:00+03
1408	209	143.67	2026-10-01 00:00:00+03
1409	210	144.00	2026-10-01 00:00:00+03
1410	211	144.33	2026-10-01 00:00:00+03
1411	212	144.67	2026-10-01 00:00:00+03
1412	213	145.00	2026-10-01 00:00:00+03
1413	214	145.33	2026-10-01 00:00:00+03
1414	215	145.67	2026-10-01 00:00:00+03
1415	216	146.00	2026-10-01 00:00:00+03
1416	217	146.33	2026-10-01 00:00:00+03
1417	218	146.67	2026-10-01 00:00:00+03
1418	219	147.00	2026-10-01 00:00:00+03
1419	220	147.33	2026-10-01 00:00:00+03
1420	221	147.67	2026-10-01 00:00:00+03
1421	222	148.00	2026-10-01 00:00:00+03
1422	223	148.33	2026-10-01 00:00:00+03
1423	224	148.67	2026-10-01 00:00:00+03
1424	225	149.00	2026-10-01 00:00:00+03
1425	226	149.33	2026-10-01 00:00:00+03
1426	227	149.67	2026-10-01 00:00:00+03
1427	228	150.00	2026-10-01 00:00:00+03
1428	229	150.33	2026-10-01 00:00:00+03
1429	230	150.67	2026-10-01 00:00:00+03
1430	231	151.00	2026-10-01 00:00:00+03
1431	232	151.33	2026-10-01 00:00:00+03
1432	233	151.67	2026-10-01 00:00:00+03
1433	234	152.00	2026-10-01 00:00:00+03
1434	235	152.33	2026-10-01 00:00:00+03
1435	236	152.67	2026-10-01 00:00:00+03
1436	237	153.00	2026-10-01 00:00:00+03
1437	238	153.33	2026-10-01 00:00:00+03
1438	239	153.67	2026-10-01 00:00:00+03
1439	240	154.00	2026-10-01 00:00:00+03
1440	241	154.33	2026-10-01 00:00:00+03
1441	242	154.67	2026-10-01 00:00:00+03
1442	243	155.00	2026-10-01 00:00:00+03
1443	244	155.33	2026-10-01 00:00:00+03
1444	245	155.67	2026-10-01 00:00:00+03
1445	246	156.00	2026-10-01 00:00:00+03
1446	247	156.33	2026-10-01 00:00:00+03
1447	248	156.67	2026-10-01 00:00:00+03
1448	249	157.00	2026-10-01 00:00:00+03
1449	250	157.33	2026-10-01 00:00:00+03
1450	251	157.67	2026-10-01 00:00:00+03
1451	252	158.00	2026-10-01 00:00:00+03
1452	253	158.33	2026-10-01 00:00:00+03
1453	254	158.67	2026-10-01 00:00:00+03
1454	255	159.00	2026-10-01 00:00:00+03
1455	256	159.33	2026-10-01 00:00:00+03
1456	257	159.67	2026-10-01 00:00:00+03
1457	258	160.00	2026-10-01 00:00:00+03
1458	259	160.33	2026-10-01 00:00:00+03
1459	260	160.67	2026-10-01 00:00:00+03
1460	261	161.00	2026-10-01 00:00:00+03
1461	262	161.33	2026-10-01 00:00:00+03
1462	263	161.67	2026-10-01 00:00:00+03
1463	264	162.00	2026-10-01 00:00:00+03
1464	265	162.33	2026-10-01 00:00:00+03
1465	266	162.67	2026-10-01 00:00:00+03
1466	267	163.00	2026-10-01 00:00:00+03
1467	268	163.33	2026-10-01 00:00:00+03
1468	269	163.67	2026-10-01 00:00:00+03
1469	270	164.00	2026-10-01 00:00:00+03
1470	271	164.33	2026-10-01 00:00:00+03
1471	272	164.67	2026-10-01 00:00:00+03
1472	273	165.00	2026-10-01 00:00:00+03
1473	274	165.33	2026-10-01 00:00:00+03
1474	275	165.67	2026-10-01 00:00:00+03
1475	276	166.00	2026-10-01 00:00:00+03
1476	277	166.33	2026-10-01 00:00:00+03
1477	278	166.67	2026-10-01 00:00:00+03
1478	279	167.00	2026-10-01 00:00:00+03
1479	280	167.33	2026-10-01 00:00:00+03
1480	281	167.67	2026-10-01 00:00:00+03
1481	282	168.00	2026-10-01 00:00:00+03
1482	283	168.33	2026-10-01 00:00:00+03
1483	284	168.67	2026-10-01 00:00:00+03
1484	285	169.00	2026-10-01 00:00:00+03
1485	286	169.33	2026-10-01 00:00:00+03
1486	287	169.67	2026-10-01 00:00:00+03
1487	288	170.00	2026-10-01 00:00:00+03
1488	289	170.33	2026-10-01 00:00:00+03
1489	290	170.67	2026-10-01 00:00:00+03
1490	291	171.00	2026-10-01 00:00:00+03
1491	292	171.33	2026-10-01 00:00:00+03
1492	293	171.67	2026-10-01 00:00:00+03
1493	294	172.00	2026-10-01 00:00:00+03
1494	295	172.33	2026-10-01 00:00:00+03
1495	296	172.67	2026-10-01 00:00:00+03
1496	297	173.00	2026-10-01 00:00:00+03
1497	298	173.33	2026-10-01 00:00:00+03
1498	299	173.67	2026-10-01 00:00:00+03
1499	300	174.00	2026-10-01 00:00:00+03
1500	301	174.33	2026-10-01 00:00:00+03
1501	302	174.67	2026-10-01 00:00:00+03
1502	303	175.00	2026-10-01 00:00:00+03
1503	304	175.33	2026-10-01 00:00:00+03
1504	305	175.67	2026-10-01 00:00:00+03
1505	306	176.00	2026-10-01 00:00:00+03
1506	307	176.33	2026-10-01 00:00:00+03
1507	308	176.67	2026-10-01 00:00:00+03
1508	309	177.00	2026-10-01 00:00:00+03
1509	310	177.33	2026-10-01 00:00:00+03
1510	311	177.67	2026-10-01 00:00:00+03
1511	312	178.00	2026-10-01 00:00:00+03
1512	313	178.33	2026-10-01 00:00:00+03
1513	314	178.67	2026-10-01 00:00:00+03
1514	315	179.00	2026-10-01 00:00:00+03
1515	316	179.33	2026-10-01 00:00:00+03
1516	317	179.67	2026-10-01 00:00:00+03
1517	318	180.00	2026-10-01 00:00:00+03
1518	319	180.33	2026-10-01 00:00:00+03
1519	320	180.67	2026-10-01 00:00:00+03
1520	321	181.00	2026-10-01 00:00:00+03
1521	322	181.33	2026-10-01 00:00:00+03
1522	323	181.67	2026-10-01 00:00:00+03
1523	324	182.00	2026-10-01 00:00:00+03
1524	325	182.33	2026-10-01 00:00:00+03
1525	326	182.67	2026-10-01 00:00:00+03
1526	327	183.00	2026-10-01 00:00:00+03
1527	328	183.33	2026-10-01 00:00:00+03
1528	329	183.67	2026-10-01 00:00:00+03
1529	330	184.00	2026-10-01 00:00:00+03
1530	331	184.33	2026-10-01 00:00:00+03
1531	332	184.67	2026-10-01 00:00:00+03
1532	333	185.00	2026-10-01 00:00:00+03
1533	334	185.33	2026-10-01 00:00:00+03
1534	335	185.67	2026-10-01 00:00:00+03
1535	336	186.00	2026-10-01 00:00:00+03
1536	337	186.33	2026-10-01 00:00:00+03
1537	338	186.67	2026-10-01 00:00:00+03
1538	339	187.00	2026-10-01 00:00:00+03
1539	340	187.33	2026-10-01 00:00:00+03
1540	341	187.67	2026-10-01 00:00:00+03
1541	342	188.00	2026-10-01 00:00:00+03
1542	343	188.33	2026-10-01 00:00:00+03
1543	344	188.67	2026-10-01 00:00:00+03
1544	345	189.00	2026-10-01 00:00:00+03
1545	346	189.33	2026-10-01 00:00:00+03
1546	347	189.67	2026-10-01 00:00:00+03
1547	348	190.00	2026-10-01 00:00:00+03
1548	349	190.33	2026-10-01 00:00:00+03
1549	350	190.67	2026-10-01 00:00:00+03
1550	351	191.00	2026-10-01 00:00:00+03
1551	352	191.33	2026-10-01 00:00:00+03
1552	353	191.67	2026-10-01 00:00:00+03
1553	354	192.00	2026-10-01 00:00:00+03
1554	355	192.33	2026-10-01 00:00:00+03
1555	356	192.67	2026-10-01 00:00:00+03
1556	357	193.00	2026-10-01 00:00:00+03
1557	358	193.33	2026-10-01 00:00:00+03
1558	359	193.67	2026-10-01 00:00:00+03
1559	360	194.00	2026-10-01 00:00:00+03
1560	361	194.33	2026-10-01 00:00:00+03
1561	362	194.67	2026-10-01 00:00:00+03
1562	363	195.00	2026-10-01 00:00:00+03
1563	364	195.33	2026-10-01 00:00:00+03
1564	365	195.67	2026-10-01 00:00:00+03
1565	366	196.00	2026-10-01 00:00:00+03
1566	367	196.33	2026-10-01 00:00:00+03
1567	368	196.67	2026-10-01 00:00:00+03
1568	369	197.00	2026-10-01 00:00:00+03
1569	370	197.33	2026-10-01 00:00:00+03
1570	371	197.67	2026-10-01 00:00:00+03
1571	372	198.00	2026-10-01 00:00:00+03
1572	373	198.33	2026-10-01 00:00:00+03
1573	374	198.67	2026-10-01 00:00:00+03
1574	375	199.00	2026-10-01 00:00:00+03
1575	376	199.33	2026-10-01 00:00:00+03
1576	377	199.67	2026-10-01 00:00:00+03
1577	378	200.00	2026-10-01 00:00:00+03
1578	379	200.33	2026-10-01 00:00:00+03
1579	380	200.67	2026-10-01 00:00:00+03
1580	381	201.00	2026-10-01 00:00:00+03
1581	382	201.33	2026-10-01 00:00:00+03
1582	383	201.67	2026-10-01 00:00:00+03
1583	384	202.00	2026-10-01 00:00:00+03
1584	385	202.33	2026-10-01 00:00:00+03
1585	386	202.67	2026-10-01 00:00:00+03
1586	387	203.00	2026-10-01 00:00:00+03
1587	388	203.33	2026-10-01 00:00:00+03
1588	389	203.67	2026-10-01 00:00:00+03
1589	390	204.00	2026-10-01 00:00:00+03
1590	391	204.33	2026-10-01 00:00:00+03
1591	392	204.67	2026-10-01 00:00:00+03
1592	393	205.00	2026-10-01 00:00:00+03
1593	394	205.33	2026-10-01 00:00:00+03
1594	395	205.67	2026-10-01 00:00:00+03
1595	396	206.00	2026-10-01 00:00:00+03
1596	397	206.33	2026-10-01 00:00:00+03
1597	398	206.67	2026-10-01 00:00:00+03
1598	399	207.00	2026-10-01 00:00:00+03
1599	400	207.33	2026-10-01 00:00:00+03
1600	401	207.67	2026-10-01 00:00:00+03
1601	402	208.00	2026-10-01 00:00:00+03
1602	403	208.33	2026-10-01 00:00:00+03
1603	404	208.67	2026-10-01 00:00:00+03
1604	405	209.00	2026-10-01 00:00:00+03
1605	406	209.33	2026-10-01 00:00:00+03
1606	407	209.67	2026-10-01 00:00:00+03
1607	408	210.00	2026-10-01 00:00:00+03
1608	409	210.33	2026-10-01 00:00:00+03
1609	410	210.67	2026-10-01 00:00:00+03
1610	411	211.00	2026-10-01 00:00:00+03
1611	412	211.33	2026-10-01 00:00:00+03
1612	413	211.67	2026-10-01 00:00:00+03
1613	414	212.00	2026-10-01 00:00:00+03
1614	415	212.33	2026-10-01 00:00:00+03
1615	416	212.67	2026-10-01 00:00:00+03
1616	417	213.00	2026-10-01 00:00:00+03
1617	418	213.33	2026-10-01 00:00:00+03
1618	419	213.67	2026-10-01 00:00:00+03
1619	420	214.00	2026-10-01 00:00:00+03
1620	421	214.33	2026-10-01 00:00:00+03
1621	422	214.67	2026-10-01 00:00:00+03
1622	423	215.00	2026-10-01 00:00:00+03
1623	424	215.33	2026-10-01 00:00:00+03
1624	425	215.67	2026-10-01 00:00:00+03
1625	426	216.00	2026-10-01 00:00:00+03
1626	427	216.33	2026-10-01 00:00:00+03
1627	428	216.67	2026-10-01 00:00:00+03
1628	429	217.00	2026-10-01 00:00:00+03
1629	430	217.33	2026-10-01 00:00:00+03
1630	431	217.67	2026-10-01 00:00:00+03
1631	432	218.00	2026-10-01 00:00:00+03
1632	433	218.33	2026-10-01 00:00:00+03
1633	434	218.67	2026-10-01 00:00:00+03
1634	435	219.00	2026-10-01 00:00:00+03
1635	436	219.33	2026-10-01 00:00:00+03
1636	437	219.67	2026-10-01 00:00:00+03
1637	438	220.00	2026-10-01 00:00:00+03
1638	439	220.33	2026-10-01 00:00:00+03
1639	440	220.67	2026-10-01 00:00:00+03
1640	441	221.00	2026-10-01 00:00:00+03
1641	442	221.33	2026-10-01 00:00:00+03
1642	443	221.67	2026-10-01 00:00:00+03
1643	444	222.00	2026-10-01 00:00:00+03
1644	445	222.33	2026-10-01 00:00:00+03
1645	446	222.67	2026-10-01 00:00:00+03
1646	447	223.00	2026-10-01 00:00:00+03
1647	448	223.33	2026-10-01 00:00:00+03
1648	449	223.67	2026-10-01 00:00:00+03
1649	450	224.00	2026-10-01 00:00:00+03
1650	451	224.33	2026-10-01 00:00:00+03
1651	452	224.67	2026-10-01 00:00:00+03
1652	453	225.00	2026-10-01 00:00:00+03
1653	454	225.33	2026-10-01 00:00:00+03
1654	455	225.67	2026-10-01 00:00:00+03
1655	456	226.00	2026-10-01 00:00:00+03
1656	457	226.33	2026-10-01 00:00:00+03
1657	458	226.67	2026-10-01 00:00:00+03
1658	459	227.00	2026-10-01 00:00:00+03
1659	460	227.33	2026-10-01 00:00:00+03
1660	461	227.67	2026-10-01 00:00:00+03
1661	462	228.00	2026-10-01 00:00:00+03
1662	463	228.33	2026-10-01 00:00:00+03
1663	464	228.67	2026-10-01 00:00:00+03
1664	465	229.00	2026-10-01 00:00:00+03
1665	466	229.33	2026-10-01 00:00:00+03
1666	467	229.67	2026-10-01 00:00:00+03
1667	468	230.00	2026-10-01 00:00:00+03
1668	469	230.33	2026-10-01 00:00:00+03
1669	470	230.67	2026-10-01 00:00:00+03
1670	471	231.00	2026-10-01 00:00:00+03
1671	472	231.33	2026-10-01 00:00:00+03
1672	473	231.67	2026-10-01 00:00:00+03
1673	474	232.00	2026-10-01 00:00:00+03
1674	475	232.33	2026-10-01 00:00:00+03
1675	476	232.67	2026-10-01 00:00:00+03
1676	477	233.00	2026-10-01 00:00:00+03
1677	478	233.33	2026-10-01 00:00:00+03
1678	479	233.67	2026-10-01 00:00:00+03
1679	480	234.00	2026-10-01 00:00:00+03
1680	481	234.33	2026-10-01 00:00:00+03
1681	482	234.67	2026-10-01 00:00:00+03
1682	483	235.00	2026-10-01 00:00:00+03
1683	484	235.33	2026-10-01 00:00:00+03
1684	485	235.67	2026-10-01 00:00:00+03
1685	486	236.00	2026-10-01 00:00:00+03
1686	487	236.33	2026-10-01 00:00:00+03
1687	488	236.67	2026-10-01 00:00:00+03
1688	489	237.00	2026-10-01 00:00:00+03
1689	490	237.33	2026-10-01 00:00:00+03
1690	491	237.67	2026-10-01 00:00:00+03
1691	492	238.00	2026-10-01 00:00:00+03
1692	493	238.33	2026-10-01 00:00:00+03
1693	494	238.67	2026-10-01 00:00:00+03
1694	495	239.00	2026-10-01 00:00:00+03
1695	496	239.33	2026-10-01 00:00:00+03
1696	497	239.67	2026-10-01 00:00:00+03
1697	498	240.00	2026-10-01 00:00:00+03
1698	499	240.33	2026-10-01 00:00:00+03
1699	500	240.67	2026-10-01 00:00:00+03
1700	501	241.00	2026-10-01 00:00:00+03
1701	502	241.33	2026-10-01 00:00:00+03
1702	503	241.67	2026-10-01 00:00:00+03
1703	504	242.00	2026-10-01 00:00:00+03
1704	505	242.33	2026-10-01 00:00:00+03
1705	506	242.67	2026-10-01 00:00:00+03
1706	507	243.00	2026-10-01 00:00:00+03
1707	508	243.33	2026-10-01 00:00:00+03
1708	509	243.67	2026-10-01 00:00:00+03
1709	510	244.00	2026-10-01 00:00:00+03
1710	511	244.33	2026-10-01 00:00:00+03
1711	512	244.67	2026-10-01 00:00:00+03
1712	513	245.00	2026-10-01 00:00:00+03
1713	514	245.33	2026-10-01 00:00:00+03
1714	515	245.67	2026-10-01 00:00:00+03
1715	516	246.00	2026-10-01 00:00:00+03
1716	517	246.33	2026-10-01 00:00:00+03
1717	518	246.67	2026-10-01 00:00:00+03
1718	519	247.00	2026-10-01 00:00:00+03
1719	520	247.33	2026-10-01 00:00:00+03
1720	521	247.67	2026-10-01 00:00:00+03
1721	522	248.00	2026-10-01 00:00:00+03
1722	523	248.33	2026-10-01 00:00:00+03
1723	524	248.67	2026-10-01 00:00:00+03
1724	525	249.00	2026-10-01 00:00:00+03
1725	526	249.33	2026-10-01 00:00:00+03
1726	527	249.67	2026-10-01 00:00:00+03
1727	528	250.00	2026-10-01 00:00:00+03
1728	529	250.33	2026-10-01 00:00:00+03
1729	530	250.67	2026-10-01 00:00:00+03
1730	531	251.00	2026-10-01 00:00:00+03
1731	532	251.33	2026-10-01 00:00:00+03
1732	533	251.67	2026-10-01 00:00:00+03
1733	534	252.00	2026-10-01 00:00:00+03
1734	535	252.33	2026-10-01 00:00:00+03
1735	536	252.67	2026-10-01 00:00:00+03
1736	537	253.00	2026-10-01 00:00:00+03
1737	538	253.33	2026-10-01 00:00:00+03
1738	539	253.67	2026-10-01 00:00:00+03
1739	540	254.00	2026-10-01 00:00:00+03
1740	541	254.33	2026-10-01 00:00:00+03
1741	542	254.67	2026-10-01 00:00:00+03
1742	543	255.00	2026-10-01 00:00:00+03
1743	544	255.33	2026-10-01 00:00:00+03
1744	545	255.67	2026-10-01 00:00:00+03
1745	546	256.00	2026-10-01 00:00:00+03
1746	547	256.33	2026-10-01 00:00:00+03
1747	548	256.67	2026-10-01 00:00:00+03
1748	549	257.00	2026-10-01 00:00:00+03
1749	550	257.33	2026-10-01 00:00:00+03
1750	551	257.67	2026-10-01 00:00:00+03
1751	552	258.00	2026-10-01 00:00:00+03
1752	553	258.33	2026-10-01 00:00:00+03
1753	554	258.67	2026-10-01 00:00:00+03
1754	555	259.00	2026-10-01 00:00:00+03
1755	556	259.33	2026-10-01 00:00:00+03
1756	557	259.67	2026-10-01 00:00:00+03
1757	558	260.00	2026-10-01 00:00:00+03
1758	559	260.33	2026-10-01 00:00:00+03
1759	560	260.67	2026-10-01 00:00:00+03
1760	561	261.00	2026-10-01 00:00:00+03
1761	562	261.33	2026-10-01 00:00:00+03
1762	563	261.67	2026-10-01 00:00:00+03
1763	564	262.00	2026-10-01 00:00:00+03
1764	565	262.33	2026-10-01 00:00:00+03
1765	566	262.67	2026-10-01 00:00:00+03
1766	567	263.00	2026-10-01 00:00:00+03
1767	568	263.33	2026-10-01 00:00:00+03
1768	569	263.67	2026-10-01 00:00:00+03
1769	570	264.00	2026-10-01 00:00:00+03
1770	571	264.33	2026-10-01 00:00:00+03
1771	572	264.67	2026-10-01 00:00:00+03
1772	573	265.00	2026-10-01 00:00:00+03
1773	574	265.33	2026-10-01 00:00:00+03
1774	575	265.67	2026-10-01 00:00:00+03
1775	576	266.00	2026-10-01 00:00:00+03
1776	577	266.33	2026-10-01 00:00:00+03
1777	578	266.67	2026-10-01 00:00:00+03
1778	579	267.00	2026-10-01 00:00:00+03
1779	580	267.33	2026-10-01 00:00:00+03
1780	581	267.67	2026-10-01 00:00:00+03
1781	582	268.00	2026-10-01 00:00:00+03
1782	583	268.33	2026-10-01 00:00:00+03
1783	584	268.67	2026-10-01 00:00:00+03
1784	585	269.00	2026-10-01 00:00:00+03
1785	586	269.33	2026-10-01 00:00:00+03
1786	587	269.67	2026-10-01 00:00:00+03
1787	588	270.00	2026-10-01 00:00:00+03
1788	589	270.33	2026-10-01 00:00:00+03
1789	590	270.67	2026-10-01 00:00:00+03
1790	591	271.00	2026-10-01 00:00:00+03
1791	592	271.33	2026-10-01 00:00:00+03
1792	593	271.67	2026-10-01 00:00:00+03
1793	594	272.00	2026-10-01 00:00:00+03
1794	595	272.33	2026-10-01 00:00:00+03
1795	596	272.67	2026-10-01 00:00:00+03
1796	597	273.00	2026-10-01 00:00:00+03
1797	598	273.33	2026-10-01 00:00:00+03
1798	599	273.67	2026-10-01 00:00:00+03
1799	600	274.00	2026-10-01 00:00:00+03
1800	601	274.33	2026-10-01 00:00:00+03
1801	602	274.67	2026-10-01 00:00:00+03
1802	603	275.00	2026-10-01 00:00:00+03
1803	604	275.33	2026-10-01 00:00:00+03
1804	605	275.67	2026-10-01 00:00:00+03
1805	606	276.00	2026-10-01 00:00:00+03
1806	607	276.33	2026-10-01 00:00:00+03
1807	608	276.67	2026-10-01 00:00:00+03
1808	609	277.00	2026-10-01 00:00:00+03
1809	610	277.33	2026-10-01 00:00:00+03
1810	611	277.67	2026-10-01 00:00:00+03
1811	612	278.00	2026-10-01 00:00:00+03
1812	613	278.33	2026-10-01 00:00:00+03
1813	614	278.67	2026-10-01 00:00:00+03
1814	615	279.00	2026-10-01 00:00:00+03
1815	616	279.33	2026-10-01 00:00:00+03
1816	617	279.67	2026-10-01 00:00:00+03
1817	618	280.00	2026-10-01 00:00:00+03
1818	619	280.33	2026-10-01 00:00:00+03
1819	620	280.67	2026-10-01 00:00:00+03
1820	621	281.00	2026-10-01 00:00:00+03
1821	622	281.33	2026-10-01 00:00:00+03
1822	623	281.67	2026-10-01 00:00:00+03
1823	624	282.00	2026-10-01 00:00:00+03
1824	625	282.33	2026-10-01 00:00:00+03
1825	626	282.67	2026-10-01 00:00:00+03
1826	627	283.00	2026-10-01 00:00:00+03
1827	628	283.33	2026-10-01 00:00:00+03
1828	629	283.67	2026-10-01 00:00:00+03
1829	630	284.00	2026-10-01 00:00:00+03
1830	631	284.33	2026-10-01 00:00:00+03
1831	632	284.67	2026-10-01 00:00:00+03
1832	633	285.00	2026-10-01 00:00:00+03
1833	634	285.33	2026-10-01 00:00:00+03
1834	635	285.67	2026-10-01 00:00:00+03
1835	636	286.00	2026-10-01 00:00:00+03
1836	637	286.33	2026-10-01 00:00:00+03
1837	638	286.67	2026-10-01 00:00:00+03
1838	639	287.00	2026-10-01 00:00:00+03
1839	640	287.33	2026-10-01 00:00:00+03
1840	641	287.67	2026-10-01 00:00:00+03
1841	642	288.00	2026-10-01 00:00:00+03
1842	643	288.33	2026-10-01 00:00:00+03
1843	644	288.67	2026-10-01 00:00:00+03
1844	645	289.00	2026-10-01 00:00:00+03
1845	646	289.33	2026-10-01 00:00:00+03
1846	647	289.67	2026-10-01 00:00:00+03
1847	648	290.00	2026-10-01 00:00:00+03
1848	649	290.33	2026-10-01 00:00:00+03
1849	650	290.67	2026-10-01 00:00:00+03
1850	651	291.00	2026-10-01 00:00:00+03
1851	652	291.33	2026-10-01 00:00:00+03
1852	653	291.67	2026-10-01 00:00:00+03
1853	654	292.00	2026-10-01 00:00:00+03
1854	655	292.33	2026-10-01 00:00:00+03
1855	656	292.67	2026-10-01 00:00:00+03
1856	657	293.00	2026-10-01 00:00:00+03
1857	658	293.33	2026-10-01 00:00:00+03
1858	659	293.67	2026-10-01 00:00:00+03
1859	660	294.00	2026-10-01 00:00:00+03
1860	661	294.33	2026-10-01 00:00:00+03
1861	662	294.67	2026-10-01 00:00:00+03
1862	663	295.00	2026-10-01 00:00:00+03
1863	664	295.33	2026-10-01 00:00:00+03
1864	665	295.67	2026-10-01 00:00:00+03
1865	666	296.00	2026-10-01 00:00:00+03
1866	667	296.33	2026-10-01 00:00:00+03
1867	668	296.67	2026-10-01 00:00:00+03
1868	669	297.00	2026-10-01 00:00:00+03
1869	670	297.33	2026-10-01 00:00:00+03
1870	671	297.67	2026-10-01 00:00:00+03
1871	672	298.00	2026-10-01 00:00:00+03
1872	673	298.33	2026-10-01 00:00:00+03
1873	674	298.67	2026-10-01 00:00:00+03
1874	675	299.00	2026-10-01 00:00:00+03
1875	676	299.33	2026-10-01 00:00:00+03
1876	677	299.67	2026-10-01 00:00:00+03
1877	678	300.00	2026-10-01 00:00:00+03
1878	679	300.33	2026-10-01 00:00:00+03
1879	680	300.67	2026-10-01 00:00:00+03
1880	681	301.00	2026-10-01 00:00:00+03
1881	682	301.33	2026-10-01 00:00:00+03
1882	683	301.67	2026-10-01 00:00:00+03
1883	684	302.00	2026-10-01 00:00:00+03
1884	685	302.33	2026-10-01 00:00:00+03
1885	686	302.67	2026-10-01 00:00:00+03
1886	687	303.00	2026-10-01 00:00:00+03
1887	688	303.33	2026-10-01 00:00:00+03
1888	689	303.67	2026-10-01 00:00:00+03
1889	690	304.00	2026-10-01 00:00:00+03
1890	691	304.33	2026-10-01 00:00:00+03
1891	692	304.67	2026-10-01 00:00:00+03
1892	693	305.00	2026-10-01 00:00:00+03
1893	694	305.33	2026-10-01 00:00:00+03
1894	695	305.67	2026-10-01 00:00:00+03
1895	696	306.00	2026-10-01 00:00:00+03
1896	697	306.33	2026-10-01 00:00:00+03
1897	698	306.67	2026-10-01 00:00:00+03
1898	699	307.00	2026-10-01 00:00:00+03
1899	700	307.33	2026-10-01 00:00:00+03
1900	701	307.67	2026-10-01 00:00:00+03
1901	702	308.00	2026-10-01 00:00:00+03
1902	703	308.33	2026-10-01 00:00:00+03
1903	704	308.67	2026-10-01 00:00:00+03
1904	705	309.00	2026-10-01 00:00:00+03
1905	706	309.33	2026-10-01 00:00:00+03
1906	707	309.67	2026-10-01 00:00:00+03
1907	708	310.00	2026-10-01 00:00:00+03
1908	709	310.33	2026-10-01 00:00:00+03
1909	710	310.67	2026-10-01 00:00:00+03
1910	711	311.00	2026-10-01 00:00:00+03
1911	712	311.33	2026-10-01 00:00:00+03
1912	713	311.67	2026-10-01 00:00:00+03
1913	714	312.00	2026-10-01 00:00:00+03
1914	715	312.33	2026-10-01 00:00:00+03
1915	716	312.67	2026-10-01 00:00:00+03
1916	717	313.00	2026-10-01 00:00:00+03
1917	718	313.33	2026-10-01 00:00:00+03
1918	719	313.67	2026-10-01 00:00:00+03
1919	720	314.00	2026-10-01 00:00:00+03
1920	721	314.33	2026-10-01 00:00:00+03
1921	722	314.67	2026-10-01 00:00:00+03
1922	723	315.00	2026-10-01 00:00:00+03
1923	724	315.33	2026-10-01 00:00:00+03
1924	725	315.67	2026-10-01 00:00:00+03
1925	726	316.00	2026-10-01 00:00:00+03
1926	727	316.33	2026-10-01 00:00:00+03
1927	728	316.67	2026-10-01 00:00:00+03
1928	729	317.00	2026-10-01 00:00:00+03
1929	730	317.33	2026-10-01 00:00:00+03
1930	731	317.67	2026-10-01 00:00:00+03
1931	732	318.00	2026-10-01 00:00:00+03
1932	733	318.33	2026-10-01 00:00:00+03
1933	734	318.67	2026-10-01 00:00:00+03
1934	735	319.00	2026-10-01 00:00:00+03
1935	736	319.33	2026-10-01 00:00:00+03
1936	737	319.67	2026-10-01 00:00:00+03
1937	738	320.00	2026-10-01 00:00:00+03
1938	739	320.33	2026-10-01 00:00:00+03
1939	740	320.67	2026-10-01 00:00:00+03
1940	741	321.00	2026-10-01 00:00:00+03
1941	742	321.33	2026-10-01 00:00:00+03
1942	743	321.67	2026-10-01 00:00:00+03
1943	744	322.00	2026-10-01 00:00:00+03
1944	745	322.33	2026-10-01 00:00:00+03
1945	746	322.67	2026-10-01 00:00:00+03
1946	747	323.00	2026-10-01 00:00:00+03
1947	748	323.33	2026-10-01 00:00:00+03
1948	749	323.67	2026-10-01 00:00:00+03
1949	750	324.00	2026-10-01 00:00:00+03
1950	751	324.33	2026-10-01 00:00:00+03
1951	752	324.67	2026-10-01 00:00:00+03
1952	753	325.00	2026-10-01 00:00:00+03
1953	754	325.33	2026-10-01 00:00:00+03
1954	755	0.00	2026-10-01 00:00:00+03
1955	756	0.33	2026-10-01 00:00:00+03
1956	757	0.67	2026-10-01 00:00:00+03
1957	758	1.00	2026-10-01 00:00:00+03
1958	759	1.33	2026-10-01 00:00:00+03
1959	760	1.67	2026-10-01 00:00:00+03
1960	761	2.00	2026-10-01 00:00:00+03
1961	762	2.33	2026-10-01 00:00:00+03
1962	763	2.67	2026-10-01 00:00:00+03
1963	764	3.00	2026-10-01 00:00:00+03
1964	765	3.33	2026-10-01 00:00:00+03
1965	766	3.67	2026-10-01 00:00:00+03
1966	767	4.00	2026-10-01 00:00:00+03
1967	768	4.33	2026-10-01 00:00:00+03
1968	769	4.67	2026-10-01 00:00:00+03
1969	770	5.00	2026-10-01 00:00:00+03
1970	771	5.33	2026-10-01 00:00:00+03
1971	772	5.67	2026-10-01 00:00:00+03
1972	773	6.00	2026-10-01 00:00:00+03
1973	774	6.33	2026-10-01 00:00:00+03
1974	775	6.67	2026-10-01 00:00:00+03
1975	776	7.00	2026-10-01 00:00:00+03
1976	777	7.33	2026-10-01 00:00:00+03
1977	778	7.67	2026-10-01 00:00:00+03
1978	779	8.00	2026-10-01 00:00:00+03
1979	780	8.33	2026-10-01 00:00:00+03
1980	781	8.67	2026-10-01 00:00:00+03
1981	782	9.00	2026-10-01 00:00:00+03
1982	783	9.33	2026-10-01 00:00:00+03
1983	784	9.67	2026-10-01 00:00:00+03
1984	785	10.00	2026-10-01 00:00:00+03
1985	786	10.33	2026-10-01 00:00:00+03
1986	787	10.67	2026-10-01 00:00:00+03
1987	788	11.00	2026-10-01 00:00:00+03
1988	789	11.33	2026-10-01 00:00:00+03
1989	790	11.67	2026-10-01 00:00:00+03
1990	791	12.00	2026-10-01 00:00:00+03
1991	792	12.33	2026-10-01 00:00:00+03
1992	793	12.67	2026-10-01 00:00:00+03
1993	794	13.00	2026-10-01 00:00:00+03
1994	795	13.33	2026-10-01 00:00:00+03
1995	796	13.67	2026-10-01 00:00:00+03
1996	797	14.00	2026-10-01 00:00:00+03
1997	798	14.33	2026-10-01 00:00:00+03
1998	799	14.67	2026-10-01 00:00:00+03
1999	800	15.00	2026-10-01 00:00:00+03
2000	801	15.33	2026-10-01 00:00:00+03
2001	802	15.67	2026-10-01 00:00:00+03
2002	803	16.00	2026-10-01 00:00:00+03
2003	804	16.33	2026-10-01 00:00:00+03
2004	805	16.67	2026-10-01 00:00:00+03
2005	806	17.00	2026-10-01 00:00:00+03
2006	807	17.33	2026-10-01 00:00:00+03
2007	808	17.67	2026-10-01 00:00:00+03
2008	809	18.00	2026-10-01 00:00:00+03
2009	810	18.33	2026-10-01 00:00:00+03
2010	811	18.67	2026-10-01 00:00:00+03
2011	812	19.00	2026-10-01 00:00:00+03
2012	813	19.33	2026-10-01 00:00:00+03
2013	814	19.67	2026-10-01 00:00:00+03
2014	815	20.00	2026-10-01 00:00:00+03
2015	816	20.33	2026-10-01 00:00:00+03
2016	817	20.67	2026-10-01 00:00:00+03
2017	818	21.00	2026-10-01 00:00:00+03
2018	819	21.33	2026-10-01 00:00:00+03
2019	820	21.67	2026-10-01 00:00:00+03
2020	821	22.00	2026-10-01 00:00:00+03
2021	822	22.33	2026-10-01 00:00:00+03
2022	823	22.67	2026-10-01 00:00:00+03
2023	824	23.00	2026-10-01 00:00:00+03
2024	825	23.33	2026-10-01 00:00:00+03
2025	826	23.67	2026-10-01 00:00:00+03
2026	827	24.00	2026-10-01 00:00:00+03
2027	828	24.33	2026-10-01 00:00:00+03
2028	829	24.67	2026-10-01 00:00:00+03
2029	830	25.00	2026-10-01 00:00:00+03
2030	831	25.33	2026-10-01 00:00:00+03
2031	832	25.67	2026-10-01 00:00:00+03
2032	833	26.00	2026-10-01 00:00:00+03
2033	834	26.33	2026-10-01 00:00:00+03
2034	835	26.67	2026-10-01 00:00:00+03
2035	836	27.00	2026-10-01 00:00:00+03
2036	837	27.33	2026-10-01 00:00:00+03
2037	838	27.67	2026-10-01 00:00:00+03
2038	839	28.00	2026-10-01 00:00:00+03
2039	840	28.33	2026-10-01 00:00:00+03
2040	841	28.67	2026-10-01 00:00:00+03
2041	842	29.00	2026-10-01 00:00:00+03
2042	843	29.33	2026-10-01 00:00:00+03
2043	844	29.67	2026-10-01 00:00:00+03
2044	845	30.00	2026-10-01 00:00:00+03
2045	846	30.33	2026-10-01 00:00:00+03
2046	847	30.67	2026-10-01 00:00:00+03
2047	848	31.00	2026-10-01 00:00:00+03
2048	849	31.33	2026-10-01 00:00:00+03
2049	850	31.67	2026-10-01 00:00:00+03
2050	851	32.00	2026-10-01 00:00:00+03
2051	852	32.33	2026-10-01 00:00:00+03
2052	853	32.67	2026-10-01 00:00:00+03
2053	854	33.00	2026-10-01 00:00:00+03
2054	855	33.33	2026-10-01 00:00:00+03
2055	856	33.67	2026-10-01 00:00:00+03
2056	857	34.00	2026-10-01 00:00:00+03
2057	858	34.33	2026-10-01 00:00:00+03
2058	859	34.67	2026-10-01 00:00:00+03
2059	860	35.00	2026-10-01 00:00:00+03
2060	861	35.33	2026-10-01 00:00:00+03
2061	862	35.67	2026-10-01 00:00:00+03
2062	863	36.00	2026-10-01 00:00:00+03
2063	864	36.33	2026-10-01 00:00:00+03
2064	865	36.67	2026-10-01 00:00:00+03
2065	866	37.00	2026-10-01 00:00:00+03
2066	867	37.33	2026-10-01 00:00:00+03
2067	868	37.67	2026-10-01 00:00:00+03
2068	869	38.00	2026-10-01 00:00:00+03
2069	870	38.33	2026-10-01 00:00:00+03
2070	871	38.67	2026-10-01 00:00:00+03
2071	872	39.00	2026-10-01 00:00:00+03
2072	873	39.33	2026-10-01 00:00:00+03
2073	874	39.67	2026-10-01 00:00:00+03
2074	875	40.00	2026-10-01 00:00:00+03
2075	876	40.33	2026-10-01 00:00:00+03
2076	877	40.67	2026-10-01 00:00:00+03
2077	878	41.00	2026-10-01 00:00:00+03
2078	879	41.33	2026-10-01 00:00:00+03
2079	880	41.67	2026-10-01 00:00:00+03
2080	881	42.00	2026-10-01 00:00:00+03
2081	882	42.33	2026-10-01 00:00:00+03
2082	883	42.67	2026-10-01 00:00:00+03
2083	884	43.00	2026-10-01 00:00:00+03
2084	885	43.33	2026-10-01 00:00:00+03
2085	886	43.67	2026-10-01 00:00:00+03
2086	887	44.00	2026-10-01 00:00:00+03
2087	888	44.33	2026-10-01 00:00:00+03
2088	889	44.67	2026-10-01 00:00:00+03
2089	890	45.00	2026-10-01 00:00:00+03
2090	891	45.33	2026-10-01 00:00:00+03
2091	892	45.67	2026-10-01 00:00:00+03
2092	893	46.00	2026-10-01 00:00:00+03
2093	894	46.33	2026-10-01 00:00:00+03
2094	895	46.67	2026-10-01 00:00:00+03
2095	896	47.00	2026-10-01 00:00:00+03
2096	897	47.33	2026-10-01 00:00:00+03
2097	898	47.67	2026-10-01 00:00:00+03
2098	899	48.00	2026-10-01 00:00:00+03
2099	900	48.33	2026-10-01 00:00:00+03
2100	901	48.67	2026-10-01 00:00:00+03
2101	902	49.00	2026-10-01 00:00:00+03
2102	903	49.33	2026-10-01 00:00:00+03
2103	904	49.67	2026-10-01 00:00:00+03
2104	905	50.00	2026-10-01 00:00:00+03
2105	906	50.33	2026-10-01 00:00:00+03
2106	907	50.67	2026-10-01 00:00:00+03
2107	908	51.00	2026-10-01 00:00:00+03
2108	909	51.33	2026-10-01 00:00:00+03
2109	910	51.67	2026-10-01 00:00:00+03
2110	911	52.00	2026-10-01 00:00:00+03
2111	912	52.33	2026-10-01 00:00:00+03
2112	913	52.67	2026-10-01 00:00:00+03
2113	914	53.00	2026-10-01 00:00:00+03
2114	915	53.33	2026-10-01 00:00:00+03
2115	916	53.67	2026-10-01 00:00:00+03
2116	917	54.00	2026-10-01 00:00:00+03
2117	918	54.33	2026-10-01 00:00:00+03
2118	919	54.67	2026-10-01 00:00:00+03
2119	920	55.00	2026-10-01 00:00:00+03
2120	921	55.33	2026-10-01 00:00:00+03
2121	922	55.67	2026-10-01 00:00:00+03
2122	923	56.00	2026-10-01 00:00:00+03
2123	924	56.33	2026-10-01 00:00:00+03
2124	925	56.67	2026-10-01 00:00:00+03
2125	926	57.00	2026-10-01 00:00:00+03
2126	927	57.33	2026-10-01 00:00:00+03
2127	928	57.67	2026-10-01 00:00:00+03
2128	929	58.00	2026-10-01 00:00:00+03
2129	930	58.33	2026-10-01 00:00:00+03
2130	931	58.67	2026-10-01 00:00:00+03
2131	932	59.00	2026-10-01 00:00:00+03
2132	933	59.33	2026-10-01 00:00:00+03
2133	934	59.67	2026-10-01 00:00:00+03
2134	935	60.00	2026-10-01 00:00:00+03
2135	936	60.33	2026-10-01 00:00:00+03
2136	937	60.67	2026-10-01 00:00:00+03
2137	938	61.00	2026-10-01 00:00:00+03
2138	939	61.33	2026-10-01 00:00:00+03
2139	940	61.67	2026-10-01 00:00:00+03
2140	941	62.00	2026-10-01 00:00:00+03
2141	942	62.33	2026-10-01 00:00:00+03
2142	943	62.67	2026-10-01 00:00:00+03
2143	944	63.00	2026-10-01 00:00:00+03
2144	945	63.33	2026-10-01 00:00:00+03
2145	946	63.67	2026-10-01 00:00:00+03
2146	947	64.00	2026-10-01 00:00:00+03
2147	948	64.33	2026-10-01 00:00:00+03
2148	949	64.67	2026-10-01 00:00:00+03
2149	950	65.00	2026-10-01 00:00:00+03
2150	951	65.33	2026-10-01 00:00:00+03
2151	952	65.67	2026-10-01 00:00:00+03
2152	953	66.00	2026-10-01 00:00:00+03
2153	954	66.33	2026-10-01 00:00:00+03
2154	955	66.67	2026-10-01 00:00:00+03
2155	956	67.00	2026-10-01 00:00:00+03
2156	957	67.33	2026-10-01 00:00:00+03
2157	958	67.67	2026-10-01 00:00:00+03
2158	959	68.00	2026-10-01 00:00:00+03
2159	960	68.33	2026-10-01 00:00:00+03
2160	961	68.67	2026-10-01 00:00:00+03
2161	962	69.00	2026-10-01 00:00:00+03
2162	963	69.33	2026-10-01 00:00:00+03
2163	964	69.67	2026-10-01 00:00:00+03
2164	965	70.00	2026-10-01 00:00:00+03
2165	966	70.33	2026-10-01 00:00:00+03
2166	967	70.67	2026-10-01 00:00:00+03
2167	968	71.00	2026-10-01 00:00:00+03
2168	969	71.33	2026-10-01 00:00:00+03
2169	970	71.67	2026-10-01 00:00:00+03
2170	971	72.00	2026-10-01 00:00:00+03
2171	972	72.33	2026-10-01 00:00:00+03
2172	973	72.67	2026-10-01 00:00:00+03
2173	974	73.00	2026-10-01 00:00:00+03
2174	975	73.33	2026-10-01 00:00:00+03
2175	976	73.67	2026-10-01 00:00:00+03
2176	977	74.00	2026-10-01 00:00:00+03
2177	978	74.33	2026-10-01 00:00:00+03
2178	979	74.67	2026-10-01 00:00:00+03
2179	980	75.00	2026-10-01 00:00:00+03
2180	981	75.33	2026-10-01 00:00:00+03
2181	982	75.67	2026-10-01 00:00:00+03
2182	983	76.00	2026-10-01 00:00:00+03
2183	984	76.33	2026-10-01 00:00:00+03
2184	985	76.67	2026-10-01 00:00:00+03
2185	986	77.00	2026-10-01 00:00:00+03
2186	987	77.33	2026-10-01 00:00:00+03
2187	988	77.67	2026-10-01 00:00:00+03
2188	989	78.00	2026-10-01 00:00:00+03
2189	990	78.33	2026-10-01 00:00:00+03
2190	991	78.67	2026-10-01 00:00:00+03
2191	992	79.00	2026-10-01 00:00:00+03
2192	993	79.33	2026-10-01 00:00:00+03
2193	994	79.67	2026-10-01 00:00:00+03
2194	995	80.00	2026-10-01 00:00:00+03
2195	996	80.33	2026-10-01 00:00:00+03
2196	997	80.67	2026-10-01 00:00:00+03
2197	998	81.00	2026-10-01 00:00:00+03
2198	999	81.33	2026-10-01 00:00:00+03
2199	1000	81.67	2026-10-01 00:00:00+03
2200	1001	82.00	2026-10-01 00:00:00+03
2201	1002	82.33	2026-10-01 00:00:00+03
2202	1003	82.67	2026-10-01 00:00:00+03
2203	1004	83.00	2026-10-01 00:00:00+03
2204	1005	83.33	2026-10-01 00:00:00+03
2205	1006	83.67	2026-10-01 00:00:00+03
2206	1007	84.00	2026-10-01 00:00:00+03
2207	1008	84.33	2026-10-01 00:00:00+03
2208	1009	84.67	2026-10-01 00:00:00+03
2209	1010	85.00	2026-10-01 00:00:00+03
2210	1011	85.33	2026-10-01 00:00:00+03
2211	1012	85.67	2026-10-01 00:00:00+03
2212	1013	86.00	2026-10-01 00:00:00+03
2213	1014	86.33	2026-10-01 00:00:00+03
2214	1015	86.67	2026-10-01 00:00:00+03
2215	1016	87.00	2026-10-01 00:00:00+03
2216	1017	87.33	2026-10-01 00:00:00+03
2217	1018	87.67	2026-10-01 00:00:00+03
2218	1019	88.00	2026-10-01 00:00:00+03
2219	1020	88.33	2026-10-01 00:00:00+03
2220	1021	88.67	2026-10-01 00:00:00+03
2221	1022	89.00	2026-10-01 00:00:00+03
2222	1023	89.33	2026-10-01 00:00:00+03
2223	1024	89.67	2026-10-01 00:00:00+03
2224	1025	90.00	2026-10-01 00:00:00+03
2225	1026	90.33	2026-10-01 00:00:00+03
2226	1027	90.67	2026-10-01 00:00:00+03
2227	1028	91.00	2026-10-01 00:00:00+03
2228	1029	91.33	2026-10-01 00:00:00+03
2229	1030	91.67	2026-10-01 00:00:00+03
2230	1031	92.00	2026-10-01 00:00:00+03
2231	1032	92.33	2026-10-01 00:00:00+03
2232	1033	92.67	2026-10-01 00:00:00+03
2233	1034	93.00	2026-10-01 00:00:00+03
2234	1035	93.33	2026-10-01 00:00:00+03
2235	1036	93.67	2026-10-01 00:00:00+03
2236	1037	94.00	2026-10-01 00:00:00+03
2237	1038	94.33	2026-10-01 00:00:00+03
2238	1039	94.67	2026-10-01 00:00:00+03
2239	1040	95.00	2026-10-01 00:00:00+03
2240	1041	95.33	2026-10-01 00:00:00+03
2241	1042	95.67	2026-10-01 00:00:00+03
2242	1043	96.00	2026-10-01 00:00:00+03
2243	1044	96.33	2026-10-01 00:00:00+03
2244	1045	96.67	2026-10-01 00:00:00+03
2245	1046	97.00	2026-10-01 00:00:00+03
2246	1047	97.33	2026-10-01 00:00:00+03
2247	1048	97.67	2026-10-01 00:00:00+03
2248	1049	98.00	2026-10-01 00:00:00+03
2249	1050	98.33	2026-10-01 00:00:00+03
2250	1051	98.67	2026-10-01 00:00:00+03
2251	1052	99.00	2026-10-01 00:00:00+03
2252	1053	99.33	2026-10-01 00:00:00+03
2253	1054	99.67	2026-10-01 00:00:00+03
2254	1055	100.00	2026-10-01 00:00:00+03
2255	1056	100.33	2026-10-01 00:00:00+03
2256	1057	100.67	2026-10-01 00:00:00+03
2257	1058	101.00	2026-10-01 00:00:00+03
2258	1059	101.33	2026-10-01 00:00:00+03
2259	1060	101.67	2026-10-01 00:00:00+03
2260	1061	102.00	2026-10-01 00:00:00+03
2261	1062	102.33	2026-10-01 00:00:00+03
2262	1063	102.67	2026-10-01 00:00:00+03
2263	1064	103.00	2026-10-01 00:00:00+03
2264	1065	103.33	2026-10-01 00:00:00+03
2265	1066	103.67	2026-10-01 00:00:00+03
2266	1067	104.00	2026-10-01 00:00:00+03
2267	1068	104.33	2026-10-01 00:00:00+03
2268	1069	104.67	2026-10-01 00:00:00+03
2269	1070	105.00	2026-10-01 00:00:00+03
2270	1071	105.33	2026-10-01 00:00:00+03
2271	1072	105.67	2026-10-01 00:00:00+03
2272	1073	106.00	2026-10-01 00:00:00+03
2273	1074	106.33	2026-10-01 00:00:00+03
2274	1075	106.67	2026-10-01 00:00:00+03
2275	1076	107.00	2026-10-01 00:00:00+03
2276	1077	107.33	2026-10-01 00:00:00+03
2277	1078	107.67	2026-10-01 00:00:00+03
2278	1079	108.00	2026-10-01 00:00:00+03
2279	1080	108.33	2026-10-01 00:00:00+03
2280	1081	108.67	2026-10-01 00:00:00+03
2281	1082	109.00	2026-10-01 00:00:00+03
2282	1083	109.33	2026-10-01 00:00:00+03
2283	1084	109.67	2026-10-01 00:00:00+03
2284	1085	110.00	2026-10-01 00:00:00+03
2285	1086	110.33	2026-10-01 00:00:00+03
2286	1087	110.67	2026-10-01 00:00:00+03
2287	1088	111.00	2026-10-01 00:00:00+03
2288	1089	111.33	2026-10-01 00:00:00+03
2289	1090	111.67	2026-10-01 00:00:00+03
2290	1091	112.00	2026-10-01 00:00:00+03
2291	1092	112.33	2026-10-01 00:00:00+03
2292	1093	112.67	2026-10-01 00:00:00+03
2293	1094	113.00	2026-10-01 00:00:00+03
2294	1095	113.33	2026-10-01 00:00:00+03
2295	1096	113.67	2026-10-01 00:00:00+03
2296	1097	114.00	2026-10-01 00:00:00+03
2297	1098	114.33	2026-10-01 00:00:00+03
2298	1099	114.67	2026-10-01 00:00:00+03
2299	1100	115.00	2026-10-01 00:00:00+03
2300	1101	115.33	2026-10-01 00:00:00+03
2301	1102	115.67	2026-10-01 00:00:00+03
2302	1103	116.00	2026-10-01 00:00:00+03
2303	1104	116.33	2026-10-01 00:00:00+03
2304	1105	116.67	2026-10-01 00:00:00+03
2305	1106	117.00	2026-10-01 00:00:00+03
2306	1107	117.33	2026-10-01 00:00:00+03
2307	1108	117.67	2026-10-01 00:00:00+03
2308	1109	118.00	2026-10-01 00:00:00+03
2309	1110	118.33	2026-10-01 00:00:00+03
2310	1111	118.67	2026-10-01 00:00:00+03
2311	1112	119.00	2026-10-01 00:00:00+03
2312	1113	119.33	2026-10-01 00:00:00+03
2313	1114	119.67	2026-10-01 00:00:00+03
2314	1115	120.00	2026-10-01 00:00:00+03
2315	1116	120.33	2026-10-01 00:00:00+03
2316	1117	120.67	2026-10-01 00:00:00+03
2317	1118	121.00	2026-10-01 00:00:00+03
2318	1119	121.33	2026-10-01 00:00:00+03
2319	1120	121.67	2026-10-01 00:00:00+03
2320	1121	122.00	2026-10-01 00:00:00+03
2321	1122	122.33	2026-10-01 00:00:00+03
2322	1123	122.67	2026-10-01 00:00:00+03
2323	1124	123.00	2026-10-01 00:00:00+03
2324	1125	123.33	2026-10-01 00:00:00+03
2325	1126	123.67	2026-10-01 00:00:00+03
2326	1127	124.00	2026-10-01 00:00:00+03
2327	1128	124.33	2026-10-01 00:00:00+03
2328	1129	124.67	2026-10-01 00:00:00+03
2329	1130	125.00	2026-10-01 00:00:00+03
2330	1131	125.33	2026-10-01 00:00:00+03
2331	1132	125.67	2026-10-01 00:00:00+03
2332	1133	126.00	2026-10-01 00:00:00+03
2333	1134	126.33	2026-10-01 00:00:00+03
2334	1135	126.67	2026-10-01 00:00:00+03
2335	1136	127.00	2026-10-01 00:00:00+03
2336	1137	127.33	2026-10-01 00:00:00+03
2337	1138	127.67	2026-10-01 00:00:00+03
2338	1139	128.00	2026-10-01 00:00:00+03
2339	1140	128.33	2026-10-01 00:00:00+03
2340	1141	128.67	2026-10-01 00:00:00+03
2341	1142	129.00	2026-10-01 00:00:00+03
2342	1143	129.33	2026-10-01 00:00:00+03
2343	1144	129.67	2026-10-01 00:00:00+03
2344	1145	130.00	2026-10-01 00:00:00+03
2345	1146	130.33	2026-10-01 00:00:00+03
2346	1147	130.67	2026-10-01 00:00:00+03
2347	1148	131.00	2026-10-01 00:00:00+03
2348	1149	131.33	2026-10-01 00:00:00+03
2349	1150	131.67	2026-10-01 00:00:00+03
2350	1151	132.00	2026-10-01 00:00:00+03
2351	1152	132.33	2026-10-01 00:00:00+03
2352	1153	132.67	2026-10-01 00:00:00+03
2353	1154	133.00	2026-10-01 00:00:00+03
2354	1155	133.33	2026-10-01 00:00:00+03
2355	1156	133.67	2026-10-01 00:00:00+03
2356	1157	134.00	2026-10-01 00:00:00+03
2357	1158	134.33	2026-10-01 00:00:00+03
2358	1159	134.67	2026-10-01 00:00:00+03
2359	1160	135.00	2026-10-01 00:00:00+03
2360	1161	135.33	2026-10-01 00:00:00+03
2361	1162	135.67	2026-10-01 00:00:00+03
2362	1163	136.00	2026-10-01 00:00:00+03
2363	1164	136.33	2026-10-01 00:00:00+03
2364	1165	136.67	2026-10-01 00:00:00+03
2365	1166	137.00	2026-10-01 00:00:00+03
2366	1167	137.33	2026-10-01 00:00:00+03
2367	1168	137.67	2026-10-01 00:00:00+03
2368	1169	138.00	2026-10-01 00:00:00+03
2369	1170	138.33	2026-10-01 00:00:00+03
2370	1171	138.67	2026-10-01 00:00:00+03
2371	1172	139.00	2026-10-01 00:00:00+03
2372	1173	139.33	2026-10-01 00:00:00+03
2373	1174	139.67	2026-10-01 00:00:00+03
2374	1175	140.00	2026-10-01 00:00:00+03
2375	1176	140.33	2026-10-01 00:00:00+03
2376	1177	140.67	2026-10-01 00:00:00+03
2377	1178	141.00	2026-10-01 00:00:00+03
2378	1179	141.33	2026-10-01 00:00:00+03
2379	1180	141.67	2026-10-01 00:00:00+03
2380	1181	142.00	2026-10-01 00:00:00+03
2381	1182	142.33	2026-10-01 00:00:00+03
2382	1183	142.67	2026-10-01 00:00:00+03
2383	1184	143.00	2026-10-01 00:00:00+03
2384	1185	143.33	2026-10-01 00:00:00+03
2385	1186	143.67	2026-10-01 00:00:00+03
2386	1187	144.00	2026-10-01 00:00:00+03
2387	1188	144.33	2026-10-01 00:00:00+03
2388	1189	144.67	2026-10-01 00:00:00+03
2389	1190	145.00	2026-10-01 00:00:00+03
2390	1191	145.33	2026-10-01 00:00:00+03
2391	1192	145.67	2026-10-01 00:00:00+03
2392	1193	146.00	2026-10-01 00:00:00+03
2393	1194	146.33	2026-10-01 00:00:00+03
2394	1195	146.67	2026-10-01 00:00:00+03
2395	1196	147.00	2026-10-01 00:00:00+03
2396	1197	147.33	2026-10-01 00:00:00+03
2397	1198	147.67	2026-10-01 00:00:00+03
2398	1199	148.00	2026-10-01 00:00:00+03
2399	1200	148.33	2026-10-01 00:00:00+03
2400	1	148.67	2026-10-01 00:00:00+03
2401	2	149.00	2026-10-01 00:00:00+03
2402	3	149.33	2026-10-01 00:00:00+03
2403	4	149.67	2026-10-01 00:00:00+03
2404	5	150.00	2026-10-01 00:00:00+03
2405	6	150.33	2026-10-01 00:00:00+03
2406	7	150.67	2026-10-01 00:00:00+03
2407	8	151.00	2026-10-01 00:00:00+03
2408	9	151.33	2026-10-01 00:00:00+03
2409	10	151.67	2026-10-01 00:00:00+03
2410	11	152.00	2026-10-01 00:00:00+03
2411	12	152.33	2026-10-01 00:00:00+03
2412	13	152.67	2026-10-01 00:00:00+03
2413	14	153.00	2026-10-01 00:00:00+03
2414	15	153.33	2026-10-01 00:00:00+03
2415	16	153.67	2026-10-01 00:00:00+03
2416	17	154.00	2026-10-01 00:00:00+03
2417	18	154.33	2026-10-01 00:00:00+03
2418	19	154.67	2026-10-01 00:00:00+03
2419	20	155.00	2026-10-01 00:00:00+03
2420	21	155.33	2026-10-01 00:00:00+03
2421	22	155.67	2026-10-01 00:00:00+03
2422	23	156.00	2026-10-01 00:00:00+03
2423	24	156.33	2026-10-01 00:00:00+03
2424	25	156.67	2026-10-01 00:00:00+03
2425	26	157.00	2026-10-01 00:00:00+03
2426	27	157.33	2026-10-01 00:00:00+03
2427	28	157.67	2026-10-01 00:00:00+03
2428	29	158.00	2026-10-01 00:00:00+03
2429	30	158.33	2026-10-01 00:00:00+03
2430	31	158.67	2026-10-01 00:00:00+03
2431	32	159.00	2026-10-01 00:00:00+03
2432	33	159.33	2026-10-01 00:00:00+03
2433	34	159.67	2026-10-01 00:00:00+03
2434	35	160.00	2026-10-01 00:00:00+03
2435	36	160.33	2026-10-01 00:00:00+03
2436	37	160.67	2026-10-01 00:00:00+03
2437	38	161.00	2026-10-01 00:00:00+03
2438	39	161.33	2026-10-01 00:00:00+03
2439	40	161.67	2026-10-01 00:00:00+03
2440	41	162.00	2026-10-01 00:00:00+03
2441	42	162.33	2026-10-01 00:00:00+03
2442	43	162.67	2026-10-01 00:00:00+03
2443	44	163.00	2026-10-01 00:00:00+03
2444	45	163.33	2026-10-01 00:00:00+03
2445	46	163.67	2026-10-01 00:00:00+03
2446	47	164.00	2026-10-01 00:00:00+03
2447	48	164.33	2026-10-01 00:00:00+03
2448	49	164.67	2026-10-01 00:00:00+03
2449	50	165.00	2026-10-01 00:00:00+03
2450	51	165.33	2026-10-01 00:00:00+03
2451	52	165.67	2026-10-01 00:00:00+03
2452	53	166.00	2026-10-01 00:00:00+03
2453	54	166.33	2026-10-01 00:00:00+03
2454	55	166.67	2026-10-01 00:00:00+03
2455	56	167.00	2026-10-01 00:00:00+03
2456	57	167.33	2026-10-01 00:00:00+03
2457	58	167.67	2026-10-01 00:00:00+03
2458	59	168.00	2026-10-01 00:00:00+03
2459	60	168.33	2026-10-01 00:00:00+03
2460	61	168.67	2026-10-01 00:00:00+03
2461	62	169.00	2026-10-01 00:00:00+03
2462	63	169.33	2026-10-01 00:00:00+03
2463	64	169.67	2026-10-01 00:00:00+03
2464	65	170.00	2026-10-01 00:00:00+03
2465	66	170.33	2026-10-01 00:00:00+03
2466	67	170.67	2026-10-01 00:00:00+03
2467	68	171.00	2026-10-01 00:00:00+03
2468	69	171.33	2026-10-01 00:00:00+03
2469	70	171.67	2026-10-01 00:00:00+03
2470	71	172.00	2026-10-01 00:00:00+03
2471	72	172.33	2026-10-01 00:00:00+03
2472	73	172.67	2026-10-01 00:00:00+03
2473	74	173.00	2026-10-01 00:00:00+03
2474	75	173.33	2026-10-01 00:00:00+03
2475	76	173.67	2026-10-01 00:00:00+03
2476	77	174.00	2026-10-01 00:00:00+03
2477	78	174.33	2026-10-01 00:00:00+03
2478	79	174.67	2026-10-01 00:00:00+03
2479	80	175.00	2026-10-01 00:00:00+03
2480	81	175.33	2026-10-01 00:00:00+03
2481	82	175.67	2026-10-01 00:00:00+03
2482	83	176.00	2026-10-01 00:00:00+03
2483	84	176.33	2026-10-01 00:00:00+03
2484	85	176.67	2026-10-01 00:00:00+03
2485	86	177.00	2026-10-01 00:00:00+03
2486	87	177.33	2026-10-01 00:00:00+03
2487	88	177.67	2026-10-01 00:00:00+03
2488	89	178.00	2026-10-01 00:00:00+03
2489	90	178.33	2026-10-01 00:00:00+03
2490	91	178.67	2026-10-01 00:00:00+03
2491	92	179.00	2026-10-01 00:00:00+03
2492	93	179.33	2026-10-01 00:00:00+03
2493	94	179.67	2026-10-01 00:00:00+03
2494	95	180.00	2026-10-01 00:00:00+03
2495	96	180.33	2026-10-01 00:00:00+03
2496	97	180.67	2026-10-01 00:00:00+03
2497	98	181.00	2026-10-01 00:00:00+03
2498	99	181.33	2026-10-01 00:00:00+03
2499	100	181.67	2026-10-01 00:00:00+03
2500	101	182.00	2026-10-01 00:00:00+03
2501	102	182.33	2026-10-01 00:00:00+03
2502	103	182.67	2026-10-01 00:00:00+03
2503	104	183.00	2026-10-01 00:00:00+03
2504	105	183.33	2026-10-01 00:00:00+03
2505	106	183.67	2026-10-01 00:00:00+03
2506	107	184.00	2026-10-01 00:00:00+03
2507	108	184.33	2026-10-01 00:00:00+03
2508	109	184.67	2026-10-01 00:00:00+03
2509	110	185.00	2026-10-01 00:00:00+03
2510	111	185.33	2026-10-01 00:00:00+03
2511	112	185.67	2026-10-01 00:00:00+03
2512	113	186.00	2026-10-01 00:00:00+03
2513	114	186.33	2026-10-01 00:00:00+03
2514	115	186.67	2026-10-01 00:00:00+03
2515	116	187.00	2026-10-01 00:00:00+03
2516	117	187.33	2026-10-01 00:00:00+03
2517	118	187.67	2026-10-01 00:00:00+03
2518	119	188.00	2026-10-01 00:00:00+03
2519	120	188.33	2026-10-01 00:00:00+03
2520	121	188.67	2026-10-01 00:00:00+03
2521	122	189.00	2026-10-01 00:00:00+03
2522	123	189.33	2026-10-01 00:00:00+03
2523	124	189.67	2026-10-01 00:00:00+03
2524	125	190.00	2026-10-01 00:00:00+03
2525	126	190.33	2026-10-01 00:00:00+03
2526	127	190.67	2026-10-01 00:00:00+03
2527	128	191.00	2026-10-01 00:00:00+03
2528	129	191.33	2026-10-01 00:00:00+03
2529	130	191.67	2026-10-01 00:00:00+03
2530	131	192.00	2026-10-01 00:00:00+03
2531	132	192.33	2026-10-01 00:00:00+03
2532	133	192.67	2026-10-01 00:00:00+03
2533	134	193.00	2026-10-01 00:00:00+03
2534	135	193.33	2026-10-01 00:00:00+03
2535	136	193.67	2026-10-01 00:00:00+03
2536	137	194.00	2026-10-01 00:00:00+03
2537	138	194.33	2026-10-01 00:00:00+03
2538	139	194.67	2026-10-01 00:00:00+03
2539	140	195.00	2026-10-01 00:00:00+03
2540	141	195.33	2026-10-01 00:00:00+03
2541	142	195.67	2026-10-01 00:00:00+03
2542	143	196.00	2026-10-01 00:00:00+03
2543	144	196.33	2026-10-01 00:00:00+03
2544	145	196.67	2026-10-01 00:00:00+03
2545	146	197.00	2026-10-01 00:00:00+03
2546	147	197.33	2026-10-01 00:00:00+03
2547	148	197.67	2026-10-01 00:00:00+03
2548	149	198.00	2026-10-01 00:00:00+03
2549	150	198.33	2026-10-01 00:00:00+03
2550	151	198.67	2026-10-01 00:00:00+03
2551	152	199.00	2026-10-01 00:00:00+03
2552	153	199.33	2026-10-01 00:00:00+03
2553	154	199.67	2026-10-01 00:00:00+03
2554	155	200.00	2026-10-01 00:00:00+03
2555	156	200.33	2026-10-01 00:00:00+03
2556	157	200.67	2026-10-01 00:00:00+03
2557	158	201.00	2026-10-01 00:00:00+03
2558	159	201.33	2026-10-01 00:00:00+03
2559	160	201.67	2026-10-01 00:00:00+03
2560	161	202.00	2026-10-01 00:00:00+03
2561	162	202.33	2026-10-01 00:00:00+03
2562	163	202.67	2026-10-01 00:00:00+03
2563	164	203.00	2026-10-01 00:00:00+03
2564	165	203.33	2026-10-01 00:00:00+03
2565	166	203.67	2026-10-01 00:00:00+03
2566	167	204.00	2026-10-01 00:00:00+03
2567	168	204.33	2026-10-01 00:00:00+03
2568	169	204.67	2026-10-01 00:00:00+03
2569	170	205.00	2026-10-01 00:00:00+03
2570	171	205.33	2026-10-01 00:00:00+03
2571	172	205.67	2026-10-01 00:00:00+03
2572	173	206.00	2026-10-01 00:00:00+03
2573	174	206.33	2026-10-01 00:00:00+03
2574	175	206.67	2026-10-01 00:00:00+03
2575	176	207.00	2026-10-01 00:00:00+03
2576	177	207.33	2026-10-01 00:00:00+03
2577	178	207.67	2026-10-01 00:00:00+03
2578	179	208.00	2026-10-01 00:00:00+03
2579	180	208.33	2026-10-01 00:00:00+03
2580	181	208.67	2026-10-01 00:00:00+03
2581	182	209.00	2026-10-01 00:00:00+03
2582	183	209.33	2026-10-01 00:00:00+03
2583	184	209.67	2026-10-01 00:00:00+03
2584	185	210.00	2026-10-01 00:00:00+03
2585	186	210.33	2026-10-01 00:00:00+03
2586	187	210.67	2026-10-01 00:00:00+03
2587	188	211.00	2026-10-01 00:00:00+03
2588	189	211.33	2026-10-01 00:00:00+03
2589	190	211.67	2026-10-01 00:00:00+03
2590	191	212.00	2026-10-01 00:00:00+03
2591	192	212.33	2026-10-01 00:00:00+03
2592	193	212.67	2026-10-01 00:00:00+03
2593	194	213.00	2026-10-01 00:00:00+03
2594	195	213.33	2026-10-01 00:00:00+03
2595	196	213.67	2026-10-01 00:00:00+03
2596	197	214.00	2026-10-01 00:00:00+03
2597	198	214.33	2026-10-01 00:00:00+03
2598	199	214.67	2026-10-01 00:00:00+03
2599	200	215.00	2026-10-01 00:00:00+03
2600	201	215.33	2026-10-01 00:00:00+03
2601	202	215.67	2026-10-01 00:00:00+03
2602	203	216.00	2026-10-01 00:00:00+03
2603	204	216.33	2026-10-01 00:00:00+03
2604	205	216.67	2026-10-01 00:00:00+03
2605	206	217.00	2026-10-01 00:00:00+03
2606	207	217.33	2026-10-01 00:00:00+03
2607	208	217.67	2026-10-01 00:00:00+03
2608	209	218.00	2026-10-01 00:00:00+03
2609	210	218.33	2026-10-01 00:00:00+03
2610	211	218.67	2026-10-01 00:00:00+03
2611	212	219.00	2026-10-01 00:00:00+03
2612	213	219.33	2026-10-01 00:00:00+03
2613	214	219.67	2026-10-01 00:00:00+03
2614	215	220.00	2026-10-01 00:00:00+03
2615	216	220.33	2026-10-01 00:00:00+03
2616	217	220.67	2026-10-01 00:00:00+03
2617	218	221.00	2026-10-01 00:00:00+03
2618	219	221.33	2026-10-01 00:00:00+03
2619	220	221.67	2026-10-01 00:00:00+03
2620	221	222.00	2026-10-01 00:00:00+03
2621	222	222.33	2026-10-01 00:00:00+03
2622	223	222.67	2026-10-01 00:00:00+03
2623	224	223.00	2026-10-01 00:00:00+03
2624	225	223.33	2026-10-01 00:00:00+03
2625	226	223.67	2026-10-01 00:00:00+03
2626	227	224.00	2026-10-01 00:00:00+03
2627	228	224.33	2026-10-01 00:00:00+03
2628	229	224.67	2026-10-01 00:00:00+03
2629	230	225.00	2026-10-01 00:00:00+03
2630	231	225.33	2026-10-01 00:00:00+03
2631	232	225.67	2026-10-01 00:00:00+03
2632	233	226.00	2026-10-01 00:00:00+03
2633	234	226.33	2026-10-01 00:00:00+03
2634	235	226.67	2026-10-01 00:00:00+03
2635	236	227.00	2026-10-01 00:00:00+03
2636	237	227.33	2026-10-01 00:00:00+03
2637	238	227.67	2026-10-01 00:00:00+03
2638	239	228.00	2026-10-01 00:00:00+03
2639	240	228.33	2026-10-01 00:00:00+03
2640	241	228.67	2026-10-01 00:00:00+03
2641	242	229.00	2026-10-01 00:00:00+03
2642	243	229.33	2026-10-01 00:00:00+03
2643	244	229.67	2026-10-01 00:00:00+03
2644	245	230.00	2026-10-01 00:00:00+03
2645	246	230.33	2026-10-01 00:00:00+03
2646	247	230.67	2026-10-01 00:00:00+03
2647	248	231.00	2026-10-01 00:00:00+03
2648	249	231.33	2026-10-01 00:00:00+03
2649	250	231.67	2026-10-01 00:00:00+03
2650	251	232.00	2026-10-01 00:00:00+03
2651	252	232.33	2026-10-01 00:00:00+03
2652	253	232.67	2026-10-01 00:00:00+03
2653	254	233.00	2026-10-01 00:00:00+03
2654	255	233.33	2026-10-01 00:00:00+03
2655	256	233.67	2026-10-01 00:00:00+03
2656	257	234.00	2026-10-01 00:00:00+03
2657	258	234.33	2026-10-01 00:00:00+03
2658	259	234.67	2026-10-01 00:00:00+03
2659	260	235.00	2026-10-01 00:00:00+03
2660	261	235.33	2026-10-01 00:00:00+03
2661	262	235.67	2026-10-01 00:00:00+03
2662	263	236.00	2026-10-01 00:00:00+03
2663	264	236.33	2026-10-01 00:00:00+03
2664	265	236.67	2026-10-01 00:00:00+03
2665	266	237.00	2026-10-01 00:00:00+03
2666	267	237.33	2026-10-01 00:00:00+03
2667	268	237.67	2026-10-01 00:00:00+03
2668	269	238.00	2026-10-01 00:00:00+03
2669	270	238.33	2026-10-01 00:00:00+03
2670	271	238.67	2026-10-01 00:00:00+03
2671	272	239.00	2026-10-01 00:00:00+03
2672	273	239.33	2026-10-01 00:00:00+03
2673	274	239.67	2026-10-01 00:00:00+03
2674	275	240.00	2026-10-01 00:00:00+03
2675	276	240.33	2026-10-01 00:00:00+03
2676	277	240.67	2026-10-01 00:00:00+03
2677	278	241.00	2026-10-01 00:00:00+03
2678	279	241.33	2026-10-01 00:00:00+03
2679	280	241.67	2026-10-01 00:00:00+03
2680	281	242.00	2026-10-01 00:00:00+03
2681	282	242.33	2026-10-01 00:00:00+03
2682	283	242.67	2026-10-01 00:00:00+03
2683	284	243.00	2026-10-01 00:00:00+03
2684	285	243.33	2026-10-01 00:00:00+03
2685	286	243.67	2026-10-01 00:00:00+03
2686	287	244.00	2026-10-01 00:00:00+03
2687	288	244.33	2026-10-01 00:00:00+03
2688	289	244.67	2026-10-01 00:00:00+03
2689	290	245.00	2026-10-01 00:00:00+03
2690	291	245.33	2026-10-01 00:00:00+03
2691	292	245.67	2026-10-01 00:00:00+03
2692	293	246.00	2026-10-01 00:00:00+03
2693	294	246.33	2026-10-01 00:00:00+03
2694	295	246.67	2026-10-01 00:00:00+03
2695	296	247.00	2026-10-01 00:00:00+03
2696	297	247.33	2026-10-01 00:00:00+03
2697	298	247.67	2026-10-01 00:00:00+03
2698	299	248.00	2026-10-01 00:00:00+03
2699	300	248.33	2026-10-01 00:00:00+03
2700	301	248.67	2026-10-01 00:00:00+03
2701	302	249.00	2026-10-01 00:00:00+03
2702	303	249.33	2026-10-01 00:00:00+03
2703	304	249.67	2026-10-01 00:00:00+03
2704	305	250.00	2026-10-01 00:00:00+03
2705	306	250.33	2026-10-01 00:00:00+03
2706	307	250.67	2026-10-01 00:00:00+03
2707	308	251.00	2026-10-01 00:00:00+03
2708	309	251.33	2026-10-01 00:00:00+03
2709	310	251.67	2026-10-01 00:00:00+03
2710	311	252.00	2026-10-01 00:00:00+03
2711	312	252.33	2026-10-01 00:00:00+03
2712	313	252.67	2026-10-01 00:00:00+03
2713	314	253.00	2026-10-01 00:00:00+03
2714	315	253.33	2026-10-01 00:00:00+03
2715	316	253.67	2026-10-01 00:00:00+03
2716	317	254.00	2026-10-01 00:00:00+03
2717	318	254.33	2026-10-01 00:00:00+03
2718	319	254.67	2026-10-01 00:00:00+03
2719	320	255.00	2026-10-01 00:00:00+03
2720	321	255.33	2026-10-01 00:00:00+03
2721	322	255.67	2026-10-01 00:00:00+03
2722	323	256.00	2026-10-01 00:00:00+03
2723	324	256.33	2026-10-01 00:00:00+03
2724	325	256.67	2026-10-01 00:00:00+03
2725	326	257.00	2026-10-01 00:00:00+03
2726	327	257.33	2026-10-01 00:00:00+03
2727	328	257.67	2026-10-01 00:00:00+03
2728	329	258.00	2026-10-01 00:00:00+03
2729	330	258.33	2026-10-01 00:00:00+03
2730	331	258.67	2026-10-01 00:00:00+03
2731	332	259.00	2026-10-01 00:00:00+03
2732	333	259.33	2026-10-01 00:00:00+03
2733	334	259.67	2026-10-01 00:00:00+03
2734	335	260.00	2026-10-01 00:00:00+03
2735	336	260.33	2026-10-01 00:00:00+03
2736	337	260.67	2026-10-01 00:00:00+03
2737	338	261.00	2026-10-01 00:00:00+03
2738	339	261.33	2026-10-01 00:00:00+03
2739	340	261.67	2026-10-01 00:00:00+03
2740	341	262.00	2026-10-01 00:00:00+03
2741	342	262.33	2026-10-01 00:00:00+03
2742	343	262.67	2026-10-01 00:00:00+03
2743	344	263.00	2026-10-01 00:00:00+03
2744	345	263.33	2026-10-01 00:00:00+03
2745	346	263.67	2026-10-01 00:00:00+03
2746	347	264.00	2026-10-01 00:00:00+03
2747	348	264.33	2026-10-01 00:00:00+03
2748	349	264.67	2026-10-01 00:00:00+03
2749	350	265.00	2026-10-01 00:00:00+03
2750	351	265.33	2026-10-01 00:00:00+03
2751	352	265.67	2026-10-01 00:00:00+03
2752	353	266.00	2026-10-01 00:00:00+03
2753	354	266.33	2026-10-01 00:00:00+03
2754	355	266.67	2026-10-01 00:00:00+03
2755	356	267.00	2026-10-01 00:00:00+03
2756	357	267.33	2026-10-01 00:00:00+03
2757	358	267.67	2026-10-01 00:00:00+03
2758	359	268.00	2026-10-01 00:00:00+03
2759	360	268.33	2026-10-01 00:00:00+03
2760	361	268.67	2026-10-01 00:00:00+03
2761	362	269.00	2026-10-01 00:00:00+03
2762	363	269.33	2026-10-01 00:00:00+03
2763	364	269.67	2026-10-01 00:00:00+03
2764	365	270.00	2026-10-01 00:00:00+03
2765	366	270.33	2026-10-01 00:00:00+03
2766	367	270.67	2026-10-01 00:00:00+03
2767	368	271.00	2026-10-01 00:00:00+03
2768	369	271.33	2026-10-01 00:00:00+03
2769	370	271.67	2026-10-01 00:00:00+03
2770	371	272.00	2026-10-01 00:00:00+03
2771	372	272.33	2026-10-01 00:00:00+03
2772	373	272.67	2026-10-01 00:00:00+03
2773	374	273.00	2026-10-01 00:00:00+03
2774	375	273.33	2026-10-01 00:00:00+03
2775	376	273.67	2026-10-01 00:00:00+03
2776	377	274.00	2026-10-01 00:00:00+03
2777	378	274.33	2026-10-01 00:00:00+03
2778	379	274.67	2026-10-01 00:00:00+03
2779	380	275.00	2026-10-01 00:00:00+03
2780	381	275.33	2026-10-01 00:00:00+03
2781	382	275.67	2026-10-01 00:00:00+03
2782	383	276.00	2026-10-01 00:00:00+03
2783	384	276.33	2026-10-01 00:00:00+03
2784	385	276.67	2026-10-01 00:00:00+03
2785	386	277.00	2026-10-01 00:00:00+03
2786	387	277.33	2026-10-01 00:00:00+03
2787	388	277.67	2026-10-01 00:00:00+03
2788	389	278.00	2026-10-01 00:00:00+03
2789	390	278.33	2026-10-01 00:00:00+03
2790	391	278.67	2026-10-01 00:00:00+03
2791	392	279.00	2026-10-01 00:00:00+03
2792	393	279.33	2026-10-01 00:00:00+03
2793	394	279.67	2026-10-01 00:00:00+03
2794	395	280.00	2026-10-01 00:00:00+03
2795	396	280.33	2026-10-01 00:00:00+03
2796	397	280.67	2026-10-01 00:00:00+03
2797	398	281.00	2026-10-01 00:00:00+03
2798	399	281.33	2026-10-01 00:00:00+03
2799	400	281.67	2026-10-01 00:00:00+03
2800	401	282.00	2026-10-01 00:00:00+03
2801	402	282.33	2026-10-01 00:00:00+03
2802	403	282.67	2026-10-01 00:00:00+03
2803	404	283.00	2026-10-01 00:00:00+03
2804	405	283.33	2026-10-01 00:00:00+03
2805	406	283.67	2026-10-01 00:00:00+03
2806	407	284.00	2026-10-01 00:00:00+03
2807	408	284.33	2026-10-01 00:00:00+03
2808	409	284.67	2026-10-01 00:00:00+03
2809	410	285.00	2026-10-01 00:00:00+03
2810	411	285.33	2026-10-01 00:00:00+03
2811	412	285.67	2026-10-01 00:00:00+03
2812	413	286.00	2026-10-01 00:00:00+03
2813	414	286.33	2026-10-01 00:00:00+03
2814	415	286.67	2026-10-01 00:00:00+03
2815	416	287.00	2026-10-01 00:00:00+03
2816	417	287.33	2026-10-01 00:00:00+03
2817	418	287.67	2026-10-01 00:00:00+03
2818	419	288.00	2026-10-01 00:00:00+03
2819	420	288.33	2026-10-01 00:00:00+03
2820	421	288.67	2026-10-01 00:00:00+03
2821	422	289.00	2026-10-01 00:00:00+03
2822	423	289.33	2026-10-01 00:00:00+03
2823	424	289.67	2026-10-01 00:00:00+03
2824	425	290.00	2026-10-01 00:00:00+03
2825	426	290.33	2026-10-01 00:00:00+03
2826	427	290.67	2026-10-01 00:00:00+03
2827	428	291.00	2026-10-01 00:00:00+03
2828	429	291.33	2026-10-01 00:00:00+03
2829	430	291.67	2026-10-01 00:00:00+03
2830	431	292.00	2026-10-01 00:00:00+03
2831	432	292.33	2026-10-01 00:00:00+03
2832	433	292.67	2026-10-01 00:00:00+03
2833	434	293.00	2026-10-01 00:00:00+03
2834	435	293.33	2026-10-01 00:00:00+03
2835	436	293.67	2026-10-01 00:00:00+03
2836	437	294.00	2026-10-01 00:00:00+03
2837	438	294.33	2026-10-01 00:00:00+03
2838	439	294.67	2026-10-01 00:00:00+03
2839	440	295.00	2026-10-01 00:00:00+03
2840	441	295.33	2026-10-01 00:00:00+03
2841	442	295.67	2026-10-01 00:00:00+03
2842	443	296.00	2026-10-01 00:00:00+03
2843	444	296.33	2026-10-01 00:00:00+03
2844	445	296.67	2026-10-01 00:00:00+03
2845	446	297.00	2026-10-01 00:00:00+03
2846	447	297.33	2026-10-01 00:00:00+03
2847	448	297.67	2026-10-01 00:00:00+03
2848	449	298.00	2026-10-01 00:00:00+03
2849	450	298.33	2026-10-01 00:00:00+03
2850	451	298.67	2026-10-01 00:00:00+03
2851	452	299.00	2026-10-01 00:00:00+03
2852	453	299.33	2026-10-01 00:00:00+03
2853	454	299.67	2026-10-01 00:00:00+03
2854	455	300.00	2026-10-01 00:00:00+03
2855	456	300.33	2026-10-01 00:00:00+03
2856	457	300.67	2026-10-01 00:00:00+03
2857	458	301.00	2026-10-01 00:00:00+03
2858	459	301.33	2026-10-01 00:00:00+03
2859	460	301.67	2026-10-01 00:00:00+03
2860	461	302.00	2026-10-01 00:00:00+03
2861	462	302.33	2026-10-01 00:00:00+03
2862	463	302.67	2026-10-01 00:00:00+03
2863	464	303.00	2026-10-01 00:00:00+03
2864	465	303.33	2026-10-01 00:00:00+03
2865	466	303.67	2026-10-01 00:00:00+03
2866	467	304.00	2026-10-01 00:00:00+03
2867	468	304.33	2026-10-01 00:00:00+03
2868	469	304.67	2026-10-01 00:00:00+03
2869	470	305.00	2026-10-01 00:00:00+03
2870	471	305.33	2026-10-01 00:00:00+03
2871	472	305.67	2026-10-01 00:00:00+03
2872	473	306.00	2026-10-01 00:00:00+03
2873	474	306.33	2026-10-01 00:00:00+03
2874	475	306.67	2026-10-01 00:00:00+03
2875	476	307.00	2026-10-01 00:00:00+03
2876	477	307.33	2026-10-01 00:00:00+03
2877	478	307.67	2026-10-01 00:00:00+03
2878	479	308.00	2026-10-01 00:00:00+03
2879	480	308.33	2026-10-01 00:00:00+03
2880	481	308.67	2026-10-01 00:00:00+03
2881	482	309.00	2026-10-01 00:00:00+03
2882	483	309.33	2026-10-01 00:00:00+03
2883	484	309.67	2026-10-01 00:00:00+03
2884	485	310.00	2026-10-01 00:00:00+03
2885	486	310.33	2026-10-01 00:00:00+03
2886	487	310.67	2026-10-01 00:00:00+03
2887	488	311.00	2026-10-01 00:00:00+03
2888	489	311.33	2026-10-01 00:00:00+03
2889	490	311.67	2026-10-01 00:00:00+03
2890	491	312.00	2026-10-01 00:00:00+03
2891	492	312.33	2026-10-01 00:00:00+03
2892	493	312.67	2026-10-01 00:00:00+03
2893	494	313.00	2026-10-01 00:00:00+03
2894	495	313.33	2026-10-01 00:00:00+03
2895	496	313.67	2026-10-01 00:00:00+03
2896	497	314.00	2026-10-01 00:00:00+03
2897	498	314.33	2026-10-01 00:00:00+03
2898	499	314.67	2026-10-01 00:00:00+03
2899	500	315.00	2026-10-01 00:00:00+03
2900	501	315.33	2026-10-01 00:00:00+03
2901	502	315.67	2026-10-01 00:00:00+03
2902	503	316.00	2026-10-01 00:00:00+03
2903	504	316.33	2026-10-01 00:00:00+03
2904	505	316.67	2026-10-01 00:00:00+03
2905	506	317.00	2026-10-01 00:00:00+03
2906	507	317.33	2026-10-01 00:00:00+03
2907	508	317.67	2026-10-01 00:00:00+03
2908	509	318.00	2026-10-01 00:00:00+03
2909	510	318.33	2026-10-01 00:00:00+03
2910	511	318.67	2026-10-01 00:00:00+03
2911	512	319.00	2026-10-01 00:00:00+03
2912	513	319.33	2026-10-01 00:00:00+03
2913	514	319.67	2026-10-01 00:00:00+03
2914	515	320.00	2026-10-01 00:00:00+03
2915	516	320.33	2026-10-01 00:00:00+03
2916	517	320.67	2026-10-01 00:00:00+03
2917	518	321.00	2026-10-01 00:00:00+03
2918	519	321.33	2026-10-01 00:00:00+03
2919	520	321.67	2026-10-01 00:00:00+03
2920	521	322.00	2026-10-01 00:00:00+03
2921	522	322.33	2026-10-01 00:00:00+03
2922	523	322.67	2026-10-01 00:00:00+03
2923	524	323.00	2026-10-01 00:00:00+03
2924	525	323.33	2026-10-01 00:00:00+03
2925	526	323.67	2026-10-01 00:00:00+03
2926	527	324.00	2026-10-01 00:00:00+03
2927	528	324.33	2026-10-01 00:00:00+03
2928	529	324.67	2026-10-01 00:00:00+03
2929	530	325.00	2026-10-01 00:00:00+03
2930	531	325.33	2026-10-01 00:00:00+03
2931	532	0.00	2026-10-01 00:00:00+03
2932	533	0.33	2026-10-01 00:00:00+03
2933	534	0.67	2026-10-01 00:00:00+03
2934	535	1.00	2026-10-01 00:00:00+03
2935	536	1.33	2026-10-01 00:00:00+03
2936	537	1.67	2026-10-01 00:00:00+03
2937	538	2.00	2026-10-01 00:00:00+03
2938	539	2.33	2026-10-01 00:00:00+03
2939	540	2.67	2026-10-01 00:00:00+03
2940	541	3.00	2026-10-01 00:00:00+03
2941	542	3.33	2026-10-01 00:00:00+03
2942	543	3.67	2026-10-01 00:00:00+03
2943	544	4.00	2026-10-01 00:00:00+03
2944	545	4.33	2026-10-01 00:00:00+03
2945	546	4.67	2026-10-01 00:00:00+03
2946	547	5.00	2026-10-01 00:00:00+03
2947	548	5.33	2026-10-01 00:00:00+03
2948	549	5.67	2026-10-01 00:00:00+03
2949	550	6.00	2026-10-01 00:00:00+03
2950	551	6.33	2026-10-01 00:00:00+03
2951	552	6.67	2026-10-01 00:00:00+03
2952	553	7.00	2026-10-01 00:00:00+03
2953	554	7.33	2026-10-01 00:00:00+03
2954	555	7.67	2026-10-01 00:00:00+03
2955	556	8.00	2026-10-01 00:00:00+03
2956	557	8.33	2026-10-01 00:00:00+03
2957	558	8.67	2026-10-01 00:00:00+03
2958	559	9.00	2026-10-01 00:00:00+03
2959	560	9.33	2026-10-01 00:00:00+03
2960	561	9.67	2026-10-01 00:00:00+03
2961	562	10.00	2026-10-01 00:00:00+03
2962	563	10.33	2026-10-01 00:00:00+03
2963	564	10.67	2026-10-01 00:00:00+03
2964	565	11.00	2026-10-01 00:00:00+03
2965	566	11.33	2026-10-01 00:00:00+03
2966	567	11.67	2026-10-01 00:00:00+03
2967	568	12.00	2026-10-01 00:00:00+03
2968	569	12.33	2026-10-01 00:00:00+03
2969	570	12.67	2026-10-01 00:00:00+03
2970	571	13.00	2026-10-01 00:00:00+03
2971	572	13.33	2026-10-01 00:00:00+03
2972	573	13.67	2026-10-01 00:00:00+03
2973	574	14.00	2026-10-01 00:00:00+03
2974	575	14.33	2026-10-01 00:00:00+03
2975	576	14.67	2026-10-01 00:00:00+03
2976	577	15.00	2026-10-01 00:00:00+03
2977	578	15.33	2026-10-01 00:00:00+03
2978	579	15.67	2026-10-01 00:00:00+03
2979	580	16.00	2026-10-01 00:00:00+03
2980	581	16.33	2026-10-01 00:00:00+03
2981	582	16.67	2026-10-01 00:00:00+03
2982	583	17.00	2026-10-01 00:00:00+03
2983	584	17.33	2026-10-01 00:00:00+03
2984	585	17.67	2026-10-01 00:00:00+03
2985	586	18.00	2026-10-01 00:00:00+03
2986	587	18.33	2026-10-01 00:00:00+03
2987	588	18.67	2026-10-01 00:00:00+03
2988	589	19.00	2026-10-01 00:00:00+03
2989	590	19.33	2026-10-01 00:00:00+03
2990	591	19.67	2026-10-01 00:00:00+03
2991	592	20.00	2026-10-01 00:00:00+03
2992	593	20.33	2026-10-01 00:00:00+03
2993	594	20.67	2026-10-01 00:00:00+03
2994	595	21.00	2026-10-01 00:00:00+03
2995	596	21.33	2026-10-01 00:00:00+03
2996	597	21.67	2026-10-01 00:00:00+03
2997	598	22.00	2026-10-01 00:00:00+03
2998	599	22.33	2026-10-01 00:00:00+03
2999	600	22.67	2026-10-01 00:00:00+03
3000	601	23.00	2026-10-01 00:00:00+03
3001	602	23.33	2026-10-01 00:00:00+03
3002	603	23.67	2026-10-01 00:00:00+03
3003	604	24.00	2026-10-01 00:00:00+03
3004	605	24.33	2026-10-01 00:00:00+03
3005	606	24.67	2026-10-01 00:00:00+03
3006	607	25.00	2026-10-01 00:00:00+03
3007	608	25.33	2026-10-01 00:00:00+03
3008	609	25.67	2026-10-01 00:00:00+03
3009	610	26.00	2026-10-01 00:00:00+03
3010	611	26.33	2026-10-01 00:00:00+03
3011	612	26.67	2026-10-01 00:00:00+03
3012	613	27.00	2026-10-01 00:00:00+03
3013	614	27.33	2026-10-01 00:00:00+03
3014	615	27.67	2026-10-01 00:00:00+03
3015	616	28.00	2026-10-01 00:00:00+03
3016	617	28.33	2026-10-01 00:00:00+03
3017	618	28.67	2026-10-01 00:00:00+03
3018	619	29.00	2026-10-01 00:00:00+03
3019	620	29.33	2026-10-01 00:00:00+03
3020	621	29.67	2026-10-01 00:00:00+03
3021	622	30.00	2026-10-01 00:00:00+03
3022	623	30.33	2026-10-01 00:00:00+03
3023	624	30.67	2026-10-01 00:00:00+03
3024	625	31.00	2026-10-01 00:00:00+03
3025	626	31.33	2026-10-01 00:00:00+03
3026	627	31.67	2026-10-01 00:00:00+03
3027	628	32.00	2026-10-01 00:00:00+03
3028	629	32.33	2026-10-01 00:00:00+03
3029	630	32.67	2026-10-01 00:00:00+03
3030	631	33.00	2026-10-01 00:00:00+03
3031	632	33.33	2026-10-01 00:00:00+03
3032	633	33.67	2026-10-01 00:00:00+03
3033	634	34.00	2026-10-01 00:00:00+03
3034	635	34.33	2026-10-01 00:00:00+03
3035	636	34.67	2026-10-01 00:00:00+03
3036	637	35.00	2026-10-01 00:00:00+03
3037	638	35.33	2026-10-01 00:00:00+03
3038	639	35.67	2026-10-01 00:00:00+03
3039	640	36.00	2026-10-01 00:00:00+03
3040	641	36.33	2026-10-01 00:00:00+03
3041	642	36.67	2026-10-01 00:00:00+03
3042	643	37.00	2026-10-01 00:00:00+03
3043	644	37.33	2026-10-01 00:00:00+03
3044	645	37.67	2026-10-01 00:00:00+03
3045	646	38.00	2026-10-01 00:00:00+03
3046	647	38.33	2026-10-01 00:00:00+03
3047	648	38.67	2026-10-01 00:00:00+03
3048	649	39.00	2026-10-01 00:00:00+03
3049	650	39.33	2026-10-01 00:00:00+03
3050	651	39.67	2026-10-01 00:00:00+03
3051	652	40.00	2026-10-01 00:00:00+03
3052	653	40.33	2026-10-01 00:00:00+03
3053	654	40.67	2026-10-01 00:00:00+03
3054	655	41.00	2026-10-01 00:00:00+03
3055	656	41.33	2026-10-01 00:00:00+03
3056	657	41.67	2026-10-01 00:00:00+03
3057	658	42.00	2026-10-01 00:00:00+03
3058	659	42.33	2026-10-01 00:00:00+03
3059	660	42.67	2026-10-01 00:00:00+03
3060	661	43.00	2026-10-01 00:00:00+03
3061	662	43.33	2026-10-01 00:00:00+03
3062	663	43.67	2026-10-01 00:00:00+03
3063	664	44.00	2026-10-01 00:00:00+03
3064	665	44.33	2026-10-01 00:00:00+03
3065	666	44.67	2026-10-01 00:00:00+03
3066	667	45.00	2026-10-01 00:00:00+03
3067	668	45.33	2026-10-01 00:00:00+03
3068	669	45.67	2026-10-01 00:00:00+03
3069	670	46.00	2026-10-01 00:00:00+03
3070	671	46.33	2026-10-01 00:00:00+03
3071	672	46.67	2026-10-01 00:00:00+03
3072	673	47.00	2026-10-01 00:00:00+03
3073	674	47.33	2026-10-01 00:00:00+03
3074	675	47.67	2026-10-01 00:00:00+03
3075	676	48.00	2026-10-01 00:00:00+03
3076	677	48.33	2026-10-01 00:00:00+03
3077	678	48.67	2026-10-01 00:00:00+03
3078	679	49.00	2026-10-01 00:00:00+03
3079	680	49.33	2026-10-01 00:00:00+03
3080	681	49.67	2026-10-01 00:00:00+03
3081	682	50.00	2026-10-01 00:00:00+03
3082	683	50.33	2026-10-01 00:00:00+03
3083	684	50.67	2026-10-01 00:00:00+03
3084	685	51.00	2026-10-01 00:00:00+03
3085	686	51.33	2026-10-01 00:00:00+03
3086	687	51.67	2026-10-01 00:00:00+03
3087	688	52.00	2026-10-01 00:00:00+03
3088	689	52.33	2026-10-01 00:00:00+03
3089	690	52.67	2026-10-01 00:00:00+03
3090	691	53.00	2026-10-01 00:00:00+03
3091	692	53.33	2026-10-01 00:00:00+03
3092	693	53.67	2026-10-01 00:00:00+03
3093	694	54.00	2026-10-01 00:00:00+03
3094	695	54.33	2026-10-01 00:00:00+03
3095	696	54.67	2026-10-01 00:00:00+03
3096	697	55.00	2026-10-01 00:00:00+03
3097	698	55.33	2026-10-01 00:00:00+03
3098	699	55.67	2026-10-01 00:00:00+03
3099	700	56.00	2026-10-01 00:00:00+03
3100	701	56.33	2026-10-01 00:00:00+03
3101	702	56.67	2026-10-01 00:00:00+03
3102	703	57.00	2026-10-01 00:00:00+03
3103	704	57.33	2026-10-01 00:00:00+03
3104	705	57.67	2026-10-01 00:00:00+03
3105	706	58.00	2026-10-01 00:00:00+03
3106	707	58.33	2026-10-01 00:00:00+03
3107	708	58.67	2026-10-01 00:00:00+03
3108	709	59.00	2026-10-01 00:00:00+03
3109	710	59.33	2026-10-01 00:00:00+03
3110	711	59.67	2026-10-01 00:00:00+03
3111	712	60.00	2026-10-01 00:00:00+03
3112	713	60.33	2026-10-01 00:00:00+03
3113	714	60.67	2026-10-01 00:00:00+03
3114	715	61.00	2026-10-01 00:00:00+03
3115	716	61.33	2026-10-01 00:00:00+03
3116	717	61.67	2026-10-01 00:00:00+03
3117	718	62.00	2026-10-01 00:00:00+03
3118	719	62.33	2026-10-01 00:00:00+03
3119	720	62.67	2026-10-01 00:00:00+03
3120	721	63.00	2026-10-01 00:00:00+03
3121	722	63.33	2026-10-01 00:00:00+03
3122	723	63.67	2026-10-01 00:00:00+03
3123	724	64.00	2026-10-01 00:00:00+03
3124	725	64.33	2026-10-01 00:00:00+03
3125	726	64.67	2026-10-01 00:00:00+03
3126	727	65.00	2026-10-01 00:00:00+03
3127	728	65.33	2026-10-01 00:00:00+03
3128	729	65.67	2026-10-01 00:00:00+03
3129	730	66.00	2026-10-01 00:00:00+03
3130	731	66.33	2026-10-01 00:00:00+03
3131	732	66.67	2026-10-01 00:00:00+03
3132	733	67.00	2026-10-01 00:00:00+03
3133	734	67.33	2026-10-01 00:00:00+03
3134	735	67.67	2026-10-01 00:00:00+03
3135	736	68.00	2026-10-01 00:00:00+03
3136	737	68.33	2026-10-01 00:00:00+03
3137	738	68.67	2026-10-01 00:00:00+03
3138	739	69.00	2026-10-01 00:00:00+03
3139	740	69.33	2026-10-01 00:00:00+03
3140	741	69.67	2026-10-01 00:00:00+03
3141	742	70.00	2026-10-01 00:00:00+03
3142	743	70.33	2026-10-01 00:00:00+03
3143	744	70.67	2026-10-01 00:00:00+03
3144	745	71.00	2026-10-01 00:00:00+03
3145	746	71.33	2026-10-01 00:00:00+03
3146	747	71.67	2026-10-01 00:00:00+03
3147	748	72.00	2026-10-01 00:00:00+03
3148	749	72.33	2026-10-01 00:00:00+03
3149	750	72.67	2026-10-01 00:00:00+03
3150	751	73.00	2026-10-01 00:00:00+03
3151	752	73.33	2026-10-01 00:00:00+03
3152	753	73.67	2026-10-01 00:00:00+03
3153	754	74.00	2026-10-01 00:00:00+03
3154	755	74.33	2026-10-01 00:00:00+03
3155	756	74.67	2026-10-01 00:00:00+03
3156	757	75.00	2026-10-01 00:00:00+03
3157	758	75.33	2026-10-01 00:00:00+03
3158	759	75.67	2026-10-01 00:00:00+03
3159	760	76.00	2026-10-01 00:00:00+03
3160	761	76.33	2026-10-01 00:00:00+03
3161	762	76.67	2026-10-01 00:00:00+03
3162	763	77.00	2026-10-01 00:00:00+03
3163	764	77.33	2026-10-01 00:00:00+03
3164	765	77.67	2026-10-01 00:00:00+03
3165	766	78.00	2026-10-01 00:00:00+03
3166	767	78.33	2026-10-01 00:00:00+03
3167	768	78.67	2026-10-01 00:00:00+03
3168	769	79.00	2026-10-01 00:00:00+03
3169	770	79.33	2026-10-01 00:00:00+03
3170	771	79.67	2026-10-01 00:00:00+03
3171	772	80.00	2026-10-01 00:00:00+03
3172	773	80.33	2026-10-01 00:00:00+03
3173	774	80.67	2026-10-01 00:00:00+03
3174	775	81.00	2026-10-01 00:00:00+03
3175	776	81.33	2026-10-01 00:00:00+03
3176	777	81.67	2026-10-01 00:00:00+03
3177	778	82.00	2026-10-01 00:00:00+03
3178	779	82.33	2026-10-01 00:00:00+03
3179	780	82.67	2026-10-01 00:00:00+03
3180	781	83.00	2026-10-01 00:00:00+03
3181	782	83.33	2026-10-01 00:00:00+03
3182	783	83.67	2026-10-01 00:00:00+03
3183	784	84.00	2026-10-01 00:00:00+03
3184	785	84.33	2026-10-01 00:00:00+03
3185	786	84.67	2026-10-01 00:00:00+03
3186	787	85.00	2026-10-01 00:00:00+03
3187	788	85.33	2026-10-01 00:00:00+03
3188	789	85.67	2026-10-01 00:00:00+03
3189	790	86.00	2026-10-01 00:00:00+03
3190	791	86.33	2026-10-01 00:00:00+03
3191	792	86.67	2026-10-01 00:00:00+03
3192	793	87.00	2026-10-01 00:00:00+03
3193	794	87.33	2026-10-01 00:00:00+03
3194	795	87.67	2026-10-01 00:00:00+03
3195	796	88.00	2026-10-01 00:00:00+03
3196	797	88.33	2026-10-01 00:00:00+03
3197	798	88.67	2026-10-01 00:00:00+03
3198	799	89.00	2026-10-01 00:00:00+03
3199	800	89.33	2026-10-01 00:00:00+03
3200	801	89.67	2026-10-01 00:00:00+03
3201	802	90.00	2026-10-01 00:00:00+03
3202	803	90.33	2026-10-01 00:00:00+03
3203	804	90.67	2026-10-01 00:00:00+03
3204	805	91.00	2026-10-01 00:00:00+03
3205	806	91.33	2026-10-01 00:00:00+03
3206	807	91.67	2026-10-01 00:00:00+03
3207	808	92.00	2026-10-01 00:00:00+03
3208	809	92.33	2026-10-01 00:00:00+03
3209	810	92.67	2026-10-01 00:00:00+03
3210	811	93.00	2026-10-01 00:00:00+03
3211	812	93.33	2026-10-01 00:00:00+03
3212	813	93.67	2026-10-01 00:00:00+03
3213	814	94.00	2026-10-01 00:00:00+03
3214	815	94.33	2026-10-01 00:00:00+03
3215	816	94.67	2026-10-01 00:00:00+03
3216	817	95.00	2026-10-01 00:00:00+03
3217	818	95.33	2026-10-01 00:00:00+03
3218	819	95.67	2026-10-01 00:00:00+03
3219	820	96.00	2026-10-01 00:00:00+03
3220	821	96.33	2026-10-01 00:00:00+03
3221	822	96.67	2026-10-01 00:00:00+03
3222	823	97.00	2026-10-01 00:00:00+03
3223	824	97.33	2026-10-01 00:00:00+03
3224	825	97.67	2026-10-01 00:00:00+03
3225	826	98.00	2026-10-01 00:00:00+03
3226	827	98.33	2026-10-01 00:00:00+03
3227	828	98.67	2026-10-01 00:00:00+03
3228	829	99.00	2026-10-01 00:00:00+03
3229	830	99.33	2026-10-01 00:00:00+03
3230	831	99.67	2026-10-01 00:00:00+03
3231	832	100.00	2026-10-01 00:00:00+03
3232	833	100.33	2026-10-01 00:00:00+03
3233	834	100.67	2026-10-01 00:00:00+03
3234	835	101.00	2026-10-01 00:00:00+03
3235	836	101.33	2026-10-01 00:00:00+03
3236	837	101.67	2026-10-01 00:00:00+03
3237	838	102.00	2026-10-01 00:00:00+03
3238	839	102.33	2026-10-01 00:00:00+03
3239	840	102.67	2026-10-01 00:00:00+03
3240	841	103.00	2026-10-01 00:00:00+03
3241	842	103.33	2026-10-01 00:00:00+03
3242	843	103.67	2026-10-01 00:00:00+03
3243	844	104.00	2026-10-01 00:00:00+03
3244	845	104.33	2026-10-01 00:00:00+03
3245	846	104.67	2026-10-01 00:00:00+03
3246	847	105.00	2026-10-01 00:00:00+03
3247	848	105.33	2026-10-01 00:00:00+03
3248	849	105.67	2026-10-01 00:00:00+03
3249	850	106.00	2026-10-01 00:00:00+03
3250	851	106.33	2026-10-01 00:00:00+03
3251	852	106.67	2026-10-01 00:00:00+03
3252	853	107.00	2026-10-01 00:00:00+03
3253	854	107.33	2026-10-01 00:00:00+03
3254	855	107.67	2026-10-01 00:00:00+03
3255	856	108.00	2026-10-01 00:00:00+03
3256	857	108.33	2026-10-01 00:00:00+03
3257	858	108.67	2026-10-01 00:00:00+03
3258	859	109.00	2026-10-01 00:00:00+03
3259	860	109.33	2026-10-01 00:00:00+03
3260	861	109.67	2026-10-01 00:00:00+03
3261	862	110.00	2026-10-01 00:00:00+03
3262	863	110.33	2026-10-01 00:00:00+03
3263	864	110.67	2026-10-01 00:00:00+03
3264	865	111.00	2026-10-01 00:00:00+03
3265	866	111.33	2026-10-01 00:00:00+03
3266	867	111.67	2026-10-01 00:00:00+03
3267	868	112.00	2026-10-01 00:00:00+03
3268	869	112.33	2026-10-01 00:00:00+03
3269	870	112.67	2026-10-01 00:00:00+03
3270	871	113.00	2026-10-01 00:00:00+03
3271	872	113.33	2026-10-01 00:00:00+03
3272	873	113.67	2026-10-01 00:00:00+03
3273	874	114.00	2026-10-01 00:00:00+03
3274	875	114.33	2026-10-01 00:00:00+03
3275	876	114.67	2026-10-01 00:00:00+03
3276	877	115.00	2026-10-01 00:00:00+03
3277	878	115.33	2026-10-01 00:00:00+03
3278	879	115.67	2026-10-01 00:00:00+03
3279	880	116.00	2026-10-01 00:00:00+03
3280	881	116.33	2026-10-01 00:00:00+03
3281	882	116.67	2026-10-01 00:00:00+03
3282	883	117.00	2026-10-01 00:00:00+03
3283	884	117.33	2026-10-01 00:00:00+03
3284	885	117.67	2026-10-01 00:00:00+03
3285	886	118.00	2026-10-01 00:00:00+03
3286	887	118.33	2026-10-01 00:00:00+03
3287	888	118.67	2026-10-01 00:00:00+03
3288	889	119.00	2026-10-01 00:00:00+03
3289	890	119.33	2026-10-01 00:00:00+03
3290	891	119.67	2026-10-01 00:00:00+03
3291	892	120.00	2026-10-01 00:00:00+03
3292	893	120.33	2026-10-01 00:00:00+03
3293	894	120.67	2026-10-01 00:00:00+03
3294	895	121.00	2026-10-01 00:00:00+03
3295	896	121.33	2026-10-01 00:00:00+03
3296	897	121.67	2026-10-01 00:00:00+03
3297	898	122.00	2026-10-01 00:00:00+03
3298	899	122.33	2026-10-01 00:00:00+03
3299	900	122.67	2026-10-01 00:00:00+03
3300	901	123.00	2026-10-01 00:00:00+03
3301	902	123.33	2026-10-01 00:00:00+03
3302	903	123.67	2026-10-01 00:00:00+03
3303	904	124.00	2026-10-01 00:00:00+03
3304	905	124.33	2026-10-01 00:00:00+03
3305	906	124.67	2026-10-01 00:00:00+03
3306	907	125.00	2026-10-01 00:00:00+03
3307	908	125.33	2026-10-01 00:00:00+03
3308	909	125.67	2026-10-01 00:00:00+03
3309	910	126.00	2026-10-01 00:00:00+03
3310	911	126.33	2026-10-01 00:00:00+03
3311	912	126.67	2026-10-01 00:00:00+03
3312	913	127.00	2026-10-01 00:00:00+03
3313	914	127.33	2026-10-01 00:00:00+03
3314	915	127.67	2026-10-01 00:00:00+03
3315	916	128.00	2026-10-01 00:00:00+03
3316	917	128.33	2026-10-01 00:00:00+03
3317	918	128.67	2026-10-01 00:00:00+03
3318	919	129.00	2026-10-01 00:00:00+03
3319	920	129.33	2026-10-01 00:00:00+03
3320	921	129.67	2026-10-01 00:00:00+03
3321	922	130.00	2026-10-01 00:00:00+03
3322	923	130.33	2026-10-01 00:00:00+03
3323	924	130.67	2026-10-01 00:00:00+03
3324	925	131.00	2026-10-01 00:00:00+03
3325	926	131.33	2026-10-01 00:00:00+03
3326	927	131.67	2026-10-01 00:00:00+03
3327	928	132.00	2026-10-01 00:00:00+03
3328	929	132.33	2026-10-01 00:00:00+03
3329	930	132.67	2026-10-01 00:00:00+03
3330	931	133.00	2026-10-01 00:00:00+03
3331	932	133.33	2026-10-01 00:00:00+03
3332	933	133.67	2026-10-01 00:00:00+03
3333	934	134.00	2026-10-01 00:00:00+03
3334	935	134.33	2026-10-01 00:00:00+03
3335	936	134.67	2026-10-01 00:00:00+03
3336	937	135.00	2026-10-01 00:00:00+03
3337	938	135.33	2026-10-01 00:00:00+03
3338	939	135.67	2026-10-01 00:00:00+03
3339	940	136.00	2026-10-01 00:00:00+03
3340	941	136.33	2026-10-01 00:00:00+03
3341	942	136.67	2026-10-01 00:00:00+03
3342	943	137.00	2026-10-01 00:00:00+03
3343	944	137.33	2026-10-01 00:00:00+03
3344	945	137.67	2026-10-01 00:00:00+03
3345	946	138.00	2026-10-01 00:00:00+03
3346	947	138.33	2026-10-01 00:00:00+03
3347	948	138.67	2026-10-01 00:00:00+03
3348	949	139.00	2026-10-01 00:00:00+03
3349	950	139.33	2026-10-01 00:00:00+03
3350	951	139.67	2026-10-01 00:00:00+03
3351	952	140.00	2026-10-01 00:00:00+03
3352	953	140.33	2026-10-01 00:00:00+03
3353	954	140.67	2026-10-01 00:00:00+03
3354	955	141.00	2026-10-01 00:00:00+03
3355	956	141.33	2026-10-01 00:00:00+03
3356	957	141.67	2026-10-01 00:00:00+03
3357	958	142.00	2026-10-01 00:00:00+03
3358	959	142.33	2026-10-01 00:00:00+03
3359	960	142.67	2026-10-01 00:00:00+03
3360	961	143.00	2026-10-01 00:00:00+03
3361	962	143.33	2026-10-01 00:00:00+03
3362	963	143.67	2026-10-01 00:00:00+03
3363	964	144.00	2026-10-01 00:00:00+03
3364	965	144.33	2026-10-01 00:00:00+03
3365	966	144.67	2026-10-01 00:00:00+03
3366	967	145.00	2026-10-01 00:00:00+03
3367	968	145.33	2026-10-01 00:00:00+03
3368	969	145.67	2026-10-01 00:00:00+03
3369	970	146.00	2026-10-01 00:00:00+03
3370	971	146.33	2026-10-01 00:00:00+03
3371	972	146.67	2026-10-01 00:00:00+03
3372	973	147.00	2026-10-01 00:00:00+03
3373	974	147.33	2026-10-01 00:00:00+03
3374	975	147.67	2026-10-01 00:00:00+03
3375	976	148.00	2026-10-01 00:00:00+03
3376	977	148.33	2026-10-01 00:00:00+03
3377	978	148.67	2026-10-01 00:00:00+03
3378	979	149.00	2026-10-01 00:00:00+03
3379	980	149.33	2026-10-01 00:00:00+03
3380	981	149.67	2026-10-01 00:00:00+03
3381	982	150.00	2026-10-01 00:00:00+03
3382	983	150.33	2026-10-01 00:00:00+03
3383	984	150.67	2026-10-01 00:00:00+03
3384	985	151.00	2026-10-01 00:00:00+03
3385	986	151.33	2026-10-01 00:00:00+03
3386	987	151.67	2026-10-01 00:00:00+03
3387	988	152.00	2026-10-01 00:00:00+03
3388	989	152.33	2026-10-01 00:00:00+03
3389	990	152.67	2026-10-01 00:00:00+03
3390	991	153.00	2026-10-01 00:00:00+03
3391	992	153.33	2026-10-01 00:00:00+03
3392	993	153.67	2026-10-01 00:00:00+03
3393	994	154.00	2026-10-01 00:00:00+03
3394	995	154.33	2026-10-01 00:00:00+03
3395	996	154.67	2026-10-01 00:00:00+03
3396	997	155.00	2026-10-01 00:00:00+03
3397	998	155.33	2026-10-01 00:00:00+03
3398	999	155.67	2026-10-01 00:00:00+03
3399	1000	156.00	2026-10-01 00:00:00+03
3400	1001	156.33	2026-10-01 00:00:00+03
3401	1002	156.67	2026-10-01 00:00:00+03
3402	1003	157.00	2026-10-01 00:00:00+03
3403	1004	157.33	2026-10-01 00:00:00+03
3404	1005	157.67	2026-10-01 00:00:00+03
3405	1006	158.00	2026-10-01 00:00:00+03
3406	1007	158.33	2026-10-01 00:00:00+03
3407	1008	158.67	2026-10-01 00:00:00+03
3408	1009	159.00	2026-10-01 00:00:00+03
3409	1010	159.33	2026-10-01 00:00:00+03
3410	1011	159.67	2026-10-01 00:00:00+03
3411	1012	160.00	2026-10-01 00:00:00+03
3412	1013	160.33	2026-10-01 00:00:00+03
3413	1014	160.67	2026-10-01 00:00:00+03
3414	1015	161.00	2026-10-01 00:00:00+03
3415	1016	161.33	2026-10-01 00:00:00+03
3416	1017	161.67	2026-10-01 00:00:00+03
3417	1018	162.00	2026-10-01 00:00:00+03
3418	1019	162.33	2026-10-01 00:00:00+03
3419	1020	162.67	2026-10-01 00:00:00+03
3420	1021	163.00	2026-10-01 00:00:00+03
3421	1022	163.33	2026-10-01 00:00:00+03
3422	1023	163.67	2026-10-01 00:00:00+03
3423	1024	164.00	2026-10-01 00:00:00+03
3424	1025	164.33	2026-10-01 00:00:00+03
3425	1026	164.67	2026-10-01 00:00:00+03
3426	1027	165.00	2026-10-01 00:00:00+03
3427	1028	165.33	2026-10-01 00:00:00+03
3428	1029	165.67	2026-10-01 00:00:00+03
3429	1030	166.00	2026-10-01 00:00:00+03
3430	1031	166.33	2026-10-01 00:00:00+03
3431	1032	166.67	2026-10-01 00:00:00+03
3432	1033	167.00	2026-10-01 00:00:00+03
3433	1034	167.33	2026-10-01 00:00:00+03
3434	1035	167.67	2026-10-01 00:00:00+03
3435	1036	168.00	2026-10-01 00:00:00+03
3436	1037	168.33	2026-10-01 00:00:00+03
3437	1038	168.67	2026-10-01 00:00:00+03
3438	1039	169.00	2026-10-01 00:00:00+03
3439	1040	169.33	2026-10-01 00:00:00+03
3440	1041	169.67	2026-10-01 00:00:00+03
3441	1042	170.00	2026-10-01 00:00:00+03
3442	1043	170.33	2026-10-01 00:00:00+03
3443	1044	170.67	2026-10-01 00:00:00+03
3444	1045	171.00	2026-10-01 00:00:00+03
3445	1046	171.33	2026-10-01 00:00:00+03
3446	1047	171.67	2026-10-01 00:00:00+03
3447	1048	172.00	2026-10-01 00:00:00+03
3448	1049	172.33	2026-10-01 00:00:00+03
3449	1050	172.67	2026-10-01 00:00:00+03
3450	1051	173.00	2026-10-01 00:00:00+03
3451	1052	173.33	2026-10-01 00:00:00+03
3452	1053	173.67	2026-10-01 00:00:00+03
3453	1054	174.00	2026-10-01 00:00:00+03
3454	1055	174.33	2026-10-01 00:00:00+03
3455	1056	174.67	2026-10-01 00:00:00+03
3456	1057	175.00	2026-10-01 00:00:00+03
3457	1058	175.33	2026-10-01 00:00:00+03
3458	1059	175.67	2026-10-01 00:00:00+03
3459	1060	176.00	2026-10-01 00:00:00+03
3460	1061	176.33	2026-10-01 00:00:00+03
3461	1062	176.67	2026-10-01 00:00:00+03
3462	1063	177.00	2026-10-01 00:00:00+03
3463	1064	177.33	2026-10-01 00:00:00+03
3464	1065	177.67	2026-10-01 00:00:00+03
3465	1066	178.00	2026-10-01 00:00:00+03
3466	1067	178.33	2026-10-01 00:00:00+03
3467	1068	178.67	2026-10-01 00:00:00+03
3468	1069	179.00	2026-10-01 00:00:00+03
3469	1070	179.33	2026-10-01 00:00:00+03
3470	1071	179.67	2026-10-01 00:00:00+03
3471	1072	180.00	2026-10-01 00:00:00+03
3472	1073	180.33	2026-10-01 00:00:00+03
3473	1074	180.67	2026-10-01 00:00:00+03
3474	1075	181.00	2026-10-01 00:00:00+03
3475	1076	181.33	2026-10-01 00:00:00+03
3476	1077	181.67	2026-10-01 00:00:00+03
3477	1078	182.00	2026-10-01 00:00:00+03
3478	1079	182.33	2026-10-01 00:00:00+03
3479	1080	182.67	2026-10-01 00:00:00+03
3480	1081	183.00	2026-10-01 00:00:00+03
3481	1082	183.33	2026-10-01 00:00:00+03
3482	1083	183.67	2026-10-01 00:00:00+03
3483	1084	184.00	2026-10-01 00:00:00+03
3484	1085	184.33	2026-10-01 00:00:00+03
3485	1086	184.67	2026-10-01 00:00:00+03
3486	1087	185.00	2026-10-01 00:00:00+03
3487	1088	185.33	2026-10-01 00:00:00+03
3488	1089	185.67	2026-10-01 00:00:00+03
3489	1090	186.00	2026-10-01 00:00:00+03
3490	1091	186.33	2026-10-01 00:00:00+03
3491	1092	186.67	2026-10-01 00:00:00+03
3492	1093	187.00	2026-10-01 00:00:00+03
3493	1094	187.33	2026-10-01 00:00:00+03
3494	1095	187.67	2026-10-01 00:00:00+03
3495	1096	188.00	2026-10-01 00:00:00+03
3496	1097	188.33	2026-10-01 00:00:00+03
3497	1098	188.67	2026-10-01 00:00:00+03
3498	1099	189.00	2026-10-01 00:00:00+03
3499	1100	189.33	2026-10-01 00:00:00+03
3500	1101	189.67	2026-10-01 00:00:00+03
3501	1102	190.00	2026-10-01 00:00:00+03
3502	1103	190.33	2026-10-01 00:00:00+03
3503	1104	190.67	2026-10-01 00:00:00+03
3504	1105	191.00	2026-10-01 00:00:00+03
3505	1106	191.33	2026-10-01 00:00:00+03
3506	1107	191.67	2026-10-01 00:00:00+03
3507	1108	192.00	2026-10-01 00:00:00+03
3508	1109	192.33	2026-10-01 00:00:00+03
3509	1110	192.67	2026-10-01 00:00:00+03
3510	1111	193.00	2026-10-01 00:00:00+03
3511	1112	193.33	2026-10-01 00:00:00+03
3512	1113	193.67	2026-10-01 00:00:00+03
3513	1114	194.00	2026-10-01 00:00:00+03
3514	1115	194.33	2026-10-01 00:00:00+03
3515	1116	194.67	2026-10-01 00:00:00+03
3516	1117	195.00	2026-10-01 00:00:00+03
3517	1118	195.33	2026-10-01 00:00:00+03
3518	1119	195.67	2026-10-01 00:00:00+03
3519	1120	196.00	2026-10-01 00:00:00+03
3520	1121	196.33	2026-10-01 00:00:00+03
3521	1122	196.67	2026-10-01 00:00:00+03
3522	1123	197.00	2026-10-01 00:00:00+03
3523	1124	197.33	2026-10-01 00:00:00+03
3524	1125	197.67	2026-10-01 00:00:00+03
3525	1126	198.00	2026-10-01 00:00:00+03
3526	1127	198.33	2026-10-01 00:00:00+03
3527	1128	198.67	2026-10-01 00:00:00+03
3528	1129	199.00	2026-10-01 00:00:00+03
3529	1130	199.33	2026-10-01 00:00:00+03
3530	1131	199.67	2026-10-01 00:00:00+03
3531	1132	200.00	2026-10-01 00:00:00+03
3532	1133	200.33	2026-10-01 00:00:00+03
3533	1134	200.67	2026-10-01 00:00:00+03
3534	1135	201.00	2026-10-01 00:00:00+03
3535	1136	201.33	2026-10-01 00:00:00+03
3536	1137	201.67	2026-10-01 00:00:00+03
3537	1138	202.00	2026-10-01 00:00:00+03
3538	1139	202.33	2026-10-01 00:00:00+03
3539	1140	202.67	2026-10-01 00:00:00+03
3540	1141	203.00	2026-10-01 00:00:00+03
3541	1142	203.33	2026-10-01 00:00:00+03
3542	1143	203.67	2026-10-01 00:00:00+03
3543	1144	204.00	2026-10-01 00:00:00+03
3544	1145	204.33	2026-10-01 00:00:00+03
3545	1146	204.67	2026-10-01 00:00:00+03
3546	1147	205.00	2026-10-01 00:00:00+03
3547	1148	205.33	2026-10-01 00:00:00+03
3548	1149	205.67	2026-10-01 00:00:00+03
3549	1150	206.00	2026-10-01 00:00:00+03
3550	1151	206.33	2026-10-01 00:00:00+03
3551	1152	206.67	2026-10-01 00:00:00+03
3552	1153	207.00	2026-10-01 00:00:00+03
3553	1154	207.33	2026-10-01 00:00:00+03
3554	1155	207.67	2026-10-01 00:00:00+03
3555	1156	208.00	2026-10-01 00:00:00+03
3556	1157	208.33	2026-10-01 00:00:00+03
3557	1158	208.67	2026-10-01 00:00:00+03
3558	1159	209.00	2026-10-01 00:00:00+03
3559	1160	209.33	2026-10-01 00:00:00+03
3560	1161	209.67	2026-10-01 00:00:00+03
3561	1162	210.00	2026-10-01 00:00:00+03
3562	1163	210.33	2026-10-01 00:00:00+03
3563	1164	210.67	2026-10-01 00:00:00+03
3564	1165	211.00	2026-10-01 00:00:00+03
3565	1166	211.33	2026-10-01 00:00:00+03
3566	1167	211.67	2026-10-01 00:00:00+03
3567	1168	212.00	2026-10-01 00:00:00+03
3568	1169	212.33	2026-10-01 00:00:00+03
3569	1170	212.67	2026-10-01 00:00:00+03
3570	1171	213.00	2026-10-01 00:00:00+03
3571	1172	213.33	2026-10-01 00:00:00+03
3572	1173	213.67	2026-10-01 00:00:00+03
3573	1174	214.00	2026-10-01 00:00:00+03
3574	1175	214.33	2026-10-01 00:00:00+03
3575	1176	214.67	2026-10-01 00:00:00+03
3576	1177	215.00	2026-10-01 00:00:00+03
3577	1178	215.33	2026-10-01 00:00:00+03
3578	1179	215.67	2026-10-01 00:00:00+03
3579	1180	216.00	2026-10-01 00:00:00+03
3580	1181	216.33	2026-10-01 00:00:00+03
3581	1182	216.67	2026-10-01 00:00:00+03
3582	1183	217.00	2026-10-01 00:00:00+03
3583	1184	217.33	2026-10-01 00:00:00+03
3584	1185	217.67	2026-10-01 00:00:00+03
3585	1186	218.00	2026-10-01 00:00:00+03
3586	1187	218.33	2026-10-01 00:00:00+03
3587	1188	218.67	2026-10-01 00:00:00+03
3588	1189	219.00	2026-10-01 00:00:00+03
3589	1190	219.33	2026-10-01 00:00:00+03
3590	1191	219.67	2026-10-01 00:00:00+03
3591	1192	220.00	2026-10-01 00:00:00+03
3592	1193	220.33	2026-10-01 00:00:00+03
3593	1194	220.67	2026-10-01 00:00:00+03
3594	1195	221.00	2026-10-01 00:00:00+03
3595	1196	221.33	2026-10-01 00:00:00+03
3596	1197	221.67	2026-10-01 00:00:00+03
3597	1198	222.00	2026-10-01 00:00:00+03
3598	1199	222.33	2026-10-01 00:00:00+03
3599	1200	222.67	2026-10-01 00:00:00+03
3600	1	223.00	2026-10-01 00:00:00+03
3601	2	223.33	2026-10-01 00:00:00+03
3602	3	223.67	2026-10-01 00:00:00+03
3603	4	224.00	2026-10-01 00:00:00+03
3604	5	224.33	2026-10-01 00:00:00+03
3605	6	224.67	2026-10-01 00:00:00+03
3606	7	225.00	2026-10-01 00:00:00+03
3607	8	225.33	2026-10-01 00:00:00+03
3608	9	225.67	2026-10-01 00:00:00+03
3609	10	226.00	2026-10-01 00:00:00+03
3610	11	226.33	2026-10-01 00:00:00+03
3611	12	226.67	2026-10-01 00:00:00+03
3612	13	227.00	2026-10-01 00:00:00+03
3613	14	227.33	2026-10-01 00:00:00+03
3614	15	227.67	2026-10-01 00:00:00+03
3615	16	228.00	2026-10-01 00:00:00+03
3616	17	228.33	2026-10-01 00:00:00+03
3617	18	228.67	2026-10-01 00:00:00+03
3618	19	229.00	2026-10-01 00:00:00+03
3619	20	229.33	2026-10-01 00:00:00+03
3620	21	229.67	2026-10-01 00:00:00+03
3621	22	230.00	2026-10-01 00:00:00+03
3622	23	230.33	2026-10-01 00:00:00+03
3623	24	230.67	2026-10-01 00:00:00+03
3624	25	231.00	2026-10-01 00:00:00+03
3625	26	231.33	2026-10-01 00:00:00+03
3626	27	231.67	2026-10-01 00:00:00+03
3627	28	232.00	2026-10-01 00:00:00+03
3628	29	232.33	2026-10-01 00:00:00+03
3629	30	232.67	2026-10-01 00:00:00+03
3630	31	233.00	2026-10-01 00:00:00+03
3631	32	233.33	2026-10-01 00:00:00+03
3632	33	233.67	2026-10-01 00:00:00+03
3633	34	234.00	2026-10-01 00:00:00+03
3634	35	234.33	2026-10-01 00:00:00+03
3635	36	234.67	2026-10-01 00:00:00+03
3636	37	235.00	2026-10-01 00:00:00+03
3637	38	235.33	2026-10-01 00:00:00+03
3638	39	235.67	2026-10-01 00:00:00+03
3639	40	236.00	2026-10-01 00:00:00+03
3640	41	236.33	2026-10-01 00:00:00+03
3641	42	236.67	2026-10-01 00:00:00+03
3642	43	237.00	2026-10-01 00:00:00+03
3643	44	237.33	2026-10-01 00:00:00+03
3644	45	237.67	2026-10-01 00:00:00+03
3645	46	238.00	2026-10-01 00:00:00+03
3646	47	238.33	2026-10-01 00:00:00+03
3647	48	238.67	2026-10-01 00:00:00+03
3648	49	239.00	2026-10-01 00:00:00+03
3649	50	239.33	2026-10-01 00:00:00+03
3650	51	239.67	2026-10-01 00:00:00+03
3651	52	240.00	2026-10-01 00:00:00+03
3652	53	240.33	2026-10-01 00:00:00+03
3653	54	240.67	2026-10-01 00:00:00+03
3654	55	241.00	2026-10-01 00:00:00+03
3655	56	241.33	2026-10-01 00:00:00+03
3656	57	241.67	2026-10-01 00:00:00+03
3657	58	242.00	2026-10-01 00:00:00+03
3658	59	242.33	2026-10-01 00:00:00+03
3659	60	242.67	2026-10-01 00:00:00+03
3660	61	243.00	2026-10-01 00:00:00+03
3661	62	243.33	2026-10-01 00:00:00+03
3662	63	243.67	2026-10-01 00:00:00+03
3663	64	244.00	2026-10-01 00:00:00+03
3664	65	244.33	2026-10-01 00:00:00+03
3665	66	244.67	2026-10-01 00:00:00+03
3666	67	245.00	2026-10-01 00:00:00+03
3667	68	245.33	2026-10-01 00:00:00+03
3668	69	245.67	2026-10-01 00:00:00+03
3669	70	246.00	2026-10-01 00:00:00+03
3670	71	246.33	2026-10-01 00:00:00+03
3671	72	246.67	2026-10-01 00:00:00+03
3672	73	247.00	2026-10-01 00:00:00+03
3673	74	247.33	2026-10-01 00:00:00+03
3674	75	247.67	2026-10-01 00:00:00+03
3675	76	248.00	2026-10-01 00:00:00+03
3676	77	248.33	2026-10-01 00:00:00+03
3677	78	248.67	2026-10-01 00:00:00+03
3678	79	249.00	2026-10-01 00:00:00+03
3679	80	249.33	2026-10-01 00:00:00+03
3680	81	249.67	2026-10-01 00:00:00+03
3681	82	250.00	2026-10-01 00:00:00+03
3682	83	250.33	2026-10-01 00:00:00+03
3683	84	250.67	2026-10-01 00:00:00+03
3684	85	251.00	2026-10-01 00:00:00+03
3685	86	251.33	2026-10-01 00:00:00+03
3686	87	251.67	2026-10-01 00:00:00+03
3687	88	252.00	2026-10-01 00:00:00+03
3688	89	252.33	2026-10-01 00:00:00+03
3689	90	252.67	2026-10-01 00:00:00+03
3690	91	253.00	2026-10-01 00:00:00+03
3691	92	253.33	2026-10-01 00:00:00+03
3692	93	253.67	2026-10-01 00:00:00+03
3693	94	254.00	2026-10-01 00:00:00+03
3694	95	254.33	2026-10-01 00:00:00+03
3695	96	254.67	2026-10-01 00:00:00+03
3696	97	255.00	2026-10-01 00:00:00+03
3697	98	255.33	2026-10-01 00:00:00+03
3698	99	255.67	2026-10-01 00:00:00+03
3699	100	256.00	2026-10-01 00:00:00+03
3700	101	256.33	2026-10-01 00:00:00+03
3701	102	256.67	2026-10-01 00:00:00+03
3702	103	257.00	2026-10-01 00:00:00+03
3703	104	257.33	2026-10-01 00:00:00+03
3704	105	257.67	2026-10-01 00:00:00+03
3705	106	258.00	2026-10-01 00:00:00+03
3706	107	258.33	2026-10-01 00:00:00+03
3707	108	258.67	2026-10-01 00:00:00+03
3708	109	259.00	2026-10-01 00:00:00+03
3709	110	259.33	2026-10-01 00:00:00+03
3710	111	259.67	2026-10-01 00:00:00+03
3711	112	260.00	2026-10-01 00:00:00+03
3712	113	260.33	2026-10-01 00:00:00+03
3713	114	260.67	2026-10-01 00:00:00+03
3714	115	261.00	2026-10-01 00:00:00+03
3715	116	261.33	2026-10-01 00:00:00+03
3716	117	261.67	2026-10-01 00:00:00+03
3717	118	262.00	2026-10-01 00:00:00+03
3718	119	262.33	2026-10-01 00:00:00+03
3719	120	262.67	2026-10-01 00:00:00+03
3720	121	263.00	2026-10-01 00:00:00+03
3721	122	263.33	2026-10-01 00:00:00+03
3722	123	263.67	2026-10-01 00:00:00+03
3723	124	264.00	2026-10-01 00:00:00+03
3724	125	264.33	2026-10-01 00:00:00+03
3725	126	264.67	2026-10-01 00:00:00+03
3726	127	265.00	2026-10-01 00:00:00+03
3727	128	265.33	2026-10-01 00:00:00+03
3728	129	265.67	2026-10-01 00:00:00+03
3729	130	266.00	2026-10-01 00:00:00+03
3730	131	266.33	2026-10-01 00:00:00+03
3731	132	266.67	2026-10-01 00:00:00+03
3732	133	267.00	2026-10-01 00:00:00+03
3733	134	267.33	2026-10-01 00:00:00+03
3734	135	267.67	2026-10-01 00:00:00+03
3735	136	268.00	2026-10-01 00:00:00+03
3736	137	268.33	2026-10-01 00:00:00+03
3737	138	268.67	2026-10-01 00:00:00+03
3738	139	269.00	2026-10-01 00:00:00+03
3739	140	269.33	2026-10-01 00:00:00+03
3740	141	269.67	2026-10-01 00:00:00+03
3741	142	270.00	2026-10-01 00:00:00+03
3742	143	270.33	2026-10-01 00:00:00+03
3743	144	270.67	2026-10-01 00:00:00+03
3744	145	271.00	2026-10-01 00:00:00+03
3745	146	271.33	2026-10-01 00:00:00+03
3746	147	271.67	2026-10-01 00:00:00+03
3747	148	272.00	2026-10-01 00:00:00+03
3748	149	272.33	2026-10-01 00:00:00+03
3749	150	272.67	2026-10-01 00:00:00+03
3750	151	273.00	2026-10-01 00:00:00+03
3751	152	273.33	2026-10-01 00:00:00+03
3752	153	273.67	2026-10-01 00:00:00+03
3753	154	274.00	2026-10-01 00:00:00+03
3754	155	274.33	2026-10-01 00:00:00+03
3755	156	274.67	2026-10-01 00:00:00+03
3756	157	275.00	2026-10-01 00:00:00+03
3757	158	275.33	2026-10-01 00:00:00+03
3758	159	275.67	2026-10-01 00:00:00+03
3759	160	276.00	2026-10-01 00:00:00+03
3760	161	276.33	2026-10-01 00:00:00+03
3761	162	276.67	2026-10-01 00:00:00+03
3762	163	277.00	2026-10-01 00:00:00+03
3763	164	277.33	2026-10-01 00:00:00+03
3764	165	277.67	2026-10-01 00:00:00+03
3765	166	278.00	2026-10-01 00:00:00+03
3766	167	278.33	2026-10-01 00:00:00+03
3767	168	278.67	2026-10-01 00:00:00+03
3768	169	279.00	2026-10-01 00:00:00+03
3769	170	279.33	2026-10-01 00:00:00+03
3770	171	279.67	2026-10-01 00:00:00+03
3771	172	280.00	2026-10-01 00:00:00+03
3772	173	280.33	2026-10-01 00:00:00+03
3773	174	280.67	2026-10-01 00:00:00+03
3774	175	281.00	2026-10-01 00:00:00+03
3775	176	281.33	2026-10-01 00:00:00+03
3776	177	281.67	2026-10-01 00:00:00+03
3777	178	282.00	2026-10-01 00:00:00+03
3778	179	282.33	2026-10-01 00:00:00+03
3779	180	282.67	2026-10-01 00:00:00+03
3780	181	283.00	2026-10-01 00:00:00+03
3781	182	283.33	2026-10-01 00:00:00+03
3782	183	283.67	2026-10-01 00:00:00+03
3783	184	284.00	2026-10-01 00:00:00+03
3784	185	284.33	2026-10-01 00:00:00+03
3785	186	284.67	2026-10-01 00:00:00+03
3786	187	285.00	2026-10-01 00:00:00+03
3787	188	285.33	2026-10-01 00:00:00+03
3788	189	285.67	2026-10-01 00:00:00+03
3789	190	286.00	2026-10-01 00:00:00+03
3790	191	286.33	2026-10-01 00:00:00+03
3791	192	286.67	2026-10-01 00:00:00+03
3792	193	287.00	2026-10-01 00:00:00+03
3793	194	287.33	2026-10-01 00:00:00+03
3794	195	287.67	2026-10-01 00:00:00+03
3795	196	288.00	2026-10-01 00:00:00+03
3796	197	288.33	2026-10-01 00:00:00+03
3797	198	288.67	2026-10-01 00:00:00+03
3798	199	289.00	2026-10-01 00:00:00+03
3799	200	289.33	2026-10-01 00:00:00+03
3800	201	289.67	2026-10-01 00:00:00+03
3801	202	290.00	2026-10-01 00:00:00+03
3802	203	290.33	2026-10-01 00:00:00+03
3803	204	290.67	2026-10-01 00:00:00+03
3804	205	291.00	2026-10-01 00:00:00+03
3805	206	291.33	2026-10-01 00:00:00+03
3806	207	291.67	2026-10-01 00:00:00+03
3807	208	292.00	2026-10-01 00:00:00+03
3808	209	292.33	2026-10-01 00:00:00+03
3809	210	292.67	2026-10-01 00:00:00+03
3810	211	293.00	2026-10-01 00:00:00+03
3811	212	293.33	2026-10-01 00:00:00+03
3812	213	293.67	2026-10-01 00:00:00+03
3813	214	294.00	2026-10-01 00:00:00+03
3814	215	294.33	2026-10-01 00:00:00+03
3815	216	294.67	2026-10-01 00:00:00+03
3816	217	295.00	2026-10-01 00:00:00+03
3817	218	295.33	2026-10-01 00:00:00+03
3818	219	295.67	2026-10-01 00:00:00+03
3819	220	296.00	2026-10-01 00:00:00+03
3820	221	296.33	2026-10-01 00:00:00+03
3821	222	296.67	2026-10-01 00:00:00+03
3822	223	297.00	2026-10-01 00:00:00+03
3823	224	297.33	2026-10-01 00:00:00+03
3824	225	297.67	2026-10-01 00:00:00+03
3825	226	298.00	2026-10-01 00:00:00+03
3826	227	298.33	2026-10-01 00:00:00+03
3827	228	298.67	2026-10-01 00:00:00+03
3828	229	299.00	2026-10-01 00:00:00+03
3829	230	299.33	2026-10-01 00:00:00+03
3830	231	299.67	2026-10-01 00:00:00+03
3831	232	300.00	2026-10-01 00:00:00+03
3832	233	300.33	2026-10-01 00:00:00+03
3833	234	300.67	2026-10-01 00:00:00+03
3834	235	301.00	2026-10-01 00:00:00+03
3835	236	301.33	2026-10-01 00:00:00+03
3836	237	301.67	2026-10-01 00:00:00+03
3837	238	302.00	2026-10-01 00:00:00+03
3838	239	302.33	2026-10-01 00:00:00+03
3839	240	302.67	2026-10-01 00:00:00+03
3840	241	303.00	2026-10-01 00:00:00+03
3841	242	303.33	2026-10-01 00:00:00+03
3842	243	303.67	2026-10-01 00:00:00+03
3843	244	304.00	2026-10-01 00:00:00+03
3844	245	304.33	2026-10-01 00:00:00+03
3845	246	304.67	2026-10-01 00:00:00+03
3846	247	305.00	2026-10-01 00:00:00+03
3847	248	305.33	2026-10-01 00:00:00+03
3848	249	305.67	2026-10-01 00:00:00+03
3849	250	306.00	2026-10-01 00:00:00+03
3850	251	306.33	2026-10-01 00:00:00+03
3851	252	306.67	2026-10-01 00:00:00+03
3852	253	307.00	2026-10-01 00:00:00+03
3853	254	307.33	2026-10-01 00:00:00+03
3854	255	307.67	2026-10-01 00:00:00+03
3855	256	308.00	2026-10-01 00:00:00+03
3856	257	308.33	2026-10-01 00:00:00+03
3857	258	308.67	2026-10-01 00:00:00+03
3858	259	309.00	2026-10-01 00:00:00+03
3859	260	309.33	2026-10-01 00:00:00+03
3860	261	309.67	2026-10-01 00:00:00+03
3861	262	310.00	2026-10-01 00:00:00+03
3862	263	310.33	2026-10-01 00:00:00+03
3863	264	310.67	2026-10-01 00:00:00+03
3864	265	311.00	2026-10-01 00:00:00+03
3865	266	311.33	2026-10-01 00:00:00+03
3866	267	311.67	2026-10-01 00:00:00+03
3867	268	312.00	2026-10-01 00:00:00+03
3868	269	312.33	2026-10-01 00:00:00+03
3869	270	312.67	2026-10-01 00:00:00+03
3870	271	313.00	2026-10-01 00:00:00+03
3871	272	313.33	2026-10-01 00:00:00+03
3872	273	313.67	2026-10-01 00:00:00+03
3873	274	314.00	2026-10-01 00:00:00+03
3874	275	314.33	2026-10-01 00:00:00+03
3875	276	314.67	2026-10-01 00:00:00+03
3876	277	315.00	2026-10-01 00:00:00+03
3877	278	315.33	2026-10-01 00:00:00+03
3878	279	315.67	2026-10-01 00:00:00+03
3879	280	316.00	2026-10-01 00:00:00+03
3880	281	316.33	2026-10-01 00:00:00+03
3881	282	316.67	2026-10-01 00:00:00+03
3882	283	317.00	2026-10-01 00:00:00+03
3883	284	317.33	2026-10-01 00:00:00+03
3884	285	317.67	2026-10-01 00:00:00+03
3885	286	318.00	2026-10-01 00:00:00+03
3886	287	318.33	2026-10-01 00:00:00+03
3887	288	318.67	2026-10-01 00:00:00+03
3888	289	319.00	2026-10-01 00:00:00+03
3889	290	319.33	2026-10-01 00:00:00+03
3890	291	319.67	2026-10-01 00:00:00+03
3891	292	320.00	2026-10-01 00:00:00+03
3892	293	320.33	2026-10-01 00:00:00+03
3893	294	320.67	2026-10-01 00:00:00+03
3894	295	321.00	2026-10-01 00:00:00+03
3895	296	321.33	2026-10-01 00:00:00+03
3896	297	321.67	2026-10-01 00:00:00+03
3897	298	322.00	2026-10-01 00:00:00+03
3898	299	322.33	2026-10-01 00:00:00+03
3899	300	322.67	2026-10-01 00:00:00+03
3900	301	323.00	2026-10-01 00:00:00+03
3901	302	323.33	2026-10-01 00:00:00+03
3902	303	323.67	2026-10-01 00:00:00+03
3903	304	324.00	2026-10-01 00:00:00+03
3904	305	324.33	2026-10-01 00:00:00+03
3905	306	324.67	2026-10-01 00:00:00+03
3906	307	325.00	2026-10-01 00:00:00+03
3907	308	325.33	2026-10-01 00:00:00+03
3908	309	0.00	2026-10-01 00:00:00+03
3909	310	0.33	2026-10-01 00:00:00+03
3910	311	0.67	2026-10-01 00:00:00+03
3911	312	1.00	2026-10-01 00:00:00+03
3912	313	1.33	2026-10-01 00:00:00+03
3913	314	1.67	2026-10-01 00:00:00+03
3914	315	2.00	2026-10-01 00:00:00+03
3915	316	2.33	2026-10-01 00:00:00+03
3916	317	2.67	2026-10-01 00:00:00+03
3917	318	3.00	2026-10-01 00:00:00+03
3918	319	3.33	2026-10-01 00:00:00+03
3919	320	3.67	2026-10-01 00:00:00+03
3920	321	4.00	2026-10-01 00:00:00+03
3921	322	4.33	2026-10-01 00:00:00+03
3922	323	4.67	2026-10-01 00:00:00+03
3923	324	5.00	2026-10-01 00:00:00+03
3924	325	5.33	2026-10-01 00:00:00+03
3925	326	5.67	2026-10-01 00:00:00+03
3926	327	6.00	2026-10-01 00:00:00+03
3927	328	6.33	2026-10-01 00:00:00+03
3928	329	6.67	2026-10-01 00:00:00+03
3929	330	7.00	2026-10-01 00:00:00+03
3930	331	7.33	2026-10-01 00:00:00+03
3931	332	7.67	2026-10-01 00:00:00+03
3932	333	8.00	2026-10-01 00:00:00+03
3933	334	8.33	2026-10-01 00:00:00+03
3934	335	8.67	2026-10-01 00:00:00+03
3935	336	9.00	2026-10-01 00:00:00+03
3936	337	9.33	2026-10-01 00:00:00+03
3937	338	9.67	2026-10-01 00:00:00+03
3938	339	10.00	2026-10-01 00:00:00+03
3939	340	10.33	2026-10-01 00:00:00+03
3940	341	10.67	2026-10-01 00:00:00+03
3941	342	11.00	2026-10-01 00:00:00+03
3942	343	11.33	2026-10-01 00:00:00+03
3943	344	11.67	2026-10-01 00:00:00+03
3944	345	12.00	2026-10-01 00:00:00+03
3945	346	12.33	2026-10-01 00:00:00+03
3946	347	12.67	2026-10-01 00:00:00+03
3947	348	13.00	2026-10-01 00:00:00+03
3948	349	13.33	2026-10-01 00:00:00+03
3949	350	13.67	2026-10-01 00:00:00+03
3950	351	14.00	2026-10-01 00:00:00+03
3951	352	14.33	2026-10-01 00:00:00+03
3952	353	14.67	2026-10-01 00:00:00+03
3953	354	15.00	2026-10-01 00:00:00+03
3954	355	15.33	2026-10-01 00:00:00+03
3955	356	15.67	2026-10-01 00:00:00+03
3956	357	16.00	2026-10-01 00:00:00+03
3957	358	16.33	2026-10-01 00:00:00+03
3958	359	16.67	2026-10-01 00:00:00+03
3959	360	17.00	2026-10-01 00:00:00+03
3960	361	17.33	2026-10-01 00:00:00+03
3961	362	17.67	2026-10-01 00:00:00+03
3962	363	18.00	2026-10-01 00:00:00+03
3963	364	18.33	2026-10-01 00:00:00+03
3964	365	18.67	2026-10-01 00:00:00+03
3965	366	19.00	2026-10-01 00:00:00+03
3966	367	19.33	2026-10-01 00:00:00+03
3967	368	19.67	2026-10-01 00:00:00+03
3968	369	20.00	2026-10-01 00:00:00+03
3969	370	20.33	2026-10-01 00:00:00+03
3970	371	20.67	2026-10-01 00:00:00+03
3971	372	21.00	2026-10-01 00:00:00+03
3972	373	21.33	2026-10-01 00:00:00+03
3973	374	21.67	2026-10-01 00:00:00+03
3974	375	22.00	2026-10-01 00:00:00+03
3975	376	22.33	2026-10-01 00:00:00+03
3976	377	22.67	2026-10-01 00:00:00+03
3977	378	23.00	2026-10-01 00:00:00+03
3978	379	23.33	2026-10-01 00:00:00+03
3979	380	23.67	2026-10-01 00:00:00+03
3980	381	24.00	2026-10-01 00:00:00+03
3981	382	24.33	2026-10-01 00:00:00+03
3982	383	24.67	2026-10-01 00:00:00+03
3983	384	25.00	2026-10-01 00:00:00+03
3984	385	25.33	2026-10-01 00:00:00+03
3985	386	25.67	2026-10-01 00:00:00+03
3986	387	26.00	2026-10-01 00:00:00+03
3987	388	26.33	2026-10-01 00:00:00+03
3988	389	26.67	2026-10-01 00:00:00+03
3989	390	27.00	2026-10-01 00:00:00+03
3990	391	27.33	2026-10-01 00:00:00+03
3991	392	27.67	2026-10-01 00:00:00+03
3992	393	28.00	2026-10-01 00:00:00+03
3993	394	28.33	2026-10-01 00:00:00+03
3994	395	28.67	2026-10-01 00:00:00+03
3995	396	29.00	2026-10-01 00:00:00+03
3996	397	29.33	2026-10-01 00:00:00+03
3997	398	29.67	2026-10-01 00:00:00+03
3998	399	30.00	2026-10-01 00:00:00+03
3999	400	30.33	2026-10-01 00:00:00+03
4000	401	30.67	2026-10-01 00:00:00+03
4001	402	31.00	2026-10-01 00:00:00+03
4002	403	31.33	2026-10-01 00:00:00+03
4003	404	31.67	2026-10-01 00:00:00+03
4004	405	32.00	2026-10-01 00:00:00+03
4005	406	32.33	2026-10-01 00:00:00+03
4006	407	32.67	2026-10-01 00:00:00+03
4007	408	33.00	2026-10-01 00:00:00+03
4008	409	33.33	2026-10-01 00:00:00+03
4009	410	33.67	2026-10-01 00:00:00+03
4010	411	34.00	2026-10-01 00:00:00+03
4011	412	34.33	2026-10-01 00:00:00+03
4012	413	34.67	2026-10-01 00:00:00+03
4013	414	35.00	2026-10-01 00:00:00+03
4014	415	35.33	2026-10-01 00:00:00+03
4015	416	35.67	2026-10-01 00:00:00+03
4016	417	36.00	2026-10-01 00:00:00+03
4017	418	36.33	2026-10-01 00:00:00+03
4018	419	36.67	2026-10-01 00:00:00+03
4019	420	37.00	2026-10-01 00:00:00+03
4020	421	37.33	2026-10-01 00:00:00+03
4021	422	37.67	2026-10-01 00:00:00+03
4022	423	38.00	2026-10-01 00:00:00+03
4023	424	38.33	2026-10-01 00:00:00+03
4024	425	38.67	2026-10-01 00:00:00+03
4025	426	39.00	2026-10-01 00:00:00+03
4026	427	39.33	2026-10-01 00:00:00+03
4027	428	39.67	2026-10-01 00:00:00+03
4028	429	40.00	2026-10-01 00:00:00+03
4029	430	40.33	2026-10-01 00:00:00+03
4030	431	40.67	2026-10-01 00:00:00+03
4031	432	41.00	2026-10-01 00:00:00+03
4032	433	41.33	2026-10-01 00:00:00+03
4033	434	41.67	2026-10-01 00:00:00+03
4034	435	42.00	2026-10-01 00:00:00+03
4035	436	42.33	2026-10-01 00:00:00+03
4036	437	42.67	2026-10-01 00:00:00+03
4037	438	43.00	2026-10-01 00:00:00+03
4038	439	43.33	2026-10-01 00:00:00+03
4039	440	43.67	2026-10-01 00:00:00+03
4040	441	44.00	2026-10-01 00:00:00+03
4041	442	44.33	2026-10-01 00:00:00+03
4042	443	44.67	2026-10-01 00:00:00+03
4043	444	45.00	2026-10-01 00:00:00+03
4044	445	45.33	2026-10-01 00:00:00+03
4045	446	45.67	2026-10-01 00:00:00+03
4046	447	46.00	2026-10-01 00:00:00+03
4047	448	46.33	2026-10-01 00:00:00+03
4048	449	46.67	2026-10-01 00:00:00+03
4049	450	47.00	2026-10-01 00:00:00+03
4050	451	47.33	2026-10-01 00:00:00+03
4051	452	47.67	2026-10-01 00:00:00+03
4052	453	48.00	2026-10-01 00:00:00+03
4053	454	48.33	2026-10-01 00:00:00+03
4054	455	48.67	2026-10-01 00:00:00+03
4055	456	49.00	2026-10-01 00:00:00+03
4056	457	49.33	2026-10-01 00:00:00+03
4057	458	49.67	2026-10-01 00:00:00+03
4058	459	50.00	2026-10-01 00:00:00+03
4059	460	50.33	2026-10-01 00:00:00+03
4060	461	50.67	2026-10-01 00:00:00+03
4061	462	51.00	2026-10-01 00:00:00+03
4062	463	51.33	2026-10-01 00:00:00+03
4063	464	51.67	2026-10-01 00:00:00+03
4064	465	52.00	2026-10-01 00:00:00+03
4065	466	52.33	2026-10-01 00:00:00+03
4066	467	52.67	2026-10-01 00:00:00+03
4067	468	53.00	2026-10-01 00:00:00+03
4068	469	53.33	2026-10-01 00:00:00+03
4069	470	53.67	2026-10-01 00:00:00+03
4070	471	54.00	2026-10-01 00:00:00+03
4071	472	54.33	2026-10-01 00:00:00+03
4072	473	54.67	2026-10-01 00:00:00+03
4073	474	55.00	2026-10-01 00:00:00+03
4074	475	55.33	2026-10-01 00:00:00+03
4075	476	55.67	2026-10-01 00:00:00+03
4076	477	56.00	2026-10-01 00:00:00+03
4077	478	56.33	2026-10-01 00:00:00+03
4078	479	56.67	2026-10-01 00:00:00+03
4079	480	57.00	2026-10-01 00:00:00+03
4080	481	57.33	2026-10-01 00:00:00+03
4081	482	57.67	2026-10-01 00:00:00+03
4082	483	58.00	2026-10-01 00:00:00+03
4083	484	58.33	2026-10-01 00:00:00+03
4084	485	58.67	2026-10-01 00:00:00+03
4085	486	59.00	2026-10-01 00:00:00+03
4086	487	59.33	2026-10-01 00:00:00+03
4087	488	59.67	2026-10-01 00:00:00+03
4088	489	60.00	2026-10-01 00:00:00+03
4089	490	60.33	2026-10-01 00:00:00+03
4090	491	60.67	2026-10-01 00:00:00+03
4091	492	61.00	2026-10-01 00:00:00+03
4092	493	61.33	2026-10-01 00:00:00+03
4093	494	61.67	2026-10-01 00:00:00+03
4094	495	62.00	2026-10-01 00:00:00+03
4095	496	62.33	2026-10-01 00:00:00+03
4096	497	62.67	2026-10-01 00:00:00+03
4097	498	63.00	2026-10-01 00:00:00+03
4098	499	63.33	2026-10-01 00:00:00+03
4099	500	63.67	2026-10-01 00:00:00+03
4100	501	64.00	2026-10-01 00:00:00+03
4101	502	64.33	2026-10-01 00:00:00+03
4102	503	64.67	2026-10-01 00:00:00+03
4103	504	65.00	2026-10-01 00:00:00+03
4104	505	65.33	2026-10-01 00:00:00+03
4105	506	65.67	2026-10-01 00:00:00+03
4106	507	66.00	2026-10-01 00:00:00+03
4107	508	66.33	2026-10-01 00:00:00+03
4108	509	66.67	2026-10-01 00:00:00+03
4109	510	67.00	2026-10-01 00:00:00+03
4110	511	67.33	2026-10-01 00:00:00+03
4111	512	67.67	2026-10-01 00:00:00+03
4112	513	68.00	2026-10-01 00:00:00+03
4113	514	68.33	2026-10-01 00:00:00+03
4114	515	68.67	2026-10-01 00:00:00+03
4115	516	69.00	2026-10-01 00:00:00+03
4116	517	69.33	2026-10-01 00:00:00+03
4117	518	69.67	2026-10-01 00:00:00+03
4118	519	70.00	2026-10-01 00:00:00+03
4119	520	70.33	2026-10-01 00:00:00+03
4120	521	70.67	2026-10-01 00:00:00+03
4121	522	71.00	2026-10-01 00:00:00+03
4122	523	71.33	2026-10-01 00:00:00+03
4123	524	71.67	2026-10-01 00:00:00+03
4124	525	72.00	2026-10-01 00:00:00+03
4125	526	72.33	2026-10-01 00:00:00+03
4126	527	72.67	2026-10-01 00:00:00+03
4127	528	73.00	2026-10-01 00:00:00+03
4128	529	73.33	2026-10-01 00:00:00+03
4129	530	73.67	2026-10-01 00:00:00+03
4130	531	74.00	2026-10-01 00:00:00+03
4131	532	74.33	2026-10-01 00:00:00+03
4132	533	74.67	2026-10-01 00:00:00+03
4133	534	75.00	2026-10-01 00:00:00+03
4134	535	75.33	2026-10-01 00:00:00+03
4135	536	75.67	2026-10-01 00:00:00+03
4136	537	76.00	2026-10-01 00:00:00+03
4137	538	76.33	2026-10-01 00:00:00+03
4138	539	76.67	2026-10-01 00:00:00+03
4139	540	77.00	2026-10-01 00:00:00+03
4140	541	77.33	2026-10-01 00:00:00+03
4141	542	77.67	2026-10-01 00:00:00+03
4142	543	78.00	2026-10-01 00:00:00+03
4143	544	78.33	2026-10-01 00:00:00+03
4144	545	78.67	2026-10-01 00:00:00+03
4145	546	79.00	2026-10-01 00:00:00+03
4146	547	79.33	2026-10-01 00:00:00+03
4147	548	79.67	2026-10-01 00:00:00+03
4148	549	80.00	2026-10-01 00:00:00+03
4149	550	80.33	2026-10-01 00:00:00+03
4150	551	80.67	2026-10-01 00:00:00+03
4151	552	81.00	2026-10-01 00:00:00+03
4152	553	81.33	2026-10-01 00:00:00+03
4153	554	81.67	2026-10-01 00:00:00+03
4154	555	82.00	2026-10-01 00:00:00+03
4155	556	82.33	2026-10-01 00:00:00+03
4156	557	82.67	2026-10-01 00:00:00+03
4157	558	83.00	2026-10-01 00:00:00+03
4158	559	83.33	2026-10-01 00:00:00+03
4159	560	83.67	2026-10-01 00:00:00+03
4160	561	84.00	2026-10-01 00:00:00+03
4161	562	84.33	2026-10-01 00:00:00+03
4162	563	84.67	2026-10-01 00:00:00+03
4163	564	85.00	2026-10-01 00:00:00+03
4164	565	85.33	2026-10-01 00:00:00+03
4165	566	85.67	2026-10-01 00:00:00+03
4166	567	86.00	2026-10-01 00:00:00+03
4167	568	86.33	2026-10-01 00:00:00+03
4168	569	86.67	2026-10-01 00:00:00+03
4169	570	87.00	2026-10-01 00:00:00+03
4170	571	87.33	2026-10-01 00:00:00+03
4171	572	87.67	2026-10-01 00:00:00+03
4172	573	88.00	2026-10-01 00:00:00+03
4173	574	88.33	2026-10-01 00:00:00+03
4174	575	88.67	2026-10-01 00:00:00+03
4175	576	89.00	2026-10-01 00:00:00+03
4176	577	89.33	2026-10-01 00:00:00+03
4177	578	89.67	2026-10-01 00:00:00+03
4178	579	90.00	2026-10-01 00:00:00+03
4179	580	90.33	2026-10-01 00:00:00+03
4180	581	90.67	2026-10-01 00:00:00+03
4181	582	91.00	2026-10-01 00:00:00+03
4182	583	91.33	2026-10-01 00:00:00+03
4183	584	91.67	2026-10-01 00:00:00+03
4184	585	92.00	2026-10-01 00:00:00+03
4185	586	92.33	2026-10-01 00:00:00+03
4186	587	92.67	2026-10-01 00:00:00+03
4187	588	93.00	2026-10-01 00:00:00+03
4188	589	93.33	2026-10-01 00:00:00+03
4189	590	93.67	2026-10-01 00:00:00+03
4190	591	94.00	2026-10-01 00:00:00+03
4191	592	94.33	2026-10-01 00:00:00+03
4192	593	94.67	2026-10-01 00:00:00+03
4193	594	95.00	2026-10-01 00:00:00+03
4194	595	95.33	2026-10-01 00:00:00+03
4195	596	95.67	2026-10-01 00:00:00+03
4196	597	96.00	2026-10-01 00:00:00+03
4197	598	96.33	2026-10-01 00:00:00+03
4198	599	96.67	2026-10-01 00:00:00+03
4199	600	97.00	2026-10-01 00:00:00+03
4200	601	97.33	2026-10-01 00:00:00+03
4201	602	97.67	2026-10-01 00:00:00+03
4202	603	98.00	2026-10-01 00:00:00+03
4203	604	98.33	2026-10-01 00:00:00+03
4204	605	98.67	2026-10-01 00:00:00+03
4205	606	99.00	2026-10-01 00:00:00+03
4206	607	99.33	2026-10-01 00:00:00+03
4207	608	99.67	2026-10-01 00:00:00+03
4208	609	100.00	2026-10-01 00:00:00+03
4209	610	100.33	2026-10-01 00:00:00+03
4210	611	100.67	2026-10-01 00:00:00+03
4211	612	101.00	2026-10-01 00:00:00+03
4212	613	101.33	2026-10-01 00:00:00+03
4213	614	101.67	2026-10-01 00:00:00+03
4214	615	102.00	2026-10-01 00:00:00+03
4215	616	102.33	2026-10-01 00:00:00+03
4216	617	102.67	2026-10-01 00:00:00+03
4217	618	103.00	2026-10-01 00:00:00+03
4218	619	103.33	2026-10-01 00:00:00+03
4219	620	103.67	2026-10-01 00:00:00+03
4220	621	104.00	2026-10-01 00:00:00+03
4221	622	104.33	2026-10-01 00:00:00+03
4222	623	104.67	2026-10-01 00:00:00+03
4223	624	105.00	2026-10-01 00:00:00+03
4224	625	105.33	2026-10-01 00:00:00+03
4225	626	105.67	2026-10-01 00:00:00+03
4226	627	106.00	2026-10-01 00:00:00+03
4227	628	106.33	2026-10-01 00:00:00+03
4228	629	106.67	2026-10-01 00:00:00+03
4229	630	107.00	2026-10-01 00:00:00+03
4230	631	107.33	2026-10-01 00:00:00+03
4231	632	107.67	2026-10-01 00:00:00+03
4232	633	108.00	2026-10-01 00:00:00+03
4233	634	108.33	2026-10-01 00:00:00+03
4234	635	108.67	2026-10-01 00:00:00+03
4235	636	109.00	2026-10-01 00:00:00+03
4236	637	109.33	2026-10-01 00:00:00+03
4237	638	109.67	2026-10-01 00:00:00+03
4238	639	110.00	2026-10-01 00:00:00+03
4239	640	110.33	2026-10-01 00:00:00+03
4240	641	110.67	2026-10-01 00:00:00+03
4241	642	111.00	2026-10-01 00:00:00+03
4242	643	111.33	2026-10-01 00:00:00+03
4243	644	111.67	2026-10-01 00:00:00+03
4244	645	112.00	2026-10-01 00:00:00+03
4245	646	112.33	2026-10-01 00:00:00+03
4246	647	112.67	2026-10-01 00:00:00+03
4247	648	113.00	2026-10-01 00:00:00+03
4248	649	113.33	2026-10-01 00:00:00+03
4249	650	113.67	2026-10-01 00:00:00+03
4250	651	114.00	2026-10-01 00:00:00+03
4251	652	114.33	2026-10-01 00:00:00+03
4252	653	114.67	2026-10-01 00:00:00+03
4253	654	115.00	2026-10-01 00:00:00+03
4254	655	115.33	2026-10-01 00:00:00+03
4255	656	115.67	2026-10-01 00:00:00+03
4256	657	116.00	2026-10-01 00:00:00+03
4257	658	116.33	2026-10-01 00:00:00+03
4258	659	116.67	2026-10-01 00:00:00+03
4259	660	117.00	2026-10-01 00:00:00+03
4260	661	117.33	2026-10-01 00:00:00+03
4261	662	117.67	2026-10-01 00:00:00+03
4262	663	118.00	2026-10-01 00:00:00+03
4263	664	118.33	2026-10-01 00:00:00+03
4264	665	118.67	2026-10-01 00:00:00+03
4265	666	119.00	2026-10-01 00:00:00+03
4266	667	119.33	2026-10-01 00:00:00+03
4267	668	119.67	2026-10-01 00:00:00+03
4268	669	120.00	2026-10-01 00:00:00+03
4269	670	120.33	2026-10-01 00:00:00+03
4270	671	120.67	2026-10-01 00:00:00+03
4271	672	121.00	2026-10-01 00:00:00+03
4272	673	121.33	2026-10-01 00:00:00+03
4273	674	121.67	2026-10-01 00:00:00+03
4274	675	122.00	2026-10-01 00:00:00+03
4275	676	122.33	2026-10-01 00:00:00+03
4276	677	122.67	2026-10-01 00:00:00+03
4277	678	123.00	2026-10-01 00:00:00+03
4278	679	123.33	2026-10-01 00:00:00+03
4279	680	123.67	2026-10-01 00:00:00+03
4280	681	124.00	2026-10-01 00:00:00+03
4281	682	124.33	2026-10-01 00:00:00+03
4282	683	124.67	2026-10-01 00:00:00+03
4283	684	125.00	2026-10-01 00:00:00+03
4284	685	125.33	2026-10-01 00:00:00+03
4285	686	125.67	2026-10-01 00:00:00+03
4286	687	126.00	2026-10-01 00:00:00+03
4287	688	126.33	2026-10-01 00:00:00+03
4288	689	126.67	2026-10-01 00:00:00+03
4289	690	127.00	2026-10-01 00:00:00+03
4290	691	127.33	2026-10-01 00:00:00+03
4291	692	127.67	2026-10-01 00:00:00+03
4292	693	128.00	2026-10-01 00:00:00+03
4293	694	128.33	2026-10-01 00:00:00+03
4294	695	128.67	2026-10-01 00:00:00+03
4295	696	129.00	2026-10-01 00:00:00+03
4296	697	129.33	2026-10-01 00:00:00+03
4297	698	129.67	2026-10-01 00:00:00+03
4298	699	130.00	2026-10-01 00:00:00+03
4299	700	130.33	2026-10-01 00:00:00+03
4300	701	130.67	2026-10-01 00:00:00+03
4301	702	131.00	2026-10-01 00:00:00+03
4302	703	131.33	2026-10-01 00:00:00+03
4303	704	131.67	2026-10-01 00:00:00+03
4304	705	132.00	2026-10-01 00:00:00+03
4305	706	132.33	2026-10-01 00:00:00+03
4306	707	132.67	2026-10-01 00:00:00+03
4307	708	133.00	2026-10-01 00:00:00+03
4308	709	133.33	2026-10-01 00:00:00+03
4309	710	133.67	2026-10-01 00:00:00+03
4310	711	134.00	2026-10-01 00:00:00+03
4311	712	134.33	2026-10-01 00:00:00+03
4312	713	134.67	2026-10-01 00:00:00+03
4313	714	135.00	2026-10-01 00:00:00+03
4314	715	135.33	2026-10-01 00:00:00+03
4315	716	135.67	2026-10-01 00:00:00+03
4316	717	136.00	2026-10-01 00:00:00+03
4317	718	136.33	2026-10-01 00:00:00+03
4318	719	136.67	2026-10-01 00:00:00+03
4319	720	137.00	2026-10-01 00:00:00+03
4320	721	137.33	2026-10-01 00:00:00+03
4321	722	137.67	2026-10-01 00:00:00+03
4322	723	138.00	2026-10-01 00:00:00+03
4323	724	138.33	2026-10-01 00:00:00+03
4324	725	138.67	2026-10-01 00:00:00+03
4325	726	139.00	2026-10-01 00:00:00+03
4326	727	139.33	2026-10-01 00:00:00+03
4327	728	139.67	2026-10-01 00:00:00+03
4328	729	140.00	2026-10-01 00:00:00+03
4329	730	140.33	2026-10-01 00:00:00+03
4330	731	140.67	2026-10-01 00:00:00+03
4331	732	141.00	2026-10-01 00:00:00+03
4332	733	141.33	2026-10-01 00:00:00+03
4333	734	141.67	2026-10-01 00:00:00+03
4334	735	142.00	2026-10-01 00:00:00+03
4335	736	142.33	2026-10-01 00:00:00+03
4336	737	142.67	2026-10-01 00:00:00+03
4337	738	143.00	2026-10-01 00:00:00+03
4338	739	143.33	2026-10-01 00:00:00+03
4339	740	143.67	2026-10-01 00:00:00+03
4340	741	144.00	2026-10-01 00:00:00+03
4341	742	144.33	2026-10-01 00:00:00+03
4342	743	144.67	2026-10-01 00:00:00+03
4343	744	145.00	2026-10-01 00:00:00+03
4344	745	145.33	2026-10-01 00:00:00+03
4345	746	145.67	2026-10-01 00:00:00+03
4346	747	146.00	2026-10-01 00:00:00+03
4347	748	146.33	2026-10-01 00:00:00+03
4348	749	146.67	2026-10-01 00:00:00+03
4349	750	147.00	2026-10-01 00:00:00+03
4350	751	147.33	2026-10-01 00:00:00+03
4351	752	147.67	2026-10-01 00:00:00+03
4352	753	148.00	2026-10-01 00:00:00+03
4353	754	148.33	2026-10-01 00:00:00+03
4354	755	148.67	2026-10-01 00:00:00+03
4355	756	149.00	2026-10-01 00:00:00+03
4356	757	149.33	2026-10-01 00:00:00+03
4357	758	149.67	2026-10-01 00:00:00+03
4358	759	150.00	2026-10-01 00:00:00+03
4359	760	150.33	2026-10-01 00:00:00+03
4360	761	150.67	2026-10-01 00:00:00+03
4361	762	151.00	2026-10-01 00:00:00+03
4362	763	151.33	2026-10-01 00:00:00+03
4363	764	151.67	2026-10-01 00:00:00+03
4364	765	152.00	2026-10-01 00:00:00+03
4365	766	152.33	2026-10-01 00:00:00+03
4366	767	152.67	2026-10-01 00:00:00+03
4367	768	153.00	2026-10-01 00:00:00+03
4368	769	153.33	2026-10-01 00:00:00+03
4369	770	153.67	2026-10-01 00:00:00+03
4370	771	154.00	2026-10-01 00:00:00+03
4371	772	154.33	2026-10-01 00:00:00+03
4372	773	154.67	2026-10-01 00:00:00+03
4373	774	155.00	2026-10-01 00:00:00+03
4374	775	155.33	2026-10-01 00:00:00+03
4375	776	155.67	2026-10-01 00:00:00+03
4376	777	156.00	2026-10-01 00:00:00+03
4377	778	156.33	2026-10-01 00:00:00+03
4378	779	156.67	2026-10-01 00:00:00+03
4379	780	157.00	2026-10-01 00:00:00+03
4380	781	157.33	2026-10-01 00:00:00+03
4381	782	157.67	2026-10-01 00:00:00+03
4382	783	158.00	2026-10-01 00:00:00+03
4383	784	158.33	2026-10-01 00:00:00+03
4384	785	158.67	2026-10-01 00:00:00+03
4385	786	159.00	2026-10-01 00:00:00+03
4386	787	159.33	2026-10-01 00:00:00+03
4387	788	159.67	2026-10-01 00:00:00+03
4388	789	160.00	2026-10-01 00:00:00+03
4389	790	160.33	2026-10-01 00:00:00+03
4390	791	160.67	2026-10-01 00:00:00+03
4391	792	161.00	2026-10-01 00:00:00+03
4392	793	161.33	2026-10-01 00:00:00+03
4393	794	161.67	2026-10-01 00:00:00+03
4394	795	162.00	2026-10-01 00:00:00+03
4395	796	162.33	2026-10-01 00:00:00+03
4396	797	162.67	2026-10-01 00:00:00+03
4397	798	163.00	2026-10-01 00:00:00+03
4398	799	163.33	2026-10-01 00:00:00+03
4399	800	163.67	2026-10-01 00:00:00+03
4400	801	164.00	2026-10-01 00:00:00+03
4401	802	164.33	2026-10-01 00:00:00+03
4402	803	164.67	2026-10-01 00:00:00+03
4403	804	165.00	2026-10-01 00:00:00+03
4404	805	165.33	2026-10-01 00:00:00+03
4405	806	165.67	2026-10-01 00:00:00+03
4406	807	166.00	2026-10-01 00:00:00+03
4407	808	166.33	2026-10-01 00:00:00+03
4408	809	166.67	2026-10-01 00:00:00+03
4409	810	167.00	2026-10-01 00:00:00+03
4410	811	167.33	2026-10-01 00:00:00+03
4411	812	167.67	2026-10-01 00:00:00+03
4412	813	168.00	2026-10-01 00:00:00+03
4413	814	168.33	2026-10-01 00:00:00+03
4414	815	168.67	2026-10-01 00:00:00+03
4415	816	169.00	2026-10-01 00:00:00+03
4416	817	169.33	2026-10-01 00:00:00+03
4417	818	169.67	2026-10-01 00:00:00+03
4418	819	170.00	2026-10-01 00:00:00+03
4419	820	170.33	2026-10-01 00:00:00+03
4420	821	170.67	2026-10-01 00:00:00+03
4421	822	171.00	2026-10-01 00:00:00+03
4422	823	171.33	2026-10-01 00:00:00+03
4423	824	171.67	2026-10-01 00:00:00+03
4424	825	172.00	2026-10-01 00:00:00+03
4425	826	172.33	2026-10-01 00:00:00+03
4426	827	172.67	2026-10-01 00:00:00+03
4427	828	173.00	2026-10-01 00:00:00+03
4428	829	173.33	2026-10-01 00:00:00+03
4429	830	173.67	2026-10-01 00:00:00+03
4430	831	174.00	2026-10-01 00:00:00+03
4431	832	174.33	2026-10-01 00:00:00+03
4432	833	174.67	2026-10-01 00:00:00+03
4433	834	175.00	2026-10-01 00:00:00+03
4434	835	175.33	2026-10-01 00:00:00+03
4435	836	175.67	2026-10-01 00:00:00+03
4436	837	176.00	2026-10-01 00:00:00+03
4437	838	176.33	2026-10-01 00:00:00+03
4438	839	176.67	2026-10-01 00:00:00+03
4439	840	177.00	2026-10-01 00:00:00+03
4440	841	177.33	2026-10-01 00:00:00+03
4441	842	177.67	2026-10-01 00:00:00+03
4442	843	178.00	2026-10-01 00:00:00+03
4443	844	178.33	2026-10-01 00:00:00+03
4444	845	178.67	2026-10-01 00:00:00+03
4445	846	179.00	2026-10-01 00:00:00+03
4446	847	179.33	2026-10-01 00:00:00+03
4447	848	179.67	2026-10-01 00:00:00+03
4448	849	180.00	2026-10-01 00:00:00+03
4449	850	180.33	2026-10-01 00:00:00+03
4450	851	180.67	2026-10-01 00:00:00+03
4451	852	181.00	2026-10-01 00:00:00+03
4452	853	181.33	2026-10-01 00:00:00+03
4453	854	181.67	2026-10-01 00:00:00+03
4454	855	182.00	2026-10-01 00:00:00+03
4455	856	182.33	2026-10-01 00:00:00+03
4456	857	182.67	2026-10-01 00:00:00+03
4457	858	183.00	2026-10-01 00:00:00+03
4458	859	183.33	2026-10-01 00:00:00+03
4459	860	183.67	2026-10-01 00:00:00+03
4460	861	184.00	2026-10-01 00:00:00+03
4461	862	184.33	2026-10-01 00:00:00+03
4462	863	184.67	2026-10-01 00:00:00+03
4463	864	185.00	2026-10-01 00:00:00+03
4464	865	185.33	2026-10-01 00:00:00+03
4465	866	185.67	2026-10-01 00:00:00+03
4466	867	186.00	2026-10-01 00:00:00+03
4467	868	186.33	2026-10-01 00:00:00+03
4468	869	186.67	2026-10-01 00:00:00+03
4469	870	187.00	2026-10-01 00:00:00+03
4470	871	187.33	2026-10-01 00:00:00+03
4471	872	187.67	2026-10-01 00:00:00+03
4472	873	188.00	2026-10-01 00:00:00+03
4473	874	188.33	2026-10-01 00:00:00+03
4474	875	188.67	2026-10-01 00:00:00+03
4475	876	189.00	2026-10-01 00:00:00+03
4476	877	189.33	2026-10-01 00:00:00+03
4477	878	189.67	2026-10-01 00:00:00+03
4478	879	190.00	2026-10-01 00:00:00+03
4479	880	190.33	2026-10-01 00:00:00+03
4480	881	190.67	2026-10-01 00:00:00+03
4481	882	191.00	2026-10-01 00:00:00+03
4482	883	191.33	2026-10-01 00:00:00+03
4483	884	191.67	2026-10-01 00:00:00+03
4484	885	192.00	2026-10-01 00:00:00+03
4485	886	192.33	2026-10-01 00:00:00+03
4486	887	192.67	2026-10-01 00:00:00+03
4487	888	193.00	2026-10-01 00:00:00+03
4488	889	193.33	2026-10-01 00:00:00+03
4489	890	193.67	2026-10-01 00:00:00+03
4490	891	194.00	2026-10-01 00:00:00+03
4491	892	194.33	2026-10-01 00:00:00+03
4492	893	194.67	2026-10-01 00:00:00+03
4493	894	195.00	2026-10-01 00:00:00+03
4494	895	195.33	2026-10-01 00:00:00+03
4495	896	195.67	2026-10-01 00:00:00+03
4496	897	196.00	2026-10-01 00:00:00+03
4497	898	196.33	2026-10-01 00:00:00+03
4498	899	196.67	2026-10-01 00:00:00+03
4499	900	197.00	2026-10-01 00:00:00+03
4500	901	197.33	2026-10-01 00:00:00+03
4501	902	197.67	2026-10-01 00:00:00+03
4502	903	198.00	2026-10-01 00:00:00+03
4503	904	198.33	2026-10-01 00:00:00+03
4504	905	198.67	2026-10-01 00:00:00+03
4505	906	199.00	2026-10-01 00:00:00+03
4506	907	199.33	2026-10-01 00:00:00+03
4507	908	199.67	2026-10-01 00:00:00+03
4508	909	200.00	2026-10-01 00:00:00+03
4509	910	200.33	2026-10-01 00:00:00+03
4510	911	200.67	2026-10-01 00:00:00+03
4511	912	201.00	2026-10-01 00:00:00+03
4512	913	201.33	2026-10-01 00:00:00+03
4513	914	201.67	2026-10-01 00:00:00+03
4514	915	202.00	2026-10-01 00:00:00+03
4515	916	202.33	2026-10-01 00:00:00+03
4516	917	202.67	2026-10-01 00:00:00+03
4517	918	203.00	2026-10-01 00:00:00+03
4518	919	203.33	2026-10-01 00:00:00+03
4519	920	203.67	2026-10-01 00:00:00+03
4520	921	204.00	2026-10-01 00:00:00+03
4521	922	204.33	2026-10-01 00:00:00+03
4522	923	204.67	2026-10-01 00:00:00+03
4523	924	205.00	2026-10-01 00:00:00+03
4524	925	205.33	2026-10-01 00:00:00+03
4525	926	205.67	2026-10-01 00:00:00+03
4526	927	206.00	2026-10-01 00:00:00+03
4527	928	206.33	2026-10-01 00:00:00+03
4528	929	206.67	2026-10-01 00:00:00+03
4529	930	207.00	2026-10-01 00:00:00+03
4530	931	207.33	2026-10-01 00:00:00+03
4531	932	207.67	2026-10-01 00:00:00+03
4532	933	208.00	2026-10-01 00:00:00+03
4533	934	208.33	2026-10-01 00:00:00+03
4534	935	208.67	2026-10-01 00:00:00+03
4535	936	209.00	2026-10-01 00:00:00+03
4536	937	209.33	2026-10-01 00:00:00+03
4537	938	209.67	2026-10-01 00:00:00+03
4538	939	210.00	2026-10-01 00:00:00+03
4539	940	210.33	2026-10-01 00:00:00+03
4540	941	210.67	2026-10-01 00:00:00+03
4541	942	211.00	2026-10-01 00:00:00+03
4542	943	211.33	2026-10-01 00:00:00+03
4543	944	211.67	2026-10-01 00:00:00+03
4544	945	212.00	2026-10-01 00:00:00+03
4545	946	212.33	2026-10-01 00:00:00+03
4546	947	212.67	2026-10-01 00:00:00+03
4547	948	213.00	2026-10-01 00:00:00+03
4548	949	213.33	2026-10-01 00:00:00+03
4549	950	213.67	2026-10-01 00:00:00+03
4550	951	214.00	2026-10-01 00:00:00+03
4551	952	214.33	2026-10-01 00:00:00+03
4552	953	214.67	2026-10-01 00:00:00+03
4553	954	215.00	2026-10-01 00:00:00+03
4554	955	215.33	2026-10-01 00:00:00+03
4555	956	215.67	2026-10-01 00:00:00+03
4556	957	216.00	2026-10-01 00:00:00+03
4557	958	216.33	2026-10-01 00:00:00+03
4558	959	216.67	2026-10-01 00:00:00+03
4559	960	217.00	2026-10-01 00:00:00+03
4560	961	217.33	2026-10-01 00:00:00+03
4561	962	217.67	2026-10-01 00:00:00+03
4562	963	218.00	2026-10-01 00:00:00+03
4563	964	218.33	2026-10-01 00:00:00+03
4564	965	218.67	2026-10-01 00:00:00+03
4565	966	219.00	2026-10-01 00:00:00+03
4566	967	219.33	2026-10-01 00:00:00+03
4567	968	219.67	2026-10-01 00:00:00+03
4568	969	220.00	2026-10-01 00:00:00+03
4569	970	220.33	2026-10-01 00:00:00+03
4570	971	220.67	2026-10-01 00:00:00+03
4571	972	221.00	2026-10-01 00:00:00+03
4572	973	221.33	2026-10-01 00:00:00+03
4573	974	221.67	2026-10-01 00:00:00+03
4574	975	222.00	2026-10-01 00:00:00+03
4575	976	222.33	2026-10-01 00:00:00+03
4576	977	222.67	2026-10-01 00:00:00+03
4577	978	223.00	2026-10-01 00:00:00+03
4578	979	223.33	2026-10-01 00:00:00+03
4579	980	223.67	2026-10-01 00:00:00+03
4580	981	224.00	2026-10-01 00:00:00+03
4581	982	224.33	2026-10-01 00:00:00+03
4582	983	224.67	2026-10-01 00:00:00+03
4583	984	225.00	2026-10-01 00:00:00+03
4584	985	225.33	2026-10-01 00:00:00+03
4585	986	225.67	2026-10-01 00:00:00+03
4586	987	226.00	2026-10-01 00:00:00+03
4587	988	226.33	2026-10-01 00:00:00+03
4588	989	226.67	2026-10-01 00:00:00+03
4589	990	227.00	2026-10-01 00:00:00+03
4590	991	227.33	2026-10-01 00:00:00+03
4591	992	227.67	2026-10-01 00:00:00+03
4592	993	228.00	2026-10-01 00:00:00+03
4593	994	228.33	2026-10-01 00:00:00+03
4594	995	228.67	2026-10-01 00:00:00+03
4595	996	229.00	2026-10-01 00:00:00+03
4596	997	229.33	2026-10-01 00:00:00+03
4597	998	229.67	2026-10-01 00:00:00+03
4598	999	230.00	2026-10-01 00:00:00+03
4599	1000	230.33	2026-10-01 00:00:00+03
4600	1001	230.67	2026-10-01 00:00:00+03
4601	1002	231.00	2026-10-01 00:00:00+03
4602	1003	231.33	2026-10-01 00:00:00+03
4603	1004	231.67	2026-10-01 00:00:00+03
4604	1005	232.00	2026-10-01 00:00:00+03
4605	1006	232.33	2026-10-01 00:00:00+03
4606	1007	232.67	2026-10-01 00:00:00+03
4607	1008	233.00	2026-10-01 00:00:00+03
4608	1009	233.33	2026-10-01 00:00:00+03
4609	1010	233.67	2026-10-01 00:00:00+03
4610	1011	234.00	2026-10-01 00:00:00+03
4611	1012	234.33	2026-10-01 00:00:00+03
4612	1013	234.67	2026-10-01 00:00:00+03
4613	1014	235.00	2026-10-01 00:00:00+03
4614	1015	235.33	2026-10-01 00:00:00+03
4615	1016	235.67	2026-10-01 00:00:00+03
4616	1017	236.00	2026-10-01 00:00:00+03
4617	1018	236.33	2026-10-01 00:00:00+03
4618	1019	236.67	2026-10-01 00:00:00+03
4619	1020	237.00	2026-10-01 00:00:00+03
4620	1021	237.33	2026-10-01 00:00:00+03
4621	1022	237.67	2026-10-01 00:00:00+03
4622	1023	238.00	2026-10-01 00:00:00+03
4623	1024	238.33	2026-10-01 00:00:00+03
4624	1025	238.67	2026-10-01 00:00:00+03
4625	1026	239.00	2026-10-01 00:00:00+03
4626	1027	239.33	2026-10-01 00:00:00+03
4627	1028	239.67	2026-10-01 00:00:00+03
4628	1029	240.00	2026-10-01 00:00:00+03
4629	1030	240.33	2026-10-01 00:00:00+03
4630	1031	240.67	2026-10-01 00:00:00+03
4631	1032	241.00	2026-10-01 00:00:00+03
4632	1033	241.33	2026-10-01 00:00:00+03
4633	1034	241.67	2026-10-01 00:00:00+03
4634	1035	242.00	2026-10-01 00:00:00+03
4635	1036	242.33	2026-10-01 00:00:00+03
4636	1037	242.67	2026-10-01 00:00:00+03
4637	1038	243.00	2026-10-01 00:00:00+03
4638	1039	243.33	2026-10-01 00:00:00+03
4639	1040	243.67	2026-10-01 00:00:00+03
4640	1041	244.00	2026-10-01 00:00:00+03
4641	1042	244.33	2026-10-01 00:00:00+03
4642	1043	244.67	2026-10-01 00:00:00+03
4643	1044	245.00	2026-10-01 00:00:00+03
4644	1045	245.33	2026-10-01 00:00:00+03
4645	1046	245.67	2026-10-01 00:00:00+03
4646	1047	246.00	2026-10-01 00:00:00+03
4647	1048	246.33	2026-10-01 00:00:00+03
4648	1049	246.67	2026-10-01 00:00:00+03
4649	1050	247.00	2026-10-01 00:00:00+03
4650	1051	247.33	2026-10-01 00:00:00+03
4651	1052	247.67	2026-10-01 00:00:00+03
4652	1053	248.00	2026-10-01 00:00:00+03
4653	1054	248.33	2026-10-01 00:00:00+03
4654	1055	248.67	2026-10-01 00:00:00+03
4655	1056	249.00	2026-10-01 00:00:00+03
4656	1057	249.33	2026-10-01 00:00:00+03
4657	1058	249.67	2026-10-01 00:00:00+03
4658	1059	250.00	2026-10-01 00:00:00+03
4659	1060	250.33	2026-10-01 00:00:00+03
4660	1061	250.67	2026-10-01 00:00:00+03
4661	1062	251.00	2026-10-01 00:00:00+03
4662	1063	251.33	2026-10-01 00:00:00+03
4663	1064	251.67	2026-10-01 00:00:00+03
4664	1065	252.00	2026-10-01 00:00:00+03
4665	1066	252.33	2026-10-01 00:00:00+03
4666	1067	252.67	2026-10-01 00:00:00+03
4667	1068	253.00	2026-10-01 00:00:00+03
4668	1069	253.33	2026-10-01 00:00:00+03
4669	1070	253.67	2026-10-01 00:00:00+03
4670	1071	254.00	2026-10-01 00:00:00+03
4671	1072	254.33	2026-10-01 00:00:00+03
4672	1073	254.67	2026-10-01 00:00:00+03
4673	1074	255.00	2026-10-01 00:00:00+03
4674	1075	255.33	2026-10-01 00:00:00+03
4675	1076	255.67	2026-10-01 00:00:00+03
4676	1077	256.00	2026-10-01 00:00:00+03
4677	1078	256.33	2026-10-01 00:00:00+03
4678	1079	256.67	2026-10-01 00:00:00+03
4679	1080	257.00	2026-10-01 00:00:00+03
4680	1081	257.33	2026-10-01 00:00:00+03
4681	1082	257.67	2026-10-01 00:00:00+03
4682	1083	258.00	2026-10-01 00:00:00+03
4683	1084	258.33	2026-10-01 00:00:00+03
4684	1085	258.67	2026-10-01 00:00:00+03
4685	1086	259.00	2026-10-01 00:00:00+03
4686	1087	259.33	2026-10-01 00:00:00+03
4687	1088	259.67	2026-10-01 00:00:00+03
4688	1089	260.00	2026-10-01 00:00:00+03
4689	1090	260.33	2026-10-01 00:00:00+03
4690	1091	260.67	2026-10-01 00:00:00+03
4691	1092	261.00	2026-10-01 00:00:00+03
4692	1093	261.33	2026-10-01 00:00:00+03
4693	1094	261.67	2026-10-01 00:00:00+03
4694	1095	262.00	2026-10-01 00:00:00+03
4695	1096	262.33	2026-10-01 00:00:00+03
4696	1097	262.67	2026-10-01 00:00:00+03
4697	1098	263.00	2026-10-01 00:00:00+03
4698	1099	263.33	2026-10-01 00:00:00+03
4699	1100	263.67	2026-10-01 00:00:00+03
4700	1101	264.00	2026-10-01 00:00:00+03
4701	1102	264.33	2026-10-01 00:00:00+03
4702	1103	264.67	2026-10-01 00:00:00+03
4703	1104	265.00	2026-10-01 00:00:00+03
4704	1105	265.33	2026-10-01 00:00:00+03
4705	1106	265.67	2026-10-01 00:00:00+03
4706	1107	266.00	2026-10-01 00:00:00+03
4707	1108	266.33	2026-10-01 00:00:00+03
4708	1109	266.67	2026-10-01 00:00:00+03
4709	1110	267.00	2026-10-01 00:00:00+03
4710	1111	267.33	2026-10-01 00:00:00+03
4711	1112	267.67	2026-10-01 00:00:00+03
4712	1113	268.00	2026-10-01 00:00:00+03
4713	1114	268.33	2026-10-01 00:00:00+03
4714	1115	268.67	2026-10-01 00:00:00+03
4715	1116	269.00	2026-10-01 00:00:00+03
4716	1117	269.33	2026-10-01 00:00:00+03
4717	1118	269.67	2026-10-01 00:00:00+03
4718	1119	270.00	2026-10-01 00:00:00+03
4719	1120	270.33	2026-10-01 00:00:00+03
4720	1121	270.67	2026-10-01 00:00:00+03
4721	1122	271.00	2026-10-01 00:00:00+03
4722	1123	271.33	2026-10-01 00:00:00+03
4723	1124	271.67	2026-10-01 00:00:00+03
4724	1125	272.00	2026-10-01 00:00:00+03
4725	1126	272.33	2026-10-01 00:00:00+03
4726	1127	272.67	2026-10-01 00:00:00+03
4727	1128	273.00	2026-10-01 00:00:00+03
4728	1129	273.33	2026-10-01 00:00:00+03
4729	1130	273.67	2026-10-01 00:00:00+03
4730	1131	274.00	2026-10-01 00:00:00+03
4731	1132	274.33	2026-10-01 00:00:00+03
4732	1133	274.67	2026-10-01 00:00:00+03
4733	1134	275.00	2026-10-01 00:00:00+03
4734	1135	275.33	2026-10-01 00:00:00+03
4735	1136	275.67	2026-10-01 00:00:00+03
4736	1137	276.00	2026-10-01 00:00:00+03
4737	1138	276.33	2026-10-01 00:00:00+03
4738	1139	276.67	2026-10-01 00:00:00+03
4739	1140	277.00	2026-10-01 00:00:00+03
4740	1141	277.33	2026-10-01 00:00:00+03
4741	1142	277.67	2026-10-01 00:00:00+03
4742	1143	278.00	2026-10-01 00:00:00+03
4743	1144	278.33	2026-10-01 00:00:00+03
4744	1145	278.67	2026-10-01 00:00:00+03
4745	1146	279.00	2026-10-01 00:00:00+03
4746	1147	279.33	2026-10-01 00:00:00+03
4747	1148	279.67	2026-10-01 00:00:00+03
4748	1149	280.00	2026-10-01 00:00:00+03
4749	1150	280.33	2026-10-01 00:00:00+03
4750	1151	280.67	2026-10-01 00:00:00+03
4751	1152	281.00	2026-10-01 00:00:00+03
4752	1153	281.33	2026-10-01 00:00:00+03
4753	1154	281.67	2026-10-01 00:00:00+03
4754	1155	282.00	2026-10-01 00:00:00+03
4755	1156	282.33	2026-10-01 00:00:00+03
4756	1157	282.67	2026-10-01 00:00:00+03
4757	1158	283.00	2026-10-01 00:00:00+03
4758	1159	283.33	2026-10-01 00:00:00+03
4759	1160	283.67	2026-10-01 00:00:00+03
4760	1161	284.00	2026-10-01 00:00:00+03
4761	1162	284.33	2026-10-01 00:00:00+03
4762	1163	284.67	2026-10-01 00:00:00+03
4763	1164	285.00	2026-10-01 00:00:00+03
4764	1165	285.33	2026-10-01 00:00:00+03
4765	1166	285.67	2026-10-01 00:00:00+03
4766	1167	286.00	2026-10-01 00:00:00+03
4767	1168	286.33	2026-10-01 00:00:00+03
4768	1169	286.67	2026-10-01 00:00:00+03
4769	1170	287.00	2026-10-01 00:00:00+03
4770	1171	287.33	2026-10-01 00:00:00+03
4771	1172	287.67	2026-10-01 00:00:00+03
4772	1173	288.00	2026-10-01 00:00:00+03
4773	1174	288.33	2026-10-01 00:00:00+03
4774	1175	288.67	2026-10-01 00:00:00+03
4775	1176	289.00	2026-10-01 00:00:00+03
4776	1177	289.33	2026-10-01 00:00:00+03
4777	1178	289.67	2026-10-01 00:00:00+03
4778	1179	290.00	2026-10-01 00:00:00+03
4779	1180	290.33	2026-10-01 00:00:00+03
4780	1181	290.67	2026-10-01 00:00:00+03
4781	1182	291.00	2026-10-01 00:00:00+03
4782	1183	291.33	2026-10-01 00:00:00+03
4783	1184	291.67	2026-10-01 00:00:00+03
4784	1185	292.00	2026-10-01 00:00:00+03
4785	1186	292.33	2026-10-01 00:00:00+03
4786	1187	292.67	2026-10-01 00:00:00+03
4787	1188	293.00	2026-10-01 00:00:00+03
4788	1189	293.33	2026-10-01 00:00:00+03
4789	1190	293.67	2026-10-01 00:00:00+03
4790	1191	294.00	2026-10-01 00:00:00+03
4791	1192	294.33	2026-10-01 00:00:00+03
4792	1193	294.67	2026-10-01 00:00:00+03
4793	1194	295.00	2026-10-01 00:00:00+03
4794	1195	295.33	2026-10-01 00:00:00+03
4795	1196	295.67	2026-10-01 00:00:00+03
4796	1197	296.00	2026-10-01 00:00:00+03
4797	1198	296.33	2026-10-01 00:00:00+03
4798	1199	296.67	2026-10-01 00:00:00+03
4799	1200	297.00	2026-10-01 00:00:00+03
4800	1	297.33	2026-10-01 00:00:00+03
4801	2	297.67	2026-10-01 00:00:00+03
4802	3	298.00	2026-10-01 00:00:00+03
4803	4	298.33	2026-10-01 00:00:00+03
4804	5	298.67	2026-10-01 00:00:00+03
4805	6	299.00	2026-10-01 00:00:00+03
4806	7	299.33	2026-10-01 00:00:00+03
4807	8	299.67	2026-10-01 00:00:00+03
4808	9	300.00	2026-10-01 00:00:00+03
4809	10	300.33	2026-10-01 00:00:00+03
4810	11	300.67	2026-10-01 00:00:00+03
4811	12	301.00	2026-10-01 00:00:00+03
4812	13	301.33	2026-10-01 00:00:00+03
4813	14	301.67	2026-10-01 00:00:00+03
4814	15	302.00	2026-10-01 00:00:00+03
4815	16	302.33	2026-10-01 00:00:00+03
4816	17	302.67	2026-10-01 00:00:00+03
4817	18	303.00	2026-10-01 00:00:00+03
4818	19	303.33	2026-10-01 00:00:00+03
4819	20	303.67	2026-10-01 00:00:00+03
4820	21	304.00	2026-10-01 00:00:00+03
4821	22	304.33	2026-10-01 00:00:00+03
4822	23	304.67	2026-10-01 00:00:00+03
4823	24	305.00	2026-10-01 00:00:00+03
4824	25	305.33	2026-10-01 00:00:00+03
4825	26	305.67	2026-10-01 00:00:00+03
4826	27	306.00	2026-10-01 00:00:00+03
4827	28	306.33	2026-10-01 00:00:00+03
4828	29	306.67	2026-10-01 00:00:00+03
4829	30	307.00	2026-10-01 00:00:00+03
4830	31	307.33	2026-10-01 00:00:00+03
4831	32	307.67	2026-10-01 00:00:00+03
4832	33	308.00	2026-10-01 00:00:00+03
4833	34	308.33	2026-10-01 00:00:00+03
4834	35	308.67	2026-10-01 00:00:00+03
4835	36	309.00	2026-10-01 00:00:00+03
4836	37	309.33	2026-10-01 00:00:00+03
4837	38	309.67	2026-10-01 00:00:00+03
4838	39	310.00	2026-10-01 00:00:00+03
4839	40	310.33	2026-10-01 00:00:00+03
4840	41	310.67	2026-10-01 00:00:00+03
4841	42	311.00	2026-10-01 00:00:00+03
4842	43	311.33	2026-10-01 00:00:00+03
4843	44	311.67	2026-10-01 00:00:00+03
4844	45	312.00	2026-10-01 00:00:00+03
4845	46	312.33	2026-10-01 00:00:00+03
4846	47	312.67	2026-10-01 00:00:00+03
4847	48	313.00	2026-10-01 00:00:00+03
4848	49	313.33	2026-10-01 00:00:00+03
4849	50	313.67	2026-10-01 00:00:00+03
4850	51	314.00	2026-10-01 00:00:00+03
4851	52	314.33	2026-10-01 00:00:00+03
4852	53	314.67	2026-10-01 00:00:00+03
4853	54	315.00	2026-10-01 00:00:00+03
4854	55	315.33	2026-10-01 00:00:00+03
4855	56	315.67	2026-10-01 00:00:00+03
4856	57	316.00	2026-10-01 00:00:00+03
4857	58	316.33	2026-10-01 00:00:00+03
4858	59	316.67	2026-10-01 00:00:00+03
4859	60	317.00	2026-10-01 00:00:00+03
4860	61	317.33	2026-10-01 00:00:00+03
4861	62	317.67	2026-10-01 00:00:00+03
4862	63	318.00	2026-10-01 00:00:00+03
4863	64	318.33	2026-10-01 00:00:00+03
4864	65	318.67	2026-10-01 00:00:00+03
4865	66	319.00	2026-10-01 00:00:00+03
4866	67	319.33	2026-10-01 00:00:00+03
4867	68	319.67	2026-10-01 00:00:00+03
4868	69	320.00	2026-10-01 00:00:00+03
4869	70	320.33	2026-10-01 00:00:00+03
4870	71	320.67	2026-10-01 00:00:00+03
4871	72	321.00	2026-10-01 00:00:00+03
4872	73	321.33	2026-10-01 00:00:00+03
4873	74	321.67	2026-10-01 00:00:00+03
4874	75	322.00	2026-10-01 00:00:00+03
4875	76	322.33	2026-10-01 00:00:00+03
4876	77	322.67	2026-10-01 00:00:00+03
4877	78	323.00	2026-10-01 00:00:00+03
4878	79	323.33	2026-10-01 00:00:00+03
4879	80	323.67	2026-10-01 00:00:00+03
4880	81	324.00	2026-10-01 00:00:00+03
4881	82	324.33	2026-10-01 00:00:00+03
4882	83	324.67	2026-10-01 00:00:00+03
4883	84	325.00	2026-10-01 00:00:00+03
4884	85	325.33	2026-10-01 00:00:00+03
4885	86	0.00	2026-10-01 00:00:00+03
4886	87	0.33	2026-10-01 00:00:00+03
4887	88	0.67	2026-10-01 00:00:00+03
4888	89	1.00	2026-10-01 00:00:00+03
4889	90	1.33	2026-10-01 00:00:00+03
4890	91	1.67	2026-10-01 00:00:00+03
4891	92	2.00	2026-10-01 00:00:00+03
4892	93	2.33	2026-10-01 00:00:00+03
4893	94	2.67	2026-10-01 00:00:00+03
4894	95	3.00	2026-10-01 00:00:00+03
4895	96	3.33	2026-10-01 00:00:00+03
4896	97	3.67	2026-10-01 00:00:00+03
4897	98	4.00	2026-10-01 00:00:00+03
4898	99	4.33	2026-10-01 00:00:00+03
4899	100	4.67	2026-10-01 00:00:00+03
4900	101	5.00	2026-10-01 00:00:00+03
4901	102	5.33	2026-10-01 00:00:00+03
4902	103	5.67	2026-10-01 00:00:00+03
4903	104	6.00	2026-10-01 00:00:00+03
4904	105	6.33	2026-10-01 00:00:00+03
4905	106	6.67	2026-10-01 00:00:00+03
4906	107	7.00	2026-10-01 00:00:00+03
4907	108	7.33	2026-10-01 00:00:00+03
4908	109	7.67	2026-10-01 00:00:00+03
4909	110	8.00	2026-10-01 00:00:00+03
4910	111	8.33	2026-10-01 00:00:00+03
4911	112	8.67	2026-10-01 00:00:00+03
4912	113	9.00	2026-10-01 00:00:00+03
4913	114	9.33	2026-10-01 00:00:00+03
4914	115	9.67	2026-10-01 00:00:00+03
4915	116	10.00	2026-10-01 00:00:00+03
4916	117	10.33	2026-10-01 00:00:00+03
4917	118	10.67	2026-10-01 00:00:00+03
4918	119	11.00	2026-10-01 00:00:00+03
4919	120	11.33	2026-10-01 00:00:00+03
4920	121	11.67	2026-10-01 00:00:00+03
4921	122	12.00	2026-10-01 00:00:00+03
4922	123	12.33	2026-10-01 00:00:00+03
4923	124	12.67	2026-10-01 00:00:00+03
4924	125	13.00	2026-10-01 00:00:00+03
4925	126	13.33	2026-10-01 00:00:00+03
4926	127	13.67	2026-10-01 00:00:00+03
4927	128	14.00	2026-10-01 00:00:00+03
4928	129	14.33	2026-10-01 00:00:00+03
4929	130	14.67	2026-10-01 00:00:00+03
4930	131	15.00	2026-10-01 00:00:00+03
4931	132	15.33	2026-10-01 00:00:00+03
4932	133	15.67	2026-10-01 00:00:00+03
4933	134	16.00	2026-10-01 00:00:00+03
4934	135	16.33	2026-10-01 00:00:00+03
4935	136	16.67	2026-10-01 00:00:00+03
4936	137	17.00	2026-10-01 00:00:00+03
4937	138	17.33	2026-10-01 00:00:00+03
4938	139	17.67	2026-10-01 00:00:00+03
4939	140	18.00	2026-10-01 00:00:00+03
4940	141	18.33	2026-10-01 00:00:00+03
4941	142	18.67	2026-10-01 00:00:00+03
4942	143	19.00	2026-10-01 00:00:00+03
4943	144	19.33	2026-10-01 00:00:00+03
4944	145	19.67	2026-10-01 00:00:00+03
4945	146	20.00	2026-10-01 00:00:00+03
4946	147	20.33	2026-10-01 00:00:00+03
4947	148	20.67	2026-10-01 00:00:00+03
4948	149	21.00	2026-10-01 00:00:00+03
4949	150	21.33	2026-10-01 00:00:00+03
4950	151	21.67	2026-10-01 00:00:00+03
4951	152	22.00	2026-10-01 00:00:00+03
4952	153	22.33	2026-10-01 00:00:00+03
4953	154	22.67	2026-10-01 00:00:00+03
4954	155	23.00	2026-10-01 00:00:00+03
4955	156	23.33	2026-10-01 00:00:00+03
4956	157	23.67	2026-10-01 00:00:00+03
4957	158	24.00	2026-10-01 00:00:00+03
4958	159	24.33	2026-10-01 00:00:00+03
4959	160	24.67	2026-10-01 00:00:00+03
4960	161	25.00	2026-10-01 00:00:00+03
4961	162	25.33	2026-10-01 00:00:00+03
4962	163	25.67	2026-10-01 00:00:00+03
4963	164	26.00	2026-10-01 00:00:00+03
4964	165	26.33	2026-10-01 00:00:00+03
4965	166	26.67	2026-10-01 00:00:00+03
4966	167	27.00	2026-10-01 00:00:00+03
4967	168	27.33	2026-10-01 00:00:00+03
4968	169	27.67	2026-10-01 00:00:00+03
4969	170	28.00	2026-10-01 00:00:00+03
4970	171	28.33	2026-10-01 00:00:00+03
4971	172	28.67	2026-10-01 00:00:00+03
4972	173	29.00	2026-10-01 00:00:00+03
4973	174	29.33	2026-10-01 00:00:00+03
4974	175	29.67	2026-10-01 00:00:00+03
4975	176	30.00	2026-10-01 00:00:00+03
4976	177	30.33	2026-10-01 00:00:00+03
4977	178	30.67	2026-10-01 00:00:00+03
4978	179	31.00	2026-10-01 00:00:00+03
4979	180	31.33	2026-10-01 00:00:00+03
4980	181	31.67	2026-10-01 00:00:00+03
4981	182	32.00	2026-10-01 00:00:00+03
4982	183	32.33	2026-10-01 00:00:00+03
4983	184	32.67	2026-10-01 00:00:00+03
4984	185	33.00	2026-10-01 00:00:00+03
4985	186	33.33	2026-10-01 00:00:00+03
4986	187	33.67	2026-10-01 00:00:00+03
4987	188	34.00	2026-10-01 00:00:00+03
4988	189	34.33	2026-10-01 00:00:00+03
4989	190	34.67	2026-10-01 00:00:00+03
4990	191	35.00	2026-10-01 00:00:00+03
4991	192	35.33	2026-10-01 00:00:00+03
4992	193	35.67	2026-10-01 00:00:00+03
4993	194	36.00	2026-10-01 00:00:00+03
4994	195	36.33	2026-10-01 00:00:00+03
4995	196	36.67	2026-10-01 00:00:00+03
4996	197	37.00	2026-10-01 00:00:00+03
4997	198	37.33	2026-10-01 00:00:00+03
4998	199	37.67	2026-10-01 00:00:00+03
4999	200	38.00	2026-10-01 00:00:00+03
5000	201	38.33	2026-10-01 00:00:00+03
\.


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pg
--

SELECT pg_catalog.setval('public.customers_id_seq', 1200, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: sales; Owner: shop_owner
--

SELECT pg_catalog.setval('sales.orders_id_seq', 5000, true);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: pg
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: sales; Owner: shop_owner
--

ALTER TABLE ONLY sales.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_customer_fkey; Type: FK CONSTRAINT; Schema: sales; Owner: shop_owner
--

ALTER TABLE ONLY sales.orders
    ADD CONSTRAINT orders_customer_fkey FOREIGN KEY (customer) REFERENCES public.customers(id);


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: pg
--

GRANT SELECT ON TABLE public.customers TO shop_owner;


--
-- PostgreSQL database dump complete
--

\unrestrict fYfEDjsJhJjSYMmctnP2iLbUrdYL5dXGFzsMT85TZ1NfPn9B4KjcGKLyJZWlmBk

